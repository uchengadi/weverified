<?php

/**
 * This is the model class for table "bucket_has_assets".
 *
 * The followings are the available columns in table 'bucket_has_assets':
 * @property string $bucket_id
 * @property string $asset_id
 * @property integer $is_downloadable
 */
class BucketHasAssets extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'bucket_has_assets';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('bucket_id, asset_id', 'required'),
			array('is_downloadable', 'numerical', 'integerOnly'=>true),
			array('bucket_id, asset_id', 'length', 'max'=>10),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('bucket_id, asset_id, is_downloadable', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'bucket_id' => 'Bucket',
			'asset_id' => 'Asset',
			'is_downloadable' => 'Is Downloadable',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('bucket_id',$this->bucket_id,true);
		$criteria->compare('asset_id',$this->asset_id,true);
		$criteria->compare('is_downloadable',$this->is_downloadable);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return BucketHasAssets the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
         /*8
         * This is the function that retrieves all assets in a bucket
         */
        public function retrieveAllAssetsForThisBucket($bucket_id){
            $all_assets = [];
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='bucket_id=:id';
            $criteria->params = array(':id'=>$bucket_id);
            $assets = BucketHasAssets::model()->findAll($criteria); 
            
            foreach($assets as $asset){
            
                $all_assets[] = $asset['asset_id'];
            }
            
            return $all_assets;
        }
}
