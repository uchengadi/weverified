<?php

/**
 * This is the model class for table "domain_has_document".
 *
 * The followings are the available columns in table 'domain_has_document':
 * @property string $domain_id
 * @property integer $document_id
 * @property integer $batch_id
 * @property integer $is_needed
 * @property integer $is_physical_document_needed
 * @property integer $requested_by
 * @property integer $is_approved
 * @property string $date_requested
 * @property integer $approved_by
 * @property string $date_approved
 * @property integer $no_of_subscribers
 * @property integer $period
 */
class DomainHasDocument extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'domain_has_document';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('domain_id, document_id, batch_id', 'required'),
			array('document_id, batch_id, is_needed, is_physical_document_needed, requested_by, is_approved, approved_by, no_of_subscribers, period', 'numerical', 'integerOnly'=>true),
			array('domain_id', 'length', 'max'=>10),
			array('date_requested, date_approved', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('domain_id, document_id, batch_id, is_needed, is_physical_document_needed, requested_by, is_approved, date_requested, approved_by, date_approved, no_of_subscribers, period', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'domain_id' => 'Domain',
			'document_id' => 'Document',
			'batch_id' => 'Batch',
			'is_needed' => 'Is Needed',
			'is_physical_document_needed' => 'Is Physical Document Needed',
			'requested_by' => 'Requested By',
			'is_approved' => 'Is Approved',
			'date_requested' => 'Date Requested',
			'approved_by' => 'Approved By',
			'date_approved' => 'Date Approved',
			'no_of_subscribers' => 'No Of Subscribers',
			'period' => 'Period',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('domain_id',$this->domain_id,true);
		$criteria->compare('document_id',$this->document_id);
		$criteria->compare('batch_id',$this->batch_id);
		$criteria->compare('is_needed',$this->is_needed);
		$criteria->compare('is_physical_document_needed',$this->is_physical_document_needed);
		$criteria->compare('requested_by',$this->requested_by);
		$criteria->compare('is_approved',$this->is_approved);
		$criteria->compare('date_requested',$this->date_requested,true);
		$criteria->compare('approved_by',$this->approved_by);
		$criteria->compare('date_approved',$this->date_approved,true);
		$criteria->compare('no_of_subscribers',$this->no_of_subscribers);
		$criteria->compare('period',$this->period);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return DomainHasDocument the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
}
