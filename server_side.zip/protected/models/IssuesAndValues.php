<?php

/**
 * This is the model class for table "issues_and_values".
 *
 * The followings are the available columns in table 'issues_and_values':
 * @property string $id
 * @property string $name
 * @property string $domain_id
 * @property string $description
 * @property string $code
 * @property string $date_created
 */
class IssuesAndValues extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'issues_and_values';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('domain_id', 'required'),
			array('name', 'length', 'max'=>250),
			array('domain_id', 'length', 'max'=>10),
			array('code', 'length', 'max'=>200),
			array('description, date_created', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, name, domain_id, description, code, date_created', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'name' => 'Name',
			'domain_id' => 'Domain',
			'description' => 'Description',
			'code' => 'Code',
			'date_created' => 'Date Created',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('name',$this->name,true);
		$criteria->compare('domain_id',$this->domain_id,true);
		$criteria->compare('description',$this->description,true);
		$criteria->compare('code',$this->code,true);
		$criteria->compare('date_created',$this->date_created,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return IssuesAndValues the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
        /**
         * this is the function that retrieves the name of an issue and value
         */
        public function getTheIssuesAndValuesForThisNetwork($issue){
            
            $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';   
             $criteria->params = array(':id'=>$issue);
             $issue = IssuesAndValues::model()->find($criteria);
             
             return $issue['name'];
        }
        
        
        /**
         * This is the function that gets the issues and values name
         */
        public function getTheIssuesAndvaluesForThisMessage($issue){
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';   
             $criteria->params = array(':id'=>$issue);
             $issue = IssuesAndValues::model()->find($criteria);
             
             return $issue['name'];
        }
        
        
        /**
         * This is the function that determine if issue and value was created by a member of his colleague
         */
        public function isThisIssueAndValueAvailableForAMemberOrColleagues($id,$user_id){
              $model = new IssuesForMember;         
            if($model->isIssueAndValueAvailableForAMember($id,$user_id)){
                return true;
            }else if($this->isIssueAndValueAvailableForMemberColleagues($id,$user_id)){
                return true;
            }else{
                return false;
            }
    
        }
        
        /**
         * This is the function that determines if issues are available to member collegues
         */
        public function isIssueAndValueAvailableForMemberColleagues($issue_id,$user_id){
            $model = new IssuesForMember; 
            //get the colleagues of this menmber
            $colleagues = $this->getAllTheColleaguesOfThisMember($user_id);
            
            foreach($colleagues as $col){
                if($model->isIssueAndValueAvailableForAMember($issue_id,$col)){
                    return true;
                }
            }
            return false;
        }
        
        
        /**
         * This is the function that retrieves the colleagues of a member
         */
        public function getAllTheColleaguesOfThisMember($user_id){
            $model = new MemberHasColleagues;
            return $model->getAllTheColleaguesOfThisMember($user_id);
        }
        
        
}
