<?php

/**
 * This is the model class for table "network".
 *
 * The followings are the available columns in table 'network':
 * @property string $id
 * @property string $name
 * @property string $description
 * @property string $purpose
 * @property string $status
 * @property string $domain_id
 * @property string $create_time
 * @property string $update_time
 * @property integer $create_user_id
 * @property integer $update_user_id
 *
 * The followings are the available model relations:
 * @property Resourcegroupcategory $domain
 * @property Resourcegroupcategory[] $resourcegroupcategories
 */
class Network extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'network';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('status, domain_id', 'required'),
			array('create_user_id, update_user_id', 'numerical', 'integerOnly'=>true),
			array('name, description, purpose', 'length', 'max'=>200),
			array('status', 'length', 'max'=>8),
			array('domain_id', 'length', 'max'=>10),
			array('create_time, update_time', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, name, description, purpose, status, domain_id, create_time, update_time, create_user_id, update_user_id', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'domain' => array(self::BELONGS_TO, 'Resourcegroupcategory', 'domain_id'),
			'resourcegroupcategories' => array(self::MANY_MANY, 'Resourcegroupcategory', 'network_has_members(network_id, member_id)'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'name' => 'Name',
			'description' => 'Description',
			'purpose' => 'Purpose',
			'status' => 'Status',
			'domain_id' => 'Domain',
			'create_time' => 'Create Time',
			'update_time' => 'Update Time',
			'create_user_id' => 'Create User',
			'update_user_id' => 'Update User',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('name',$this->name,true);
		$criteria->compare('description',$this->description,true);
		$criteria->compare('purpose',$this->purpose,true);
		$criteria->compare('status',$this->status,true);
		$criteria->compare('domain_id',$this->domain_id,true);
		$criteria->compare('create_time',$this->create_time,true);
		$criteria->compare('update_time',$this->update_time,true);
		$criteria->compare('create_user_id',$this->create_user_id);
		$criteria->compare('update_user_id',$this->update_user_id);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return Network the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
        /**
         * This is the functioon that retrieves all networks owned by a user
         */
        public function getAllTheNetworksOwnedByUser($userid){
            
              $all_owner_networks = [];
              $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='create_user_id=:ownerid';   
              $criteria->params = array(':ownerid'=>$userid);
              $networks = Network::model()->findAll($criteria);
              
              foreach($networks as $network){
                  $all_owner_networks[] = $network['id'];
              }
              return $all_owner_networks;
        
        }
        
        
        /**
         * This is the function that determines if a network domain type is the type required 
         */
        public function isNetworkDomainOfTheRequiredDomainType($network_id,$domain_type){
            $model = new Resourcegroupcategory;
           
            //get the domain of this network
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';   
             $criteria->params = array(':id'=>$network_id);
             $network = Network::model()->find($criteria);
             
             if($model->isDomainOfTheRequiredDomainType($network['domain_id'],$domain_type)){
                 return true;
             }else{
                 return false;
             }
        }
        
        
         /**
         * This is the function that determines if the required domain, domain type and country of the country is the required type
         */
        public function isNetworkDomainOfTheRequiredDomainTypeAndCountry($network_id,$domain_type,$country_id){
            $model = new Resourcegroupcategory;
           
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';   
             $criteria->params = array(':id'=>$network_id);
             $network = Network::model()->find($criteria);
             
              if($model->isDomainOfTheRequiredDomainTypeAndCountry($network['domain_id'],$domain_type,$country_id)){
                    return true;
                    }else{
                        return false;
                    }         
             
            
        }
        
        
        /**
         * This is the function confirms if a network belongs to a domain
         */
        public function isThisNetworkForThisDomain($network_id,$domain_id){
            $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';   
             $criteria->params = array(':id'=>$network_id);
             $network = Network::model()->find($criteria);
             
             if($network['domain_id'] == $domain_id){
                 return true;
             }else{
                 return false;
             }
            
        }
        
        
        /**
         * This is the function that confirms if a network is available for a particular member
         */
        public function isThisNetworkAvailableForThisMember($member_id,$network_id,$domain_id,$network_security_level_weight){
            $model = new User;
            
            if($model->isMemberWithAppropriateSecurityClearance($member_id,$network_security_level_weight)){
                if($model->isMemberInTheSameDomainAsNetwork($member_id,$domain_id)){
                    return true;
                }else{
                    if($this->isNetworkOfPublicType($network_id)){
                        return true;
                    }else{
                        return false;
                    }
                }
            }
            return false;
            
        }
        
        /**
         * This is the function that determines if a network is of public type
         */
        public function isNetworkOfPublicType($network_id){
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';   
             $criteria->params = array(':id'=>$network_id);
             $network = Network::model()->find($criteria);
             
             if($network['type'] == 'public'){
                 return true;
             }else{
                 return false;
             }
        }
        
        
        /**
         * This is the funcrion that retrieves a domain of a native
         */
        public function getTheDomainOfThisNetwork($network_id){
            $model = new Resourcegroupcategory; 
            
            $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';   
             $criteria->params = array(':id'=>$network_id);
             $network = Network::model()->find($criteria);
             
             return $model->getThisDomainName($network['domain_id']);
        
        }
        
        
        /**
         * This is the functioon that retrieves the issues and values of a network
         */
        public function getTheIssuesAndValuesOfThisNetwork($network_id){
            
            $model = new IssuesAndValues;
            
            $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';   
             $criteria->params = array(':id'=>$network_id);
             $network = Network::model()->find($criteria);
             
             return $model->getTheIssuesAndValuesForThisNetwork($network['issues_and_values_id']);
        
        }
        
        
        /**
         * This is the function that retreieves the name of a network
         */
        public function getTheNameOfThisNetwork($network_id){
            
            $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';   
             $criteria->params = array(':id'=>$network_id);
             $network = Network::model()->find($criteria);
             
             return $network['name'];
             
        }
        
        
        /**
         * This is the function that confirms if a network is of a private type
         */
        public function isThisNetworkPrivate($network_id){
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('network')
                    ->where("id = $network_id and type='private'");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
        /**
         * This is the function that gets the adoption rule of this group
         */
        public function getTheAdoptionRuleForThisNetworkGroup($group_id){
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';   
             $criteria->params = array(':id'=>$group_id);
             $network = Network::model()->find($criteria);
             
             return $network['decision_rule'];
        }
        
        
        
        /**
         * This is the function that gets the quorum rule of this group
         */
        public function getTheQuorumRuleForThisNetworkGroup($group_id){
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';   
             $criteria->params = array(':id'=>$group_id);
             $network = Network::model()->find($criteria);
             
             return $network['quorum'];
        }
         
}
