<?php

/**
 * This is the model class for table "feedbacks_response".
 *
 * The followings are the available columns in table 'feedbacks_response':
 * @property string $id
 * @property string $feedback_id
 * @property string $user_id
 * @property string $product_likes
 * @property string $product_hates
 * @property string $was_needs_met
 * @property string $unfillfulled_needs
 * @property string $recommendation_to_friends
 * @property string $can_get_product_again
 * @property string $your_expected_improvements_in_our_product
 * @property string $preferred_product_to_this
 */
class FeedbacksResponse extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'feedbacks_response';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('feedback_id, user_id', 'required'),
			array('feedback_id, user_id', 'length', 'max'=>10),
			array('can_get_product_again, your_expected_improvements_in_our_product, preferred_product_to_this', 'length', 'max'=>250),
			array('product_likes, product_hates, was_needs_met, unfillfulled_needs, recommendation_to_friends', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, feedback_id, user_id, product_likes, product_hates, was_needs_met, unfillfulled_needs, recommendation_to_friends, can_get_product_again, your_expected_improvements_in_our_product, preferred_product_to_this', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'feedback_id' => 'Feedback',
			'user_id' => 'User',
			'product_likes' => 'Product Likes',
			'product_hates' => 'Product Hates',
			'was_needs_met' => 'Was Needs Met',
			'unfillfulled_needs' => 'Unfillfulled Needs',
			'recommendation_to_friends' => 'Recommendation To Friends',
			'can_get_product_again' => 'Can Get Product Again',
			'your_expected_improvements_in_our_product' => 'Your Expected Improvements In Our Product',
			'preferred_product_to_this' => 'Preferred Product To This',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('feedback_id',$this->feedback_id,true);
		$criteria->compare('user_id',$this->user_id,true);
		$criteria->compare('product_likes',$this->product_likes,true);
		$criteria->compare('product_hates',$this->product_hates,true);
		$criteria->compare('was_needs_met',$this->was_needs_met,true);
		$criteria->compare('unfillfulled_needs',$this->unfillfulled_needs,true);
		$criteria->compare('recommendation_to_friends',$this->recommendation_to_friends,true);
		$criteria->compare('can_get_product_again',$this->can_get_product_again,true);
		$criteria->compare('your_expected_improvements_in_our_product',$this->your_expected_improvements_in_our_product,true);
		$criteria->compare('preferred_product_to_this',$this->preferred_product_to_this,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return FeedbacksResponse the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
         /**
         * This is the function that ascertains if a user had provided feedback on a code before
         */
        public function hasUserProvidedThisFeedbackBefore($feedback_id,$user_id){
             $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('feedbacks_response')
                    ->where("feedback_id = $feedback_id and user_id=$user_id");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return true;
                }else{
                    return false;
                }
        }
}
