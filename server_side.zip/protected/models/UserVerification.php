<?php

/**
 * This is the model class for table "user_verification".
 *
 * The followings are the available columns in table 'user_verification':
 * @property string $id
 * @property string $user_id
 * @property string $issue_of_verification
 * @property string $status
 * @property integer $is_paid_for
 * @property string $filename
 * @property string $requestor_id
 * @property string $requestor_domain_id
 * @property string $date_requested
 * @property string $user_type
 * @property string $date_verified
 * @property string $verified_filename
 */
class UserVerification extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'user_verification';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('user_id, issue_of_verification, status, requestor_id, requestor_domain_id, user_type', 'required'),
			array('is_paid_for', 'numerical', 'integerOnly'=>true),
			array('user_id, requestor_id, requestor_domain_id', 'length', 'max'=>10),
			array('issue_of_verification', 'length', 'max'=>27),
			array('status', 'length', 'max'=>9),
			array('filename, verified_filename', 'length', 'max'=>250),
			array('user_type', 'length', 'max'=>8),
			array('date_requested, date_verified', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, user_id, issue_of_verification, status, is_paid_for, filename, requestor_id, requestor_domain_id, date_requested, user_type, date_verified, verified_filename', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'user_id' => 'User',
			'issue_of_verification' => 'Issue Of Verification',
			'status' => 'Status',
			'is_paid_for' => 'Is Paid For',
			'filename' => 'Filename',
			'requestor_id' => 'Requestor',
			'requestor_domain_id' => 'Requestor Domain',
			'date_requested' => 'Date Requested',
			'user_type' => 'User Type',
			'date_verified' => 'Date Verified',
			'verified_filename' => 'Verified Filename',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('user_id',$this->user_id,true);
		$criteria->compare('issue_of_verification',$this->issue_of_verification,true);
		$criteria->compare('status',$this->status,true);
		$criteria->compare('is_paid_for',$this->is_paid_for);
		$criteria->compare('filename',$this->filename,true);
		$criteria->compare('requestor_id',$this->requestor_id,true);
		$criteria->compare('requestor_domain_id',$this->requestor_domain_id,true);
		$criteria->compare('date_requested',$this->date_requested,true);
		$criteria->compare('user_type',$this->user_type,true);
		$criteria->compare('date_verified',$this->date_verified,true);
		$criteria->compare('verified_filename',$this->verified_filename,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return UserVerification the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
                /**
         * This is the function that determines the type and size of icon file
         */
        public function isFileTypeLegal(){
            
           if(isset($_FILES['filename']['name'])){
                $tmpName = $_FILES['filename']['tmp_name'];
                $iconFileName = $_FILES['filename']['name'];    
                $iconFileType = $_FILES['filename']['type'];
                $iconFileSize = $_FILES['filename']['size'];
            } 
          if(($iconFileType === 'application/pdf')){
              return true;
               
            }else{
                return false;
            }
            
        }
        
        
        /**
         * This is the function that moves file to its destination
         */
        public function moveTheDocumentToItsPathAndReturnTheFilenameName($model,$icon_filename){
            
            if(isset($_FILES['filename']['name'])){
                        $tmpName = $_FILES['filename']['tmp_name'];
                        $iconName = $_FILES['filename']['name'];    
                        $iconType = $_FILES['filename']['type'];
                        $iconSize = $_FILES['filename']['size'];
                  
                   }
                    
                    if($iconName !== null) {
                        if($model->id === null){
                          //$iconFileName = $icon_filename; 
                          if($icon_filename != ""){
                                $iconFileName = time().'_'.$icon_filename;  
                            }else{
                                $iconFileName = $icon_filename;  
                            }    
                          
                           // upload the icon file
                        if($iconName !== null){
                            	$iconPath = Yii::app()->params['documents'].$iconFileName;
				move_uploaded_file($tmpName,$iconPath);
                                        
                        
                                return $iconFileName;
                        }else{
                            $iconFileName = $icon_filename;
                            return $iconFileName;
                        } // validate to save file
                        }else{
                            if($this->noNewVerificationFileProvided($model->id,$icon_filename)){
                                $iconFileName = $icon_filename; 
                                return $iconFileName;
                            }else{
                            if($icon_filename != ""){
                                
                                if($this->removeTheExistingVerificatioFile($model->id)){
                                 $iconFileName = time().'_'.$icon_filename; 
                                 //$iconFileName = time().$icon_filename;  
                                   $iconPath = Yii::app()->params['documents'].$iconFileName;
                                   move_uploaded_file($tmpName,$iconPath);
                                   return $iconFileName;
                                    
                                   // $iconFileName = time().'_'.$icon_filename;  
                                    
                             }
                            }
                                
                                
                            }
                            
                            //$iconFileName = $icon_filename; 
                                              
                            
                        }
                      
                     }else{
                         $iconFileName = $icon_filename;
                         return $iconFileName;
                     }
        }
        
        
        
       
        	/**
         * This is the function to ascertain if a new verification file was provided or not
         */
        public function noNewVerificationFileProvided($id,$filename){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $filename= UserVerification::model()->find($criteria);
                
                if($filename['filename']==$filename){
                    return true;
                }else{
                    return false;
                }
            
        }
        
        
        	 /**
         * This is the function that removes an existing video file
         */
        public function removeTheExistingVerificatioFile($id){
            
            //retreve the existing zip file from the database
            
            if($this->isTheVerificationFilenameNotTheDefault($id)){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $filename= UserVerification::model()->find($criteria);
                
                //$directoryPath =  dirname(Yii::app()->request->scriptFile);
               $directoryPath = "c:\\xampp\htdocs\appspace_assets\\documents\\";
               // $iconpath = '..\appspace_assets\icons'.$icon['icon'];
                $filepath =$directoryPath.$filename['filename'];
                //$filepath = $directoryPath.$iconpath;
                
                if(unlink($filepath)){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return true;
            }
                
            
            
        }
        
        
        
          /**
         * This is the function that determines if  the filename is the default
         */
        public function isTheVerificationFilenameNotTheDefault($id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $filename= UserVerification::model()->find($criteria);
                
                if($filename['filename'] == "" || $filename['filename'] ===NULL){
                    return false;
                }else{
                    return true;
                }
        }
     
        
        /**
         * This is the function that updates a user verification request information
         */
        public function isTheUpdateOfTheVerificationIssueASuccess($id,$issue_for_verification){
            
             $cmd =Yii::app()->db->createCommand();
                $result = $cmd->update('user_verification',
                                  array(
                                    'issue_of_verification'=>$issue_for_verification
                   ),
                     ("id=$id"));
            if($result>0){
                return true;
            }else{
                return false;
            }
        }
        
        
         /**
         * Thisn is the function that retrieves all verified users on the platform
         */
        public function retrieveAllVerifiedUsersOnThePlatform(){
                $all_verified = [];
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='status=:status';
                $criteria->params = array(':status'=>"verified");
                $verified= UserVerification::model()->findAll($criteria);
                
                foreach($verified as $ver){
                    $all_verified[] = $ver['user_id'];
                    
                }
                
                return $all_verified;
            
        }
        
        
        /**
         * This is the function that retrieves the consummable member user id
         */
        public function getTheUserForThisVerification($verification_id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$verification_id);
                $verify= UserVerification::model()->find($criteria);
                
                return $verify['user_id'];
            
        }
        
           
        /**
         * This is the function that retrieves the corresponding domain given the verification id
         */
        public function getTheUserIdForThisUserVerification($verification_id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$verification_id);
                $verify= UserVerification::model()->find($criteria);
                
                return $verify['user_id'];
                
        }
}
