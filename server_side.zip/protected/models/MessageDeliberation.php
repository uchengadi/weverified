<?php

/**
 * This is the model class for table "message_deliberation".
 *
 * The followings are the available columns in table 'message_deliberation':
 * @property integer $id
 * @property string $from
 * @property integer $to
 * @property integer $cc
 * @property integer $is_to_list_a_network
 * @property integer $is_cc_list_a_network
 * @property string $to_recepients_list
 * @property string $cc_recepients_list
 * @property string $subject
 * @property string $message
 * @property string $category
 * @property integer $parent_id
 * @property string $type
 * @property string $content_type
 * @property string $decision
 * @property string $from_domain_id
 * @property string $to_domain_id
 * @property integer $message_id
 * @property integer $asset_id
 * @property string $attachment
 * @property integer $is_read
 * @property integer $is_attachment_downloaded
 * @property string $code
 * @property integer $is_message_forwardable
 * @property string $date_sent
 * @property string $date_recieved
 * @property string $sender_name
 * @property string $sender_domain_name
 */
class MessageDeliberation extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'message_deliberation';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('from, content_type, decision, from_domain_id, to_domain_id, message_id', 'required'),
			array('to, cc, is_to_list_a_network, is_cc_list_a_network, parent_id, message_id, asset_id, is_read, is_attachment_downloaded, is_message_forwardable', 'numerical', 'integerOnly'=>true),
			array('from, from_domain_id, to_domain_id', 'length', 'max'=>10),
			array('to_recepients_list, cc_recepients_list, subject, attachment, sender_name, sender_domain_name', 'length', 'max'=>250),
			array('category', 'length', 'max'=>12),
			array('type', 'length', 'max'=>6),
			array('content_type', 'length', 'max'=>8),
			array('decision', 'length', 'max'=>11),
			array('code', 'length', 'max'=>200),
			array('message, date_sent, date_recieved', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, from, to, cc, is_to_list_a_network, is_cc_list_a_network, to_recepients_list, cc_recepients_list, subject, message, category, parent_id, type, content_type, decision, from_domain_id, to_domain_id, message_id, asset_id, attachment, is_read, is_attachment_downloaded, code, is_message_forwardable, date_sent, date_recieved, sender_name, sender_domain_name', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'from' => 'From',
			'to' => 'To',
			'cc' => 'Cc',
			'is_to_list_a_network' => 'Is To List A Network',
			'is_cc_list_a_network' => 'Is Cc List A Network',
			'to_recepients_list' => 'To Recepients List',
			'cc_recepients_list' => 'Cc Recepients List',
			'subject' => 'Subject',
			'message' => 'Message',
			'category' => 'Category',
			'parent_id' => 'Parent',
			'type' => 'Type',
			'content_type' => 'Content Type',
			'decision' => 'Decision',
			'from_domain_id' => 'From Domain',
			'to_domain_id' => 'To Domain',
			'message_id' => 'Message',
			'asset_id' => 'Asset',
			'attachment' => 'Attachment',
			'is_read' => 'Is Read',
			'is_attachment_downloaded' => 'Is Attachment Downloaded',
			'code' => 'Code',
			'is_message_forwardable' => 'Is Message Forwardable',
			'date_sent' => 'Date Sent',
			'date_recieved' => 'Date Recieved',
			'sender_name' => 'Sender Name',
			'sender_domain_name' => 'Sender Domain Name',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id);
		$criteria->compare('from',$this->from,true);
		$criteria->compare('to',$this->to);
		$criteria->compare('cc',$this->cc);
		$criteria->compare('is_to_list_a_network',$this->is_to_list_a_network);
		$criteria->compare('is_cc_list_a_network',$this->is_cc_list_a_network);
		$criteria->compare('to_recepients_list',$this->to_recepients_list,true);
		$criteria->compare('cc_recepients_list',$this->cc_recepients_list,true);
		$criteria->compare('subject',$this->subject,true);
		$criteria->compare('message',$this->message,true);
		$criteria->compare('category',$this->category,true);
		$criteria->compare('parent_id',$this->parent_id);
		$criteria->compare('type',$this->type,true);
		$criteria->compare('content_type',$this->content_type,true);
		$criteria->compare('decision',$this->decision,true);
		$criteria->compare('from_domain_id',$this->from_domain_id,true);
		$criteria->compare('to_domain_id',$this->to_domain_id,true);
		$criteria->compare('message_id',$this->message_id);
		$criteria->compare('asset_id',$this->asset_id);
		$criteria->compare('attachment',$this->attachment,true);
		$criteria->compare('is_read',$this->is_read);
		$criteria->compare('is_attachment_downloaded',$this->is_attachment_downloaded);
		$criteria->compare('code',$this->code,true);
		$criteria->compare('is_message_forwardable',$this->is_message_forwardable);
		$criteria->compare('date_sent',$this->date_sent,true);
		$criteria->compare('date_recieved',$this->date_recieved,true);
		$criteria->compare('sender_name',$this->sender_name,true);
		$criteria->compare('sender_domain_name',$this->sender_domain_name,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return MessageDeliberation the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
         /**
         * This is the function that generates codes for a message
         */
        public function generateTheCodeForThisDeliberation($message_id){
                          
            $model = new Message;   
            return $model->getTheCodeOfThisMessage($message_id);
        }
        
       
            /**
             * This is the function that retreives the code of a message
             */
            public function getTheCodeOfThisDeliberation($id){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition="id=:id";
                $criteria->params = array(':id'=>$id);
                $deliberation= MessageDeliberation::model()->find($criteria);
                return $deliberation['code'];
                
            }
            
            
            /**
         * This is the function that sends a chat message to a recipient
         */
        public function executesendingChatDeliberationMessageToThisMembers($message_id,$recepient,$message,$code,$user_id,$domain_id,$filename,$content_type,$filesize,$decision,$asset_id){
            $model = new User;
            
            $subject = $this->getTheSubjectOfTheOriginalMessage($message_id);
             $cmd =Yii::app()->db->createCommand();
                $result = $cmd->insert('message_deliberation',
                                  array(
                                    'from'=>$user_id,
                                    'to'=>$recepient,
                                    'subject'=>$subject,  
                                    'message'=>$message,
                                    'category'=>strtolower('chat'),
                                    'type'=>strtolower('inbox'),
                                    'from_domain_id'=>$domain_id, 
                                    'to_domain_id'=>$model->getTheDomainOfThisUser($recepient),
                                    'message_id'=>$message_id,
                                    'code'=>$code,
                                    'attachment'=>$filename,
                                    'attachment_size'=>$filesize, 
                                    'content_type'=>$content_type,
                                     'decision'=>$decision,
                                      'asset_id'=>$asset_id,
                                   'is_message_forwardable'=>0,
                                    'date_sent'=>new CDbExpression('NOW()'),
                                    'date_recieved'=>new CDbExpression('NOW()'),  
                                    'sender_name'=>$model->getTheNameOfThisMember($user_id),
                                     'sender_domain_name'=>$this->getTheDomainNameOfThisMemberDomainId($domain_id) 
                                  )
			
                        );
                if($result>0){
                    if($this->isSendingInformationalPrivateEmailASuccess($recepient,$user_id,$domain_id,"$subject")){
                        return $this->getTheCurrentMessageIdOfThisReceipient("$code");
                    }else{
                        return $this->getTheCurrentMessageIdOfThisReceipient("$code");
                    }
                    
                }else{
                    return 0;
                }
            
        }
        
        
        /**
         * This is the function that gets the subject of a deliberation original message
         */
        public function getTheSubjectOfTheOriginalMessage($message_id){
            $model = new Message;
            return $model->getTheSubjectOfTheOriginalMessage($message_id);
        }
        
        
         /**
         * This is the finction that retrieves the last mesage id of this user
         */
        public function getTheCurrentMessageIdOfThisReceipient($code){
            //retreiev all the messages from this user
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition="code=:code";
            $criteria->params = array(':code'=>"$code");
            $messages= MessageDeliberation::model()->findAll($criteria);
             $recent = 0;
             foreach($messages as $mess){
                 if($mess['id']>$recent){
                     $recent = $mess['id'];
                 }
             }
             return $recent;
        }
        
        
        
         /**
         * This is the function that sends private email to a message recepient
         */
        public function isSendingInformationalPrivateEmailASuccess($to,$from,$from_domain_id,$subject){
            $model = new User;
            //get the email of this receiver as well as te from domain name
            $email = $model->getTheEmailAddressOfThisUser($to);
            $domain_name = $this->getTheDomainNameOfThisMemberDomainId($from_domain_id);
            
            return true;
        }
        
        
        /**
         * This is the function that gets a domain name given its id
         */
        public function getTheDomainNameOfThisMemberDomainId($domain_id){
            $model = new Resourcegroupcategory;
            return $model->getTheDomainNameOfThisDomain($domain_id);
        }
        
        
        /**
         * This is the function that gets the name of a sender
         */
        public function getTheNameOfThisMember($user_id){
            $model = new User;
            return $model->getTheNameOfThisMember($user_id);
        }
        
        
        
        /**
         * This is the function that writes a chat deliberation message to the sender outbox
         */
        public function writeThisChatDeliberationMessageToTheSenderOutbox($message_id,$message,$code,$user_id,$domain_id,$filename,$content_type,$filesize,$decision,$asset_id){
            $bucket_model = new DeliberationHasBuckets;
            $subject = $this->getTheSubjectOfTheOriginalMessage($message_id);
             $cmd =Yii::app()->db->createCommand();
                $result = $cmd->insert('message_deliberation',
                                  array(
                                    'from'=>$user_id,
                                    'subject'=>$subject,  
                                    'message'=>$message,
                                    'category'=>strtolower('chat'),
                                    'type'=>strtolower('outbox'),
                                    'from_domain_id'=>$domain_id, 
                                    'message_id'=>$message_id,
                                    'code'=>$code,
                                    'attachment'=>$filename,
                                    'attachment_size'=>$filesize, 
                                    'content_type'=>$content_type, 
                                    'decision'=>$decision,   
                                     'asset_id'=>$asset_id,  
                                   'is_message_forwardable'=>0,
                                    'date_recieved'=>new CDbExpression('NOW()'),
                                     'date_sent'=>new CDbExpression('NOW()'),  
                                    'sender_name'=>$this->getTheNameOfThisMember($user_id),
                                     'sender_domain_name'=>$this->getTheDomainNameOfThisMemberDomainId($domain_id)  
                                  )
			
                        );
               
               if($result>0){
                    return true;
                }else{
                    return false;
                }
            
        }
        
        
             /**
         * Determine a domain id of a user given his user id 
         */
        public function determineAUserDomainIdGiven($userid){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$userid);
            $user= User::model()->find($criteria1);
            
            return $user['domain_id'];
        }
        
        
           /**
         * This is the function that replies a chat message
         */
        public function replyingThisChatDeliberationMessageToThisColleague($deliberation_id,$message_id,$col,$message,$code,$user_id,$domain_id,$filename,$filesize,$content_type,$decision,$asset_id){
            
           $model = new User;
            
            $subject = $this->getTheSubjectOfTheOriginalMessage($message_id);
             $cmd =Yii::app()->db->createCommand();
                $result = $cmd->insert('message_deliberation',
                                  array(
                                    'from'=>$user_id,
                                    'to'=>$col,
                                    'subject'=>$subject,  
                                    'message'=>$message,
                                    'category'=>strtolower('chat'),
                                    'type'=>strtolower('inbox'),
                                    'from_domain_id'=>$domain_id, 
                                    'to_domain_id'=>$model->getTheDomainOfThisUser($col),
                                    'message_id'=>$message_id,
                                    'code'=>$code,
                                    'decision'=>$decision,  
                                     'asset_id'=>$asset_id,  
                                    'parent_id'=> $deliberation_id,
                                    'attachment'=>$filename,
                                    'attachment_size'=>$filesize, 
                                    'content_type'=>$content_type,   
                                   'is_message_forwardable'=>0,
                                    'date_sent'=>new CDbExpression('NOW()'),
                                    'date_recieved'=>new CDbExpression('NOW()'),  
                                    'sender_name'=>$this->getTheNameOfThisMember($user_id),
                                     'sender_domain_name'=>$this->getTheDomainNameOfThisMemberDomainId($domain_id)   
                                  )
			
                        );
                if($result>0){
                    if($this->isSendingInformationalPrivateEmailASuccess($col,$user_id,$domain_id,"$subject")){
                        return $this->getTheCurrentMessageIdOfThisReceipient("$code");
                    }else{
                        return $this->getTheCurrentMessageIdOfThisReceipient("$code");
                    }
                    
                }else{
                    return 0;
                }
               
           
        }
        
        
         /**
         * This is the function that writes a chat response deliberation message to the sender outbox
         */
        public function writeTheReplyToChatDeliberationMessageToTheSenderOutbox($deliberation_id,$message_id,$message,$code,$user_id,$domain_id,$filename,$filesize,$content_type,$decision,$asset_id){
            $bucket_model = new DeliberationHasBuckets;
            $subject = $this->getTheSubjectOfTheOriginalMessage($message_id);
             $cmd =Yii::app()->db->createCommand();
                $result = $cmd->insert('message_deliberation',
                                  array(
                                    'from'=>$user_id,
                                    'subject'=>$subject,  
                                    'message'=>$message,
                                    'category'=>strtolower('chat'),
                                    'type'=>strtolower('outbox'),
                                    'from_domain_id'=>$domain_id, 
                                    'message_id'=>$message_id,
                                     'parent_id'=> $deliberation_id,
                                    'code'=>$code,
                                    'decision'=>$decision,
                                     'asset_id'=>$asset_id,   
                                    'attachment'=>$filename,
                                    'attachment_size'=>$filesize, 
                                    'content_type'=>$content_type,    
                                   'is_message_forwardable'=>0,
                                    'date_recieved'=>new CDbExpression('NOW()'),
                                    'date_sent'=>new CDbExpression('NOW()'),  
                                    'sender_name'=>$this->getTheNameOfThisMember($user_id),
                                     'sender_domain_name'=>$this->getTheDomainNameOfThisMemberDomainId($domain_id)    
                                  )
			
                        );
               if($result>0){
                    return true;
                }else{
                    return false;
                }
            
        }
        
        
         /**
         * This is the function that moves a filename to its location path
         */
        public function moveThisFileToItsLocationAndReturnTheUniqueFilename($model,$filename,$content_type){
            
            if(isset($_FILES['deliberation_filename']['name'])){
                        $tmpName = $_FILES['deliberation_filename']['tmp_name'];
                        $iconName = $_FILES['deliberation_filename']['name'];    
                        $iconType = $_FILES['deliberation_filename']['type'];
                        $iconSize = $_FILES['deliberation_filename']['size'];
                        
                        if($iconName !== null) {
                        if($model->id === null){
                           if($filename != null){
                                $iconFileName = time().'_'.$filename;  
                            }else{
                                $iconFileName = $$filename;  
                            }  
                          
                           // upload the icon file
                        if($iconName !== null){
                            if($content_type == 'document'){
                                $iconPath = Yii::app()->params['documents'].$iconFileName;
				move_uploaded_file($tmpName,  $iconPath);
                                                        
                                return $iconFileName;
                            }else if($content_type == 'image'){
                                $iconPath = Yii::app()->params['images'].$iconFileName;
				move_uploaded_file($tmpName,  $iconPath);
                                                        
                                return $iconFileName;
                            }else if($content_type == 'audio'){
                                $iconPath = Yii::app()->params['audios'].$iconFileName;
				move_uploaded_file($tmpName,  $iconPath);
                                                        
                                return $iconFileName;
                            }else if($content_type == 'video'){
                                $iconPath = Yii::app()->params['videos'].$iconFileName;
				move_uploaded_file($tmpName,  $iconPath);
                                                        
                                return $iconFileName;
                            }
                            	
                        }else{
                            $iconFileName = $filename;
                            return $iconFileName;
                        } // validate to save file
                        }
                     }else{
                         $iconFileName = $filename;
                         return $iconFileName;
                     }
                  
                   }else{
                       return null;
                       
                   }
                    
                    
        }
        
        
        /**
         * This is the function that determines if an ssset or file type is acceptable
         */
        public function isFileTypeAndSizeAcceptable(){
           
          if(isset($_FILES['deliberation_filename']['name'])){
                $tmpName = $_FILES['deliberation_filename']['tmp_name'];
                $iconFileName = $_FILES['deliberation_filename']['name'];    
                $iconFileType = $_FILES['deliberation_filename']['type'];
                $iconFileSize = $_FILES['deliberation_filename']['size'];
                
            if($iconFileType === 'image/png'){
                return true;
            }else if($iconFileType === 'image/jpg'){
                return true;
            }else if($iconFileType === 'image/jpeg'){
                return true;
                
            }else if($iconFileType === 'application/pdf'){
                return true;
            }else if($iconFileType === 'audio/mp3'){
                return true;
            }else if($iconFileType === 'video/mp4'){
                return true;
            }else{
                return false;
            }
          }else{
              return false;  
          } 
          
           
           
            
        }
        
        
        /**
         * This is the function that confirms the deliberations of a message
         */
        public function isTheRemovalOfTheDeliberationOfThisMessageASuccess($message_id){
           //check if this message has deliberations
            if($this->isMessageWithDeliberations($message_id)){
                if($this->isRemovalOfThisMessageDeliberationASuccess($message_id)){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return true;
            }
                
        }
        
        
        /**
         * This is the functioon that removes message deliberstaions
         */
        public function isRemovalOfThisMessageDeliberationASuccess($message_id){
            $counter = 0;
            $deliberations = $this->getAllOfThisMessageDeliberations($message_id);
            foreach($deliberations as $deliberation){
                if($this->isRemovalOfThisDeliberationASuccess($deliberation) == false){
                    $counter = $counter + 1;
                }
            }
            if($counter==0){
                return true;
            }else{
                return false;
            }
        }
        
        
        /**
         * This is the function that retrieves all deliberations of a message
         */
        public function getAllOfThisMessageDeliberations($message_id){
            $deliberations = [];
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition="message_id=:messid";
            $criteria->params = array(':messid'=>$message_id);
            $messages= MessageDeliberation::model()->findAll($criteria);
            
            foreach($messages as $mess){
                $deliberations[] = $mess['id'];
            }
            return $deliberations;
        }
        
        
        
        /**
         * This is the function that confirms if a message is with deliberations
         */
        public function isMessageWithDeliberations($message_id){
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('message_deliberation')
                    ->where("message_id = $message_id");
                $result = $cmd->queryScalar();
                
               if($result>0){
                   return true;
               }else{
                   return false;
               }
        }
        
        /**
         * This is the function tnat confirms if the removal of a deliberation is a success
         */
        public function isRemovalOfThisDeliberationASuccess($deliberation){
                $model = new DeliberationSidetalk;
                
                if($model->isDeliberationWithSideTalks($deliberation)){
                    if($model->isRemovalOfThisDeliberationSidetalksASuccess($deliberation)){
                        return true;
                    }else{
                        return false;
                    }
                }else{
                    if($this->isDeliberationRemovedSuccessfully($deliberation)){
                        return true;
                    }else{
                        return false;
                    }
                }
        }
        
        
        /**
         * This is the function that conforms if a deliberatioon is removed successfully
         */
        public function isDeliberationRemovedSuccessfully($deliberation_id){
             $model=  MessageDeliberation::model()->findByPk($deliberation_id);
            if($model === null){
                return false;
            }else if($model->delete()){
                return true;
            }else{
                return false;
            }
        }
        
        
        /**
         * This is the function that confirms if deliberation has assets
         */
        public function isDeliberationMessageWithChild($deliberation_id){
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('message_deliberation')
                    ->where("parent_id = $deliberation_id");
                $result = $cmd->queryScalar();
                
               if($result>0){
                   return true;
               }else{
                   return false;
               }
        }
        
        /**
         * This is the function that confirms if deliberation has side talks
         */
        public function isTheDeliberationOnSideTalks($deliberation_id){
            $model = new DeliberationSidetalk;
            return $model->isTheDeliberationOnSideTalks($deliberation_id);
        }
        
        /**
         * This is the function that confirmd that all assets for a deliberstaion is removed successfully
         */
        public function isRemovalOfAllChildrenFromDeliberationMessageSuccessful($deliberation_id){
          /**  $family = [];
            $counter = 0;
            $family[] = $deliberation_id;
            $child = $this->getTheDeliberationIdOfThisChild($deliberation_id);
            if($this->isDeliberationMessageWithChild($child)){
                $family[] =$child;
                $counter = $counter + 1;
              $this->isRemovalOfAllChildrenFromDeliberationMessageSuccessful($child);
              return true;
               
            }else{
                $family[] = $child;
                $counter = $counter + 1;
            }
            
            for($i=$counter;$i==0;$i--){
                $model=  MessageDeliberation::model()->findByPk($family[$i]);
                $model->delete();    
            }
           * 
           */
            return true;
        }
       
        
        
       /**
        * This is the function that confirms if a deliberation is already adopted
        */
        public function isDeliberationAdopted($deliberation_id){
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('message_deliberation')
                    ->where("id = $deliberation_id and (parent_id=0 and decision='adopted')");
                $result = $cmd->queryScalar();
                
               if($result>0){
                   return true;
               }else{
                   return false;
               }
        }
        
        
        /**
         * This is the function that gets the total number of members that contributed to a deliberation
         */
        public function getTheNumberOfMembersThatContributedToThisDeliberation($deliberation_id,$group_id,$user_id){
            if($group_id == 0){
                $contributors = 0;
                $member_colleagues = $this->getAllTheColleaguesOfThisMember($user_id);
                foreach($member_colleagues as $con){
                    if($this->isMemberAContributorToThisDeliberation($deliberation_id,$con)){
                        $contributors = $contributors + 1;
                    }
                }
                //confirm if you are also contributed to the deliberation
                if($this->isMemberAContributorToThisDeliberation($deliberation_id,$user_id)){
                    $contributors = $contributors + 1;
                }
                return $contributors;
                
            }else{
                $contributors = 0;
                $group_members = $this->getAllTheMembersOfThisNetwork($group_id);
                foreach($group_members as $con){
                    if($this->isMemberAContributorToThisDeliberation($deliberation_id,$con)){
                        $contributors = $contributors + 1;
                    }
                }
                return $contributors;
            }
           
        }
        
        
        
        /**
         * This is the function that determines if a member is a contributor to a deliberation
         */
        public function isMemberAContributorToThisDeliberation($deliberation_id,$member_id){
            
             $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('message_deliberation')
                    ->where("parent_id = $deliberation_id and `from`='$member_id'");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
        /**
         * This is the function that determines if a deliberation is adopted by a member
         */
        public function isDeliberationAdoptedByMember($deliberation_id,$member_id){
             $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('message_deliberation')
                    ->where("(parent_id = $deliberation_id and decision='adopted') and `from`=$member_id");
                $result = $cmd->queryScalar();
             if($result>0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
        /**
         * This is the function that determines if a member is seeking amendments to a deliberation
         */
        public function isMemberSeekingDeliberationAmendments($deliberation_id,$member_id){
             $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('message_deliberation')
                    ->where("(parent_id = $deliberation_id and decision='amendment') and `from`=$member_id");
                $result = $cmd->queryScalar();
             if($result>0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
         /**
         * This is the function that determines if a member is non commital to a deliberation
         */
        public function isMemberNonCommitalToThisDeliberation($deliberation_id,$member_id){
             $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('message_deliberation')
                    ->where("(parent_id = $deliberation_id and decision='noncommital') and `from`=$member_id");
                $result = $cmd->queryScalar();
             if($result>0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
        
        
         /**
         * This is the function that retrieves the total number that adopted a deliberation
         */
        public function getTheNumberOfMembersThatAdoptedThisDeliberation($deliberation_id,$group_id,$user_id){
            
            if($group_id == 0){
                $contributors = 0;
                $member_colleagues = $this->getAllTheColleaguesOfThisMember($user_id);
                foreach($member_colleagues as $con){
                    if($this->isMemberAContributorToThisDeliberation($deliberation_id,$con)){
                        if($this->isDeliberationAdoptedByMember($deliberation_id,$con)){
                            $contributors = $contributors + 1;
                        }
                        
                    }
                }
                //confirm if you are also contributed to the deliberation
                if($this->isMemberAContributorToThisDeliberation($deliberation_id,$user_id)){
                    if($this->isDeliberationAdoptedByMember($deliberation_id,$con)){
                            $contributors = $contributors + 1;
                        }
                }
                return $contributors;
                
            }else{
                $contributors = 0;
                $group_members = $this->getAllTheMembersOfThisNetwork($group_id);
                foreach($group_members as $con){
                    if($this->isMemberAContributorToThisDeliberation($deliberation_id,$con)){
                         if($this->isDeliberationAdoptedByMember($deliberation_id,$con)){
                            $contributors = $contributors + 1;
                        }
                    }
                }
                return $contributors;
            }
      
        }
        
        
         /**
         * This is the function that retrieves the total number of amendment request in a deliberations 
         */
        public function getTheNumberOfMembersThatAreRequestingAmendmentToTheDeliberation($deliberation_id,$group_id,$user_id){
            
            if($group_id == 0){
                $contributors = 0;
                $member_colleagues = $this->getAllTheColleaguesOfThisMember($user_id);
                foreach($member_colleagues as $con){
                    if($this->isMemberAContributorToThisDeliberation($deliberation_id,$con)){
                        if($this->isDeliberationAdoptedByMember($deliberation_id,$con) == false){
                            if($this->isMemberSeekingDeliberationAmendments($deliberation_id,$con)){
                                $contributors = $contributors + 1;
                            }
                            
                        }
                        
                    }
                }
                //confirm if you are also contributed to the deliberation
                if($this->isMemberAContributorToThisDeliberation($deliberation_id,$user_id)){
                    if($this->isDeliberationAdoptedByMember($deliberation_id,$con) == false){
                            if($this->isMemberSeekingDeliberationAmendments($deliberation_id,$con)){
                                $contributors = $contributors + 1;
                            }
                            
                        }
                }
                return $contributors;
                
            }else{
                $contributors = 0;
                $group_members = $this->getAllTheMembersOfThisNetwork($group_id);
                foreach($group_members as $con){
                    if($this->isMemberAContributorToThisDeliberation($deliberation_id,$con)){
                        if($this->isDeliberationAdoptedByMember($deliberation_id,$con) == false){
                            if($this->isMemberSeekingDeliberationAmendments($deliberation_id,$con)){
                                $contributors = $contributors + 1;
                            }
                            
                        }
                    }
                }
                return $contributors;
            }
        }
        
        
        
        
         /**
         * This is the function that retrieves the total number of members that are still noncommital to a deliberations 
         */
        public function getTheNumberOfMembersThatAreNonCommitalToThisDeliberation($deliberation_id,$group_id,$user_id){
            
            if($group_id == 0){
                $contributors = 0;
                $member_colleagues = $this->getAllTheColleaguesOfThisMember($user_id);
                foreach($member_colleagues as $con){
                    if($this->isMemberAContributorToThisDeliberation($deliberation_id,$con)){
                        if($this->isDeliberationAdoptedByMember($deliberation_id,$con) == false){
                            if($this->isMemberSeekingDeliberationAmendments($deliberation_id,$con)==false){
                                $contributors = $contributors + 1;
                            }
                            
                        }
                        
                    }
                }
                //confirm if you are also contributed to the deliberation
                if($this->isMemberAContributorToThisDeliberation($deliberation_id,$user_id)){
                    if($this->isDeliberationAdoptedByMember($deliberation_id,$con) == false){
                            if($this->isMemberSeekingDeliberationAmendments($deliberation_id,$con)== false){
                                $contributors = $contributors + 1;
                            }
                            
                        }
                }
                return $contributors;
                
            }else{
                $contributors = 0;
                $group_members = $this->getAllTheMembersOfThisNetwork($group_id);
                foreach($group_members as $con){
                    if($this->isMemberAContributorToThisDeliberation($deliberation_id,$con)){
                        if($this->isDeliberationAdoptedByMember($deliberation_id,$con) == false){
                            if($this->isMemberSeekingDeliberationAmendments($deliberation_id,$con)==false){
                                $contributors = $contributors + 1;
                            }
                            
                        }
                    }
                }
                return $contributors;
            }
        }
        
        
       
        
         /**
         * This is the function that gets all the colleagues of a member
         */
        public function getAllTheColleaguesOfThisMember($user_id){
            $model = new MemberHasColleagues;
            return $model->getAllTheColleaguesOfThisMember($user_id);
        }
        
        /**
         * This is the function that gets the total number of a group membership
         */
        public function getAllTheMembersOfThisNetwork($group_id){
            $model = new NetworkHasMembers;
            return $model->getAllTheMembersOfThisNetwork($group_id);
        }
        
        
        /**
         * This is the function that retrieves all deliberations of a message or its asset
         */
        public function getAllOfThisMessageOrAssetDeliberations($message_id, $asset_id){
            $deliberations = [];
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition="message_id=:messid and asset_id=:assetid";
            $criteria->params = array(':messid'=>$message_id,':assetid'=>$asset_id);
            $messages= MessageDeliberation::model()->findAll($criteria);
            
            foreach($messages as $mess){
                $deliberations[] = $mess['id'];
            }
            return $deliberations;
        }
        
}
