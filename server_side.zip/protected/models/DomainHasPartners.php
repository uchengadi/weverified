<?php

/**
 * This is the model class for table "domain_has_partners".
 *
 * The followings are the available columns in table 'domain_has_partners':
 * @property string $domain_id
 * @property string $partner_id
 * @property string $type
 * @property string $request
 * @property string $initiator_request_status
 * @property string $destination_request_status
 * @property string $status
 * @property string $create_time
 * @property string $update_time
 * @property integer $create_user_id
 * @property integer $update_user_id
 *
 * The followings are the available model relations:
 * @property Resourcegroupcategory $domain
 * @property Resourcegroupcategory $partner
 */
class DomainHasPartners extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'domain_has_partners';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('domain_id, partner_id, type', 'required'),
			array('create_user_id, update_user_id', 'numerical', 'integerOnly'=>true),
			array('domain_id, partner_id, status', 'length', 'max'=>10),
			array('type', 'length', 'max'=>19),
			array('request, initiator_request_status, destination_request_status', 'length', 'max'=>8),
			array('create_time, update_time', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('domain_id, partner_id, type, request, initiator_request_status, destination_request_status, status, create_time, update_time, create_user_id, update_user_id', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'domain' => array(self::BELONGS_TO, 'Resourcegroupcategory', 'domain_id'),
			'partner' => array(self::BELONGS_TO, 'Resourcegroupcategory', 'partner_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'domain_id' => 'Domain',
			'partner_id' => 'Partner',
			'type' => 'Type',
			'request' => 'Request',
			'initiator_request_status' => 'Initiator Request Status',
			'destination_request_status' => 'Destination Request Status',
			'status' => 'Status',
			'create_time' => 'Create Time',
			'update_time' => 'Update Time',
			'create_user_id' => 'Create User',
			'update_user_id' => 'Update User',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('domain_id',$this->domain_id,true);
		$criteria->compare('partner_id',$this->partner_id,true);
		$criteria->compare('type',$this->type,true);
		$criteria->compare('request',$this->request,true);
		$criteria->compare('initiator_request_status',$this->initiator_request_status,true);
		$criteria->compare('destination_request_status',$this->destination_request_status,true);
		$criteria->compare('status',$this->status,true);
		$criteria->compare('create_time',$this->create_time,true);
		$criteria->compare('update_time',$this->update_time,true);
		$criteria->compare('create_user_id',$this->create_user_id);
		$criteria->compare('update_user_id',$this->update_user_id);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return DomainHasPartners the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        /**
         * This is the function that retrieves all domain pending partners
         */
        public function getAllTheAwaitingPartnershipRequestByDomain($user_domain_id){
            $pending_partners = [];
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='domain_id=:domainid and request=:request';   
             $criteria->params = array(':domainid'=>$user_domain_id, ':request'=>'pending');
             $domains = DomainHasPartners::model()->findAll($criteria);
             
             foreach($domains as $domain){
                 $pending_partners[] = $domain['partner_id'];
             }
             return $pending_partners;
        }
        
        
        /**
         * This is the function that retreives all partners of a domain
         */
        public function getAllThePartnersOfThisDomain($user_domain_id){
             $pending_partners = [];
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='domain_id=:domainid and request=:request';   
             $criteria->params = array(':domainid'=>$user_domain_id, ':request'=>'accepted');
             $domains = DomainHasPartners::model()->findAll($criteria);
             
             foreach($domains as $domain){
                 $pending_partners[] = $domain['partner_id'];
             }
             return $pending_partners;
        }
        
        
        /**
         * This is the function that confirms if  the requesting domain is eligible to inititate partnership request to the target domain
         */
        public function isRequestingDomainEligibleToMakePartnershipRequestToTheTargetDomain($domain_id, $target_domain_id){
            
            if($this->isSimilarPartnershipRequestPending($domain_id,$target_domain_id)){
                return false;
            }else if($this->isThisDomainAlreadyAPartnetToTheTargetDomain($domain_id,$target_domain_id)){
                return false;
            }else{
                return true;
            }
        }
        
        
        /**
         * This is the function that confirms if a similar partnership request had been pending 
         */
        public function isSimilarPartnershipRequestPending($domain_id,$target_domain_id){
            
            if($this->isTwoDomainsPartnershipRequestPending($domain_id,$target_domain_id)){
                return true;
            }else if(isTwoDomainsPartnershipRequestPending($target_domain_id,$domain_id)){
                return true;
            }else{
                return false;
            } 
            
          
        }
        
        
        /**
         * This is the function taht confirms if two domains rrequest are pending
         */
        public function isTwoDomainsPartnershipRequestPending($domain_id,$target_domain_id){
              $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('domain_has_partners')
                    ->where("(domain_id = $domain_id and partner_id=$target_domain_id) and request='pending'");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
        }
        
         /**
         * This is the function that confirms if these two domains are already in partnership 
         */
        public function isThisDomainAlreadyAPartnetToTheTargetDomain($domain_id,$target_domain_id){
            
            if($this->isTwoDomainsAreAlreadyPartners($domain_id,$target_domain_id)){
                return true;
            }else if($this->isTwoDomainsAreAlreadyPartners($target_domain_id,$domain_id)){
                return true;
            }else{
                return false;
            }
            
            
        }
        
        
        /**
         * This is the function that confirms if two domains are partners
         */
        public function isTwoDomainsAreAlreadyPartners($domain_id,$target_domain_id){
            
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('domain_has_partners')
                    ->where("(domain_id = $domain_id and partner_id=$target_domain_id) and request='accepted'");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
        
        /**
         * This is the function that confirms if partnership request was successfully initiated
         */
        public function isPartnershipRequestSuccessfullyInitiated($domain_id,$target_domain_id){
            
            if($this->isAPreviouslyRejectedRequestRemoved($domain_id,$target_domain_id)){
                
                $cmd =Yii::app()->db->createCommand();
                $result = $cmd->insert('domain_has_partners',
                                  array(
                                    'domain_id'=>$domain_id,
                                    'partner_id'=>$target_domain_id,
                                    'request'=>"pending",   
                                    'date_initiated'=>new CDbExpression('NOW()'),
                                    'initiated_user_id'=>Yii::app()->user->id  
                                  )
			
                        );
                if($result>0){
                    return true;
                }else{
                    return false;
                }
            }else{
                return false;
            }
                
        }
        
        
        /**
         * This is the function that confirms if the previoue rejected partnership request was successfuly removed
         */
        public function isAPreviouslyRejectedRequestRemoved($domain_id,$target_domain_id){
            
            if($this->isExistARejectedPartnershipRequestBetweenTwoDomains($domain_id,$target_domain_id)){
                return true;
            }else if($this->isExistARejectedPartnershipRequestBetweenTwoDomains($target_domain_id,$domain_id)){
                return true;
            }else{
                return false;
            }
             
        }
        
        
        /**
         * This is the function that confirms if there exist a rejected partnership request
         */
        public function isExistARejectedPartnershipRequestBetweenTwoDomains($domain_id,$target_domain_id){
            if($this->isRejectedRequestForPartnershipExists($domain_id,$target_domain_id)){
                $cmd =Yii::app()->db->createCommand();  
                $result = $cmd->delete('domain_has_partners','(domain_id=:domainid and partner_id=:partnerid) and request=:request', array(':domainid'=>$domain_id,':partnerid'=>$target_domain_id,':request'=>"rejected"));
            
                if($result>0){
                    return true;
                    
                }else{
                    return false;
                }   
            }else if($this->isRejectedRequestForPartnershipExists($target_domain_id,$domain_id)){
               $cmd =Yii::app()->db->createCommand();  
                $result = $cmd->delete('domain_has_partners','(domain_id=:domainid and partner_id=:partnerid) and request=:request', array(':domainid'=>$target_domain_id,':partnerid'=>$domain_id,':request'=>"rejected"));
            
                if($result>0){
                    return true;
                    
                }else{
                    return false;
                }   
            }else{
                return true;
            }
                
                
             
        }
        
        
        
        /**
         * This is the function that confirms if a rejected request for partnership exist between two domains
         */
        public function isRejectedRequestForPartnershipExists($domain_id,$target_domain_id){
            
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('domain_has_partners')
                    ->where("(domain_id = $domain_id and partnet_id=$target_domain_id) and request='rejected'");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
        }
        
        /**
         * This is the function tat confirms the success of the rejection of partnership request
         */
        public function isTheRejectionOfThisPartnershipRequestASuccess($domain_id,$target_domain_id){
            
             if($this->isThisPartnershipRequestPending($domain_id,$target_domain_id)){
                     $cmd =Yii::app()->db->createCommand();
                     $result = $cmd->insert('domain_has_partners',
                                  array(
                                    'domain_id'=>$domain_id,
                                    'partner_id'=>$target_domain_id,
                                    'request'=>"rejected",   
                                    
                                  )
			
                        );
                if($result>0){
                    return true;
                }else{
                    return false;
                }
                    
                }else{
                    return false;
                }           
               
            
        }
        
        /**
         * This is the function that confirms if a pernership request still pending
         */
        public function isThisPartnershipRequestPending($domain_id,$target_domain_id){
            
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('domain_has_partners')
                    ->where("(domain_id = $domain_id and partnet_id=$target_domain_id) and request='pending'");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
        /**
         * This is the function that confirms the acceptance of a partnership request
         */
        public function isTheAcceptanceOfThisPartnershipRequestASuccess($requester_domain,$target_domain){
            
            if($this->isThisPartnershipRequestPending($domain_id,$target_domain_id)){
                     $cmd =Yii::app()->db->createCommand();
                     $result = $cmd->insert('domain_has_partners',
                                  array(
                                    'domain_id'=>$domain_id,
                                    'partner_id'=>$target_domain_id,
                                    'request'=>"accepted",   
                                    
                                  )
			
                        );
                if($result>0){
                    return true;
                }else{
                    return false;
                }
                    
                }else{
                    return false;
                }      
        }
}
