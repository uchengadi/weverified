<?php
class RbacDocumentCommand extends CConsoleCommand
{
   
    private $_authManager;
 
    
	public function getHelp()
	{
		
		$description = "DESCRIPTION\n";
		$description .= '    '."This command generates an initial RBAC authorization hierarchy.\n";
		return parent::getHelp() . $description;
	}

	
	/**
	 * The default action - create the RBAC structure.
	 */
	public function actionIndex()
	{
		 
		$this->ensureAuthManagerDefined();
		
		//provide the oportunity for the use to abort the r$message = "This command will create 13"
        $message = " This will create operations, task and  roles for the platform.";
		$message .= "Would you like to continue?";
	    
	    //check the input from the user and continue if 
		//they indicated yes to the above question
	    if($this->confirm($message)) 
		{
		     //first we need to remove all operations, 
			 //roles, child relationship and assignments
			 $this->_authManager->clearAll();

			 //create the lowest level operations for groups
			 $this->_authManager->createOperation(
				"createCity",
				"create a new city"); 
			 $this->_authManager->createOperation(
				"readCity",
				"read city information"); 
			 $this->_authManager->createOperation(
				"updateCity",
				"update a city information"); 
			 $this->_authManager->createOperation(
				"deleteCity",
				"remove a city from the system"); 

			 //create the lowest level operations for users
			 $this->_authManager->createOperation(
				"createUser",
				"create a new user"); 
			 $this->_authManager->createOperation(
				"readUser",
				"read user information"); 
	 		 $this->_authManager->createOperation(
				"updateUser",
				"update user information"); 
			 $this->_authManager->createOperation(
				"deleteUser",
				"delete a user from the system"); 

			 //create the lowest level operations for user types
			 $this->_authManager->createOperation(
				"createUsertype",
				"create a new usertype"); 
			 $this->_authManager->createOperation(
				"readUsertype",
				"read usertype information"); 
			 $this->_authManager->createOperation(
				"updateUsertype",
				"update usertype information"); 
			 $this->_authManager->createOperation(
				"deleteUsertype",
				"delete a usertype from the system");   
                         
                         //create the lowest level operations for state
                          $this->_authManager->createOperation(
				"createState",
				"create a new state"); 
			 $this->_authManager->createOperation(
				"readState",
				"read state information"); 
			 $this->_authManager->createOperation(
				"updateState",
				"update state information"); 
			 $this->_authManager->createOperation(
				"deleteState",
				"delete a state from the project");   
                         
                         //create the lowest level operations for country
                          $this->_authManager->createOperation(
				"createCountry",
				"create a new country"); 
			 $this->_authManager->createOperation(
				"readCountry",
				"read country information"); 
			 $this->_authManager->createOperation(
				"updateCountry",
				"update country information"); 
			 $this->_authManager->createOperation(
				"deleteCountry",
				"delete a country from the system");   
                         
                         //create the lowest level operations for grouptype
                          $this->_authManager->createOperation(
				"createGrouptype",
				"create a new grouptype"); 
			 $this->_authManager->createOperation(
				"readGrouptype",
				"read grouptype information"); 
			 $this->_authManager->createOperation(
				"updateGrouptype",
				"update grouptype information"); 
			 $this->_authManager->createOperation(
				"deleteGrouptype",
				"delete a grouptype from the system");   
                         
                         
                         //create the lowest level operations for group
                          $this->_authManager->createOperation(
				"createGroup",
				"create a new group"); 
			 $this->_authManager->createOperation(
				"readGroup",
				"read group information"); 
			 $this->_authManager->createOperation(
				"updateGroup",
				"update group information"); 
			 $this->_authManager->createOperation(
				"deleteGroup",
				"delete a group from the system");   
                                     
                        
                //create the lowest level operations for containers
                          $this->_authManager->createOperation(
				"createContainer",
				"create a new resource type container"); 
			 $this->_authManager->createOperation(
				"readContainer",
				"read container information"); 
			 $this->_authManager->createOperation(
				"updateContainer",
				"update container information"); 
			 $this->_authManager->createOperation(
				"deleteContainer",
				"delete a container from the system");  
                         
                         //create the lowest level operations for Device Type
                          $this->_authManager->createOperation(
				"createDevicetype",
				"create a new devicetype"); 
			 $this->_authManager->createOperation(
				"readDevicetype",
				"read devicetype information"); 
			 $this->_authManager->createOperation(
				"updateDevicetype",
				"update devicetype information"); 
			 $this->_authManager->createOperation(
				"deleteDevicetype",
				"delete a devicetype from the system");   
                         
                         //create the lowest level operations for Device
                          $this->_authManager->createOperation(
				"createDevice",
				"create a new device"); 
			 $this->_authManager->createOperation(
				"readDevice",
				"read device information"); 
			 $this->_authManager->createOperation(
				"updateDevice",
				"update device information"); 
			 $this->_authManager->createOperation(
				"deleteDevice",
				"delete a device from the system"); 
                 
				                        
                //create the lowest level operations for Resource group category
                          $this->_authManager->createOperation(
				"createNewCategoryOrDomain",
				"create a new Toolbox domain  category"); 
			 $this->_authManager->createOperation(
				"readCategoryOrDomain",
				"read resourcegroup category information"); 
			 $this->_authManager->createOperation(
				"updateCategoryOrDomain",
				"update resourcegroup category information"); 
			 $this->_authManager->createOperation(
				"deleteCategoryOrDomain",
				"delete a resourcegroup category from the system");   
                         
                         
                         //create the lowest level operations for Documenttype
                          $this->_authManager->createOperation(
				"createNewDocumenttype",
				"create a new documenttype"); 
			 $this->_authManager->createOperation(
				"readDocumenttype",
				"read documenttype information"); 
			 $this->_authManager->createOperation(
				"updateDocumenttype",
				"update documenttype information"); 
			 $this->_authManager->createOperation(
				"deleteDocumenttype",
				"delete a documenttype from the system");   
                        
                         
                         //create the lowest level operations for Subgroup
                          $this->_authManager->createOperation(
				"createSubgroup",
				"create a new subgroup"); 
			 $this->_authManager->createOperation(
				"readSubgroup",
				"read subgroup information"); 
			 $this->_authManager->createOperation(
				"updateSubgroup",
				"update subgroup information"); 
			 $this->_authManager->createOperation(
				"deleteSubgroup",
				"delete a subgroup from the system"); 
                       
                         
                         
             //create the lowest level operations for folder
             $this->_authManager->createOperation(
				"createNewFolder",
				"create a new folder"); 
			 $this->_authManager->createOperation(
				"readFolder",
				"read folder information"); 
			 $this->_authManager->createOperation(
				"updateFolder",
				"update folder information"); 
			 $this->_authManager->createOperation(
				"deleteFolder",
				"delete a folder from the system"); 
                        
                         
                         
              //create the lowest level operations for files and documents
                         $this->_authManager->createOperation(
				"createNewFile",
				"this is the privilege that enables the creation of files"); 
			 $this->_authManager->createOperation(
				"createNewDocument",
				"this is the privilege that enables the creation of documents"); 
			 $this->_authManager->createOperation(
				"updateFileAndDocument",
				"this is the privilege that enables the update of files and documents"); 
			 $this->_authManager->createOperation(
				"deleteFileAndDocument",
				"this is the privilege that enables the removal of files and documents");
                         $this->_authManager->createOperation(
				"readFileAndDocument",
				"this is the privilege that enables the ability to read files and documents"); 
			
		//creates the lowest level operations for  user_to_subgroup assignment
			$this->_authManager->createOperation(
				"assignBulkUsersToSubgroup",
				"this is the privilege that enables the bulk assignment of users to subgroup"); 
			 $this->_authManager->createOperation(
				"assignSingleUserToSubgroup",
				"this is the privilege that enables the single assignment of user to subgroup"); 
			 $this->_authManager->createOperation(
				"deleteAssignedUserFromSubgroup",
				"this is the privilege that enables the removal of assigned users from subgroup"); 
                         $this->_authManager->createOperation(
				"updateAssignedUserInSubgroup",
				"this is the privilege that enables the update of assigned user to subgroup information"); 
			 $this->_authManager->createOperation(
				"readAssignedUserSubgroup",
				"this is the privilege that enables the ability to read assigned users in subgroup");     		


			//creates the lowest level operations for  folders_to_Domain assignment
			$this->_authManager->createOperation(
				"assignBulkFolderToDomainOrCategory",
				"this is the privilege that enables the bulk assignment of folders to a domain"); 
			 $this->_authManager->createOperation(
				"assignSingleFolderToDomainOrCategory",
				"this is the privilege that enables the single assignment of a folder to a category"); 
			 $this->_authManager->createOperation(
				"deleteAssignedFolderInDomainOrCategory",
				"this is the privilege that enables the removal of assigned folders from domain"); 
                         $this->_authManager->createOperation(
				"updateAssignedFolderInDomainOrCategory",
				"this is the privilege that enables the update of assigned folders to domain information"); 
			 $this->_authManager->createOperation(
				"readAssignedFolderToDomainOrCategory",
				"this is the privilege that enables the ability to read assigned folders in domain");     


			
			//creates the lowest level operations for  files_to_folder assignment
			$this->_authManager->createOperation(
				"assignBulkFilesToFolder",
				"this is the privilege that enables the bulk assignment of files to a folder"); 
			 $this->_authManager->createOperation(
				"assignSingleFileToFolder",
				"this is the privilege that enables the single assignment of file to a folder"); 
			 $this->_authManager->createOperation(
				"deleteAssignedFileFromFolder",
				"this is the privilege that enables the removal of assigned file from folder"); 
                         $this->_authManager->createOperation(
				"updateAssignedFilesInFolder",
				"this is the privilege that enables the update of assigned file to folder information"); 
			 $this->_authManager->createOperation(
				"readAssignedFilesInFolder",
				"this is the privilege that enables the ability to read assigned files in folder");    	
				
				
				
				//creates the lowest level operations for  folder_to_group assignment
			$this->_authManager->createOperation(
				"assignBulkFoldersToGroup",
				"this is the privilege that enables the bulk assignment of folder to a group"); 
			 $this->_authManager->createOperation(
				"assignSingleFolderToGroup",
				"this is the privilege that enables the single assignment of folder to group"); 
			 $this->_authManager->createOperation(
				"deleteAssignedFolderFromGroup",
				"this is the privilege that enables the removal of assigned folder from a group"); 
                         $this->_authManager->createOperation(
				"updateAssignedFolderToGroup",
				"this is the privilege that enables the update of assigned folder to group information"); 
			 $this->_authManager->createOperation(
				"readAssignedFoldersToGroup",
				"this is the privilege that enables the ability to read assigned folder in group");    
				
				
				
				//creates the lowest level operations for  folder_to_subgroup assignment
			$this->_authManager->createOperation(
				"assignBulkFoldersToSubgroup",
				"this is the privilege that enables the bulk assignment of folder to a subgroup"); 
			 $this->_authManager->createOperation(
				"assignSingleFolderToSubgroup",
				"this is the privilege that enables the single assignment of folder to subgroup"); 
			 $this->_authManager->createOperation(
				"deleteAssignedFolderFromSubgroup",
				"this is the privilege that enables the removal of assigned folder from a subgroup"); 
                         $this->_authManager->createOperation(
				"updateAssignedFolderToSubgroup",
				"this is the privilege that enables the update of assigned folder to subgroup information"); 
			 $this->_authManager->createOperation(
				"readAssignedFoldersToSubgroup",
				"this is the privilege that enables the ability to read assigned folder in subgroup");    
				
				
				
				//creates the lowest level operations for  folder_to_user assignment
			$this->_authManager->createOperation(
				"assignBulkFoldersToUser",
				"this is the privilege that enables the bulk assignment of folder to a user"); 
			 $this->_authManager->createOperation(
				"assignSingleFolderToUser",
				"this is the privilege that enables the single assignment of folder to user"); 
			 $this->_authManager->createOperation(
				"deleteAssignedFolderToUser",
				"this is the privilege that enables the removal of assigned folder from user"); 
                         $this->_authManager->createOperation(
				"updateAssignedFolderToUser",
				"this is the privilege that enables the update of assigned folder to user information"); 
			 $this->_authManager->createOperation(
				"readAssignedFoldersToUser",
				"this is the privilege that enables the ability to read assigned folder in user");    
								
				
				
				//creates the lowest level operations for  user_in_subgroup scheduling
			$this->_authManager->createOperation(
				"scheduleBulkUsersInSubgroup",
				"this is the privilege that enables the bulk scheduling of users in subgroup"); 
			 $this->_authManager->createOperation(
				"scheduleSingleUserInSubgroup",
				"this is the privilege that enables the single scheduling of users in subgroup"); 
				
				
			//creates the lowest level operations for  folder_in_category scheduling	
			 $this->_authManager->createOperation(
				"scheduleBulkFoldersInCategoryOrDomain",
				"this is the privilege that enables the bulk scheduling of folders in a domain"); 
                         $this->_authManager->createOperation(
				"scheduleSingleFolderInCategoryOrDomain",
				"this is the privilege that enables the single scheduling of folder in a domain"); 
				
				
				
				//creates the lowest level operations for  file_in_folder scheduling	
			 $this->_authManager->createOperation(
				"scheduleBulkFilesInFolder",
				"this is the privilege that enables the bulk scheduling of files in a folder"); 
                         $this->_authManager->createOperation(
				"scheduleSingleFileInFolder",
				"this is the privilege that enables the single scheduling of file in a folder"); 
				
				
				//creates the lowest level operations for  folder_in_group scheduling	
			 $this->_authManager->createOperation(
				"scheduleBulkFoldersInGroup",
				"this is the privilege that enables the bulk scheduling of folder in a group"); 
                         $this->_authManager->createOperation(
				"scheduleSingleFolderInGroup",
				"this is the privilege that enables the single scheduling of folder in a group"); 
				
				
				
				//creates the lowest level operations for  folder_in_subgroup scheduling	
			 $this->_authManager->createOperation(
				"scheduleBulkFoldersInSubgroup",
				"this is the privilege that enables the bulk scheduling of folder in a subgroup"); 
                         $this->_authManager->createOperation(
				"scheduleSingleFolderInSubgroup",
				"this is the privilege that enables the single scheduling of folder in a subgroup"); 
				
				
				
				//creates the lowest level operations for  folder_in_user scheduling	
			 $this->_authManager->createOperation(
				"scheduleBulkFolderForUser",
				"this is the privilege that enables the bulk scheduling of folder in a user"); 
                         $this->_authManager->createOperation(
				"scheduleSingleFolderForUser",
				"this is the privilege that enables the single scheduling of folder in a user");
			 
			 
			  
			//creates the lowest level operations for role privileges
			$this->_authManager->createOperation(
				"createNewRole",
				"this is the privilege that enables the creation of a new role"); 
			 $this->_authManager->createOperation(
				"deleteRole",
				"this is the privilege that enables the removal of a role from the system"); 
            $this->_authManager->createOperation(
				"updateRole",
				"this is the privilege that enables the update of a role"); 
			 $this->_authManager->createOperation(
				"assignPrivilegesToRole",
				"this is the privilege that enables the ability to assigned privilege to role");    
				
				
				
				
				//creates the lowest level operations for task privileges
			$this->_authManager->createOperation(
				"createNewTask",
				"this is the privilege that enables the creation of a new task"); 
			 $this->_authManager->createOperation(
				"deleteTask",
				"this is the privilege that enables the removal of a task from the system"); 
            $this->_authManager->createOperation(
				"updateTask",
				"this is the privilege that enables the update of a task"); 
			 $this->_authManager->createOperation(
				"assignPrivilegesToTask",
				"this is the privilege that enables the ability to assigned privilege to task");    
				
				
				
				//creates the lowest level operations for user authorisation privileges
			$this->_authManager->createOperation(
				"performUserAuthorisation",
				"this is the privilege that enables the ability to perform user authorisation"); 
			 $this->_authManager->createOperation(
				"deleteUserAuthorisation",
				"this is the privilege that enables the removal of a user authorisation from the system"); 
            $this->_authManager->createOperation(
				"updateBusinessRulesAndData",
				"this is the privilege that enables the update of a business rule and data"); 
			 $this->_authManager->createOperation(
				"createBusinessRulesAndData",
				"this is the privilege that enables the ability to create business rules and data");    
				
				
				
				//creates the lowest level operations for privileges
			$this->_authManager->createOperation(
				"createNewPrivilege",
				"this is the privilege that enables the creation of a new privilege"); 
			 $this->_authManager->createOperation(
				"deletePrivilege",
				"this is the privilege that enables the removal of a privilege from the system"); 
            $this->_authManager->createOperation(
				"updatePrivilege",
				"this is the privilege that enables the update of a privilege");
            $this->_authManager->createOperation(
				"createNewDocumentCategory",
				"this is the privilege that confers the ability to create new document type"); 
            $this->_authManager->createOperation(
				"updateDocumentCategory",
				"this is the privilege that confers the ability to update document category information"); 
            $this->_authManager->createOperation(
				"deleteDocumentCategory",
				"this is the privilege that confers the ability to remove document category from that platform");
            $this->_authManager->createOperation(
				"readDocumentCategory",
				"this is the privilege that confers the ability to read document category information from the database"); 
            $this->_authManager->createOperation(
				"createNewFileDuplicate",
				"this is the privilege that confers the ability to create new file duplicates");
            $this->_authManager->createOperation(
				"updateFileDuplicate",
				"this is the privilege that confers the ability to update file duplicate information");
            $this->_authManager->createOperation(
				"deleteFileDuplicate",
				"this is the privilege that confers the ability to remove file duplicate information from the platform");
            $this->_authManager->createOperation(
				"readFileDuplicate",
				"this is the privilege that confers the ability to read file duplicate information from the database");
            $this->_authManager->createOperation(
				"createNewFolderDuplicate",
				"this is the privilege that confers the ability to create new folder duplicate");
            $this->_authManager->createOperation(
				"updateFolderDuplicate",
				"this is the privilege that confers the ability to update folder duplicate information");
            $this->_authManager->createOperation(
				"deleteFolderDuplicate",
				"this is the privilege that confers the ability to remove folder duplicate information from the platform");
            $this->_authManager->createOperation(
				"readFolderDuplicate",
				"this is the privilege that confers the ability to read folder duplicate information from the platform");
            $this->_authManager->createOperation(
				"removeFileFromDuplicateFolders",
				"this is the privilege that confers the ability to remove files from duplicate folders");
            $this->_authManager->createOperation(
				"createNewAnnouncement",
				"this is the privilege that confers the ability to create new announcement");
            $this->_authManager->createOperation(
				"updateAnnouncement",
				"this is the privilege that confers the ability to update announcement information");
            $this->_authManager->createOperation(
				"deleteAnnouncement",
				"this is the privilege that confers the ability to delete announcement information");
            $this->_authManager->createOperation(
				"readAnnouncement",
				"this is the privilege that confers the ability to read announcement information from the database");
            $this->_authManager->createOperation(
				"readNeed",
				"this is the privilege that confers the ability to read Need information");
            $this->_authManager->createOperation(
				"deleteNeed",
				"this is the privilege that confers the ability to delete Need information");
            $this->_authManager->createOperation(
				"viewNeed",
				"this is the privilege that confers the ability to view Need information");
            $this->_authManager->createOperation(
				"readWish",
				"this is the privilege that confers the ability to read Wish information");
            $this->_authManager->createOperation(
				"viewWish",
				"this is the privilege that confers the ability to view Wish information");
            $this->_authManager->createOperation(
				"deleteWish",
				"this is the privilege that confers the ability to delete wish information");
            $this->_authManager->createOperation(
				"createNewDomainPolicy",
				"this is the privilege that confers the ability to create new domain policy");
            $this->_authManager->createOperation(
				"updateDomainPolicy",
				"this is the privilege that confers the ability to update domain policy information");
            $this->_authManager->createOperation(
				"deleteDomainPolicy",
				"this is the privilege that confers the ability to delete domain policy");
            $this->_authManager->createOperation(
				"readDomainPolicy",
				"this is the privilege that confers the ability to read domain policy");
            $this->_authManager->createOperation(
				"createNewTimezone",
				"this is the privilege that confers the ability to create new timezone");
            $this->_authManager->createOperation(
				"updateTimezone",
				"this is the privilege that confers the ability to update timezone information");
            $this->_authManager->createOperation(
				"deleteTimezone",
				"this is the privilege that confers the ability to delete timezone information");
            $this->_authManager->createOperation(
				"readTimezone",
				"this is the privilege that confers the ability to read timezone information");
            $this->_authManager->createOperation(
				"createNewCurrency",
				"this is the privilege that confers the ability to create new currency");
            $this->_authManager->createOperation(
				"updateCurrency",
				"this is the privilege that confers the ability to update currency information");
            $this->_authManager->createOperation(
				"deleteCurrency",
				"this is the privilege that confers the ability to delete currency");
            $this->_authManager->createOperation(
				"readCurrency",
				"this is the privilege that confers the ability to read currency information");
            $this->_authManager->createOperation(
				"createNewPlatformSettings",
				"this is the privilege that confers the ability to create new platform settings");
            $this->_authManager->createOperation(
				"updatePlatformSettings",
				"this is the privilege that confers the ability to update platform settings information");
            $this->_authManager->createOperation(
				"readPlatformSettings",
				"this is the privilege that confers the ability to read platform settings information");
            $this->_authManager->createOperation(
				"deletePlatformSettings",
				"this is the privilege that confers the ability to delete platform settings information");
            $this->_authManager->createOperation(
				"createNewStoreParameters",
				"this is the privilege that confers the ability to create new store parameters");
            $this->_authManager->createOperation(
				"updateStoreParameters",
				"this is the privilege that confers the ability to update store parameters");
            $this->_authManager->createOperation(
				"deleteStoreParameters",
				"this is the privilege that confers the ability to delete store parameters");
            $this->_authManager->createOperation(
				"readStoreParameters",
				"this is the privilege that confers the ability to read store parameters");
            $this->_authManager->createOperation(
				"createNewCurrencyExchange",
				"this is the privilege that confers the ability to create new currency exchange");
            $this->_authManager->createOperation(
				"updateCurrencyExchange",
				"this is the privilege that confers the ability to update currency exchange");
            $this->_authManager->createOperation(
				"deleteCurrencyExchange",
				"this is the privilege that confers the ability to delete currency exchange");
            $this->_authManager->createOperation(
				"readCurrencyExchange",
				"this is the privilege that confers the ability to read currency exchange");
            $this->_authManager->createOperation(
				"modifyPartnershipStatus",
				"this is the privilege that confers the ability to modify partnership status");
            $this->_authManager->createOperation(
				"deletePartnership",
				"this is the privilege that confers the ability to delete partnership");
            $this->_authManager->createOperation(
				"accessPartnerInlineStore",
				"this is the privilege that confers the ability to access partner inline store");
            $this->_authManager->createOperation(
				"readDomainPartners",
				"this is the privilege that confers the ability to read domain partners");
            $this->_authManager->createOperation(
				"createNewNetwork",
				"this is the privilege that confers the ability to create new networks");
            $this->_authManager->createOperation(
				"modifyNetwork",
				"this is the privilege that confers the ability to update network information");
            $this->_authManager->createOperation(
				"assignFolderToNetwork",
				"this is the privilege that confers the ability to assign folder to network");
            $this->_authManager->createOperation(
				"deleteNetwork",
				"this is the privilege that confers the ability to delete network");
            $this->_authManager->createOperation(
				"addFolderToNetwork",
				"this is the privilege that confers the ability to add folder to network");
            $this->_authManager->createOperation(
				"modifyFolderStatusInNetwork",
				"this is the privilege that confers the ability to modify folder status in a network");
            $this->_authManager->createOperation(
				"removeFolderFromNetwork",
				"this is the privilege that confers the ability to remove folder from a network");
            $this->_authManager->createOperation(
				"readFolderInNetwork",
				"this is the privilege that confers the ability to read folder in a network");
            $this->_authManager->createOperation(
				"removeAMemberFromNetwork",
				"this is the privilege that confers the ability to remove a member from a network");
            $this->_authManager->createOperation(
				"addingFolderToAnotherDomainNetwork",
				"this is the privilege that confers the ability to add folder to another domain network");
            $this->_authManager->createOperation(
				"removeFolderFromNetworkConnection",
				"this is the privilege that confers the ability to remove folder from network connection");
            $this->_authManager->createOperation(
				"initiateNewPartnership",
				"this is the privilege that confers the ability to initiate new partnership");
            $this->_authManager->createOperation(
				"updatePartnershipInfo",
				"this is the privilege that confers the ability to update partnership info");
            $this->_authManager->createOperation(
				"deletePendingDomainToPartnershipRequest",
				"this is the privilege that confers the ability to delete any pending domain to a partner request");
            $this->_authManager->createOperation(
				"readDomainToPartnerRequest",
				"this is the privilege that confers the ability to read domain to partner request");
            $this->_authManager->createOperation(
				"acceptOrRejectPartnerRequest",
				"this is the privilege that confers the ability to accept or reject a partner domain");
            $this->_authManager->createOperation(
				"keepRequestInView",
				"this is the privilege that confers the ability to keep a request in view");
            $this->_authManager->createOperation(
				"deletePendingPartnerToDomainRequest",
				"this is the privilege that confers the ability to delete pending partner to domain request");
            $this->_authManager->createOperation(
				"readPartnerToDomainRequest",
				"this is the privilege that confers the ability to read partner to domain request");
            $this->_authManager->createOperation(
				"initiateNewNetworkMember",
				"this is the privilege that confers the ability to initiate new network member");
            $this->_authManager->createOperation(
				"modifyNetworkMembership",
				"this is the privilege that confers the ability to modify network membership");
            $this->_authManager->createOperation(
				"removeMemberFromNetwork",
				"this is the privilege that confers the ability to remove member from Network");
            $this->_authManager->createOperation(
				"acceptOrRejectWouldBeNetworkMembership",
				"this is the privilege that confers the ability to accept or reject would be network member");
            $this->_authManager->createOperation(
				"keepNetworkMembershipInView",
				"this is the privilege that confers the ability to keep network membership in view");
            $this->_authManager->createOperation(
				"removeNetworkMembershipRequest",
				"this is the privilege that confers the ability to remove network membership request");
            $this->_authManager->createOperation(
				"readNetworkMembershipRequest",
				"this is the privilege that confers the ability to read network membership request");
            $this->_authManager->createOperation(
				"readOrders",
				"this is the privilege that confers the ability to read domain orders");
            $this->_authManager->createOperation(
				"makePaymentFromOrder",
				"this is the privilege that confers the ability to make payments from domain orders module");
            $this->_authManager->createOperation(
				"addToCartFromOrder",
				"this is the privilege that confers the ability to add to cart from domain orders module");
            $this->_authManager->createOperation(
				"updateCartContentFromOrder",
				"this is the privilege that confers the ability to update cart content from domain order module");
            $this->_authManager->createOperation(
				"removeFromCartFromOrder",
				"this is the privilege that confers the ability to remove items from the cart from the orders module");
            $this->_authManager->createOperation(
				"effectFolderServiceRenewal",
				"this is the privilege that confers the ability to effect folder service renewal");
            $this->_authManager->createOperation(
				"readDueFolderServicesForRenewal",
				"this is the privilege that confers the ability to read due services for renewal");
            $this->_authManager->createOperation(
				"readDomainReceipt",
				"this is the privilege that confers the ability to read domain receipt");
            $this->_authManager->createOperation(
				"makePaymentConfirmations",
				"this is the privilege that confers the ability to make payment confirmations");
            $this->_authManager->createOperation(
				"readUnconfirmedPayments",
				"this is the privilege that confers the ability to read unconfirmed payments");
            $this->_authManager->createOperation(
				"readInactiveFolderService",
				"this is the privilege that confers the ability to read inactive folder services");
            
            $this->_authManager->createOperation(
				"activateFolderService",
				"this is the privilege that confers the ability to activate folder service");
            $this->_authManager->createOperation(
				"readActiveFolderService",
				"this is the privilege that confers the ability to read active folder service");
            $this->_authManager->createOperation(
				"deactivateFolderService",
				"this is the privilege that confers the ability to deactivate folder service");
            $this->_authManager->createOperation(
				"viewPaymentForRemittance",
				"this is the privilege that confers the ability to view payments due for remittance");
            $this->_authManager->createOperation(
				"processPaymentForRemittance",
				"this is the privilege that confers the ability to process payment for remittance");
            $this->_authManager->createOperation(
				"deferPaymentRemittance",
				"this is the privilege that confers the ability to defer Payment for Remittance");
            $this->_authManager->createOperation(
				"includePaymentForRemittance",
				"this is the privilege that confers the ability to include payment in remittance");
            $this->_authManager->createOperation(
				"addDocumentToDuplicateFile",
				"this is the privilege that confers the ability to add document to duplicate file");
            $this->_authManager->createOperation(
				"updateDocumentInDuplicateFile",
				"this is the privilege that confers the ability to update task in duplicate file");
            $this->_authManager->createOperation(
				"removeDocumentFromDuplicateFile",
				"this is the privilege that confers the ability to remove document from duplicate file");
            $this->_authManager->createOperation(
				"addFileToDuplicateFolder",
				"this is the privilege that confers the ability to add file to duplicate folder");
            $this->_authManager->createOperation(
				"removeFileFromDuplicateFolder",
				"this is the privilege that confers the ability to remove file from duplicate folder");
            $this->_authManager->createOperation(
				"accessInlineNetworkStore",
				"this is the privilege that confers the ability to access inline network store");
		//create the platformwide supports
             $this->_authManager->createOperation(
				"platformAdmin",
				"this is the privilege that confers the ability to conduct platform-wide administration on the platform");
             $this->_authManager->createOperation(
				"platformPartnerSupport",
				"this is the privilege that confers the ability to provide support on domain partnerships");
             $this->_authManager->createOperation(
				"platformStoreSupport",
				"this is the privilege that confers the ability to provide support on all domain stores");
             $this->_authManager->createOperation(
				"platformPolicySupport",
				"this is the privilege that confers the ability to provide support on domain policies");
             $this->_authManager->createOperation(
				"platformNeedSupport",
				"this is the privilege that confers the ability to provide support on domain Needs");
             $this->_authManager->createOperation(
				"platformAnnouncementSupport",
				"this is the privilege that confers the ability to provide support on announcements");
             $this->_authManager->createOperation(
				"platformFolderDuplicationSupport",
				"this is the privilege that confers the ability to provide support on folder duplication activities");
             $this->_authManager->createOperation(
				"platformFileDuplicationSupport",
				"this is the privilege that confers the ability to provide support on file duplication activities");
             $this->_authManager->createOperation(
				"platformGroupSupport",
				"this is the privilege that confers the ability to provide support on domain groups");
             $this->_authManager->createOperation(
				"platformSubgroupSupport",
				"this is the privilege that confers the ability to provide support on domain subgroups");
             $this->_authManager->createOperation(
				"platformWishSupport",
				"this is the privilege that confers the ability to provide support on domain wishes");
             $this->_authManager->createOperation(
				"platformUserSupport",
				"this is the privilege that confers the ability to provide support on domain users");
             $this->_authManager->createOperation(
				"platformOrdersSupport",
				"this is the privilege that confers the ability to provide support on domain orders");
             $this->_authManager->createOperation(
				"platformRenewalSupport",
				"this is the privilege that confers the ability to provide support on domain renewals");
             $this->_authManager->createOperation(
				"platformPaymentConfirmationSupport",
				"this is the privilege that confers the ability to provide support on payment confirmations");
             $this->_authManager->createOperation(
				"platformFolderActivationSupport",
				"this is the privilege that confers the ability to provide support on folder activation activities");
             $this->_authManager->createOperation(
				"platformFolderDeactivationSupport",
				"this is the privilege that confers the ability to provide support on folder deactivation activities");
             $this->_authManager->createOperation(
				"platformRemittanceSupport",
				"this is the privilege that confers the ability to provide support on domain remittance");
              $this->_authManager->createOperation(
				"platformRemittanceAdmin",
				"this is the privilege that confers the ability to provide adminitration on domain remittance");
               $this->_authManager->createOperation(
				"platformFolderDeactivationAdmin",
				"this is the privilege that confers the ability to  administer folder deactivation");
               $this->_authManager->createOperation(
				"platformFolderActivationAdmin",
				"this is the privilege that confers the ability to administer folder activation");
               $this->_authManager->createOperation(
				"platformPaymentConfirmationAdmin",
				"this is the privilege that confers the ability to administer payment confirmation");
               $this->_authManager->createOperation(
				"platformRenewalAdmin",
				"this is the privilege that confers the ability to administer service renewals");
                $this->_authManager->createOperation(
				"platformOrdersAdmin",
				"this is the privilege that confers the ability to administer purchase orders");
                $this->_authManager->createOperation(
				"platformUserAdmin",
				"this is the privilege that confers the ability to administer platform users");
                $this->_authManager->createOperation(
				"platformWishAdmin",
				"this is the privilege that confers the ability to administer platform wishes");
                $this->_authManager->createOperation(
				"platformSubgroupAdmin",
				"this is the privilege that confers the ability to administer platform subgroups");
                $this->_authManager->createOperation(
				"platformGroupAdmin",
				"this is the privilege that confers the ability to administer platform groups");
                $this->_authManager->createOperation(
				"platformFileDuplicationAdmin",
				"this is the privilege that confers the ability to administer platform file duplications");
                $this->_authManager->createOperation(
				"platformFolderDuplicationAdmin",
				"this is the privilege that confers the ability to administer platform folder duplications");
                $this->_authManager->createOperation(
				"platformAnnouncementAdmin",
				"this is the privilege that confers the ability to administer platform announcements");
                $this->_authManager->createOperation(
				"platformNeedAdmin",
				"this is the privilege that confers the ability to administer platform needs");
                $this->_authManager->createOperation(
				"platformPolicyAdmin",
				"this is the privilege that confers the ability to administer platform policies");
                $this->_authManager->createOperation(
				"platformStoreAdmin",
				"this is the privilege that confers the ability to administer stores");
                $this->_authManager->createOperation(
				"platformPartnerAdmin",
				"this is the privilege that confers the ability to administer partnerships");
                $this->_authManager->createOperation(
				"platformNetworkSupport",
				"this is the privilege that confers the ability to administer domain networks");
                 $this->_authManager->createOperation(
				"changeUserPassword",
				"this is the privilege that confers the ability to change users password");
                 $this->_authManager->createOperation(
				"readFilesAndDocument",
				"this is the privilege that confers the ability to read files and documents");
                 $this->_authManager->createOperation(
				"platformPaymentConfirmation",
				"this is the privilege that confers the ability to verify payments on the platform");
                  $this->_authManager->createOperation(
				"grantSpecialPrivilegesToDomains",
				"this is the privilege that confers the ability to grant special privileges to domains");
                  $this->_authManager->createOperation(
				"activateAccountForCountry",
				"this is the privilege that confers the ability to activate accounts for country");
                  $this->_authManager->createOperation(
				"deactivateAccountForCountry",
				"this is the privilege that confers the ability to deactivate accounts for country");
                  $this->_authManager->createOperation(
				"approveAccountForCountry",
				"this is the privilege that confers the ability to approve accounts for country");
                  $this->_authManager->createOperation(
				"disapproveAccountForCountry",
				"this is the privilege that confers the ability to disapprove accounts for country");
                  $this->_authManager->createOperation(
				"assignAccountToCountry",
				"this is the privilege that confers the ability to assign accounts for country");
                  $this->_authManager->createOperation(
				"updateAssignedAccountToCountry",
				"this is the privilege that confers the ability to update assign accounts to country information");
                  $this->_authManager->createOperation(
				"addNewBankAccount",
				"this is the privilege that confers the ability to add new bank account ");
                  $this->_authManager->createOperation(
				"updateAccountNumber",
				"this is the privilege that confers the ability to update bank account ");
                  $this->_authManager->createOperation(
				"deleteAccountNumber",
				"this is the privilege that confers the ability to delete bank account ");
                  $this->_authManager->createOperation(
				"deleteAccountForCountry",
				"this is the privilege that confers the ability to remove bank account from country ");
                  $this->_authManager->createOperation(
				"readBankAccount",
				"this is the privilege that confers the ability to read bank account ");
                  $this->_authManager->createOperation(
				"createNewReport",
				"this is the privilege that confers the ability to create new reports ");
                  $this->_authManager->createOperation(
				"createReport",
				"this is the privilege that confers the ability to create new reports ");
                  $this->_authManager->createOperation(
				"deleteReport",
				"this is the privilege that confers the ability to delete reports ");
                  $this->_authManager->createOperation(
				"generateReport",
				"this is the privilege that confers the ability to generate reports ");
                  $this->_authManager->createOperation(
				"updateReport",
				"this is the privilege that confers the ability to update reports ");
                  $this->_authManager->createOperation(
				"extendCloseToExpireDocumentExpiryDate",
				"this is the privilege that confers the ability to extend the expiry date of close to expire documents");
                  $this->_authManager->createOperation(
				"viewCloseToExpireDocuments",
				"this is the privilege that confers the ability to view close to expire documents");
                  $this->_authManager->createOperation(
				"verifyExtendedCloseToExpireDocuments",
				"this is the privilege that confers the ability to verify extended close to expire documents");
                  $this->_authManager->createOperation(
				"changeExpiredDocumentsAwaitingDestructionExpiryDate",
				"this is the privilege that confers the ability to change the expiry date of expired documents awaiting destruction");
                  $this->_authManager->createOperation(
				"viewExpiredDocumentsAwaitingDestruction",
				"this is the privilege that confers the ability to view expired documents awaiting destruction");
                  
                  $this->_authManager->createOperation(
				"verifyChangedExpiredDocumentsAwaitingDestruction",
				"this is the privilege that confers the ability to verify changed expired documents awaiting destruction");
                  $this->_authManager->createOperation(
				"destroyDocuments",
				"this is the privilege that confers the ability to destroy documents");
                  $this->_authManager->createOperation(
				"verifyDomainDocumentDestruction",
				"this is the privilege that confers the ability to verify domain document destruction");
                  $this->_authManager->createOperation(
				"checkPlatformwideDocumentDestruction",
				"this is the privilege that confers the ability to check platform-wide document destruction");
                  
                  $this->_authManager->createOperation(
				"platformwideDocumentDestructionCheckerVerifier",
				"this is the privilege that confers the ability to conduct the verification of checked platform-wide document destruction");
                  $this->_authManager->createOperation(
				"removeTheDestroyedDocumentSoftCopy",
				"this is the privilege that confers the ability to remove the soft copy of the destroyed documents");
                  
                  $this->_authManager->createOperation(
				"verifyTheDomainRemovalOfDestroyedDocumentSoftCopy",
				"this is the privilege that confers the ability to verify the domain removal of the soft copy of the destroyed documents");
                  
                  $this->_authManager->createOperation(
				"checkPlatformwideRemovalOfDestroyedDocumentSoftCopy",
				"this is the privilege that confers the ability to check platform-wide removal of the soft copy of the destroyed documents");
                  $this->_authManager->createOperation(
				"verifyTheCheckedPlatformwideRemovalOfDestroyedSoftCopy",
				"this is the privilege that confers the ability to verify the checked platform-wide removal of the soft copy of the destroyed documents");
                   $this->_authManager->createOperation(
				"viewCurrentDocumentHolder",
				"this is the privilege that confers the ability to view current physical document holder");
                   $this->_authManager->createOperation(
				"viewCurrentPhysicalDocumentAttributes",
				"this is the privilege that confers the ability to view the current physical document attributes");
                   $this->_authManager->createOperation(
				"confirmBoxOrFolderStorageOrArchiving",
				"this is the privilege that confers the ability to confirm that boxes or folders had been stored or archived");
                   $this->_authManager->createOperation(
				"checkAllConfirmedBoxOrFolderStorageOrArchiving",
				"this is the privilege that confers the ability to check all confirmed boxes or folders that had been stored or archived");
                   $this->_authManager->createOperation(
				"verifyAllCheckBoxOrFolderStorageOrArchiving",
				"this is the privilege that confers the ability to verify all checked boxes or folders that had been stored or archived");
		
			 
            //create all the task security module
			$generalToolsAndTaskManager=$this->_authManager->createTask("filesAndDocumentManager");
                        $generalToolsAndTaskManager->addChild('createNewFile');
                        $generalToolsAndTaskManager->addChild('createNewDocument');
                        $generalToolsAndTaskManager->addChild('updateFileAndDocument');
                        $generalToolsAndTaskManager->addChild('deleteFileAndDocument');
                        $generalToolsAndTaskManager->addChild('readFileAndDocument');
       
			$userToSubgroupAssignmentManager=$this->_authManager->createTask("userToSubgroupAssignmentManager");
                        $userToSubgroupAssignmentManager->addChild('assignBulkUsersToSubgroup');
                        $userToSubgroupAssignmentManager->addChild('assignSingleUserToSubgroup');
                        $userToSubgroupAssignmentManager->addChild('deleteAssignedUserFromSubgroup');
                        $userToSubgroupAssignmentManager->addChild('readAssignedUserSubgroup');
                        $userToSubgroupAssignmentManager->addChild('updateAssignedUserInSubgroup');
                        
			$toolboxToCategoryAssignmentManager=$this->_authManager->createTask("folderToCategoryAssignmentManager");
                        $toolboxToCategoryAssignmentManager->addChild('assignBulkFolderToDomainOrCategory');
                        $toolboxToCategoryAssignmentManager->addChild('assignSingleFolderToDomainOrCategory');
                        $toolboxToCategoryAssignmentManager->addChild('deleteAssignedFolderInDomainOrCategory');
                        $toolboxToCategoryAssignmentManager->addChild('updateAssignedFolderInDomainOrCategory');
                        $toolboxToCategoryAssignmentManager->addChild('readAssignedFolderToDomainOrCategory');
                        
			$toolsToToolboxAssignmentManager=$this->_authManager->createTask("filesToFolderAssignmentManager");
                        $toolsToToolboxAssignmentManager->addChild('assignBulkFilesToFolder');
                        $toolsToToolboxAssignmentManager->addChild('assignSingleFileToFolder');
                        $toolsToToolboxAssignmentManager->addChild('deleteAssignedFileFromFolder');
                        $toolsToToolboxAssignmentManager->addChild('updateAssignedFilesInFolder');
                        $toolsToToolboxAssignmentManager->addChild('readAssignedFilesInFolder');
                        
			$toolboxToGroupAssignmentManager=$this->_authManager->createTask("folderToGroupAssignmentManager");
                        $toolboxToGroupAssignmentManager->addChild('assignBulkFoldersToGroup');
                        $toolboxToGroupAssignmentManager->addChild('assignSingleFolderToGroup');
                        $toolboxToGroupAssignmentManager->addChild('deleteAssignedFolderFromGroup');
                        $toolboxToGroupAssignmentManager->addChild('updateAssignedFolderToGroup');
                        $toolboxToGroupAssignmentManager->addChild('readAssignedFoldersToGroup');
                        
			$toolboxToSubgroupAssignmentManager=$this->_authManager->createTask("folderToSubgroupAssignmentManager");
                        $toolboxToSubgroupAssignmentManager->addChild('assignBulkFoldersToSubgroup');
                        $toolboxToSubgroupAssignmentManager->addChild('assignSingleFolderToSubgroup');
                        $toolboxToSubgroupAssignmentManager->addChild('deleteAssignedFolderFromSubgroup');
                        $toolboxToSubgroupAssignmentManager->addChild('updateAssignedFolderToSubgroup');
                        $toolboxToSubgroupAssignmentManager->addChild('readAssignedFoldersToSubgroup');
                        
			$toolboxToUserAssignmentManager=$this->_authManager->createTask("folderToUserAssignmentManager");
                        $toolboxToUserAssignmentManager->addChild('assignBulkFoldersToUser');
                        $toolboxToUserAssignmentManager->addChild('assignSingleFolderToUser');
                        $toolboxToUserAssignmentManager->addChild('deleteAssignedFolderToUser');
                        $toolboxToUserAssignmentManager->addChild('updateAssignedFolderToUser');
                        $toolboxToUserAssignmentManager->addChild('readAssignedFoldersToUser');
                        
			$userToSubgroupSchedulingManager=$this->_authManager->createTask("userToSubgroupSchedulingManager");
                        $userToSubgroupSchedulingManager->addChild('scheduleBulkUsersInSubgroup');
                        $userToSubgroupSchedulingManager->addChild('scheduleSingleUserInSubgroup');
                        
			$toolboxToCategorySchedulingManager=$this->_authManager->createTask("folderToCategorySchedulingManager");
                        $toolboxToCategorySchedulingManager->addChild('scheduleBulkFoldersInCategoryOrDomain');
                        $toolboxToCategorySchedulingManager->addChild('scheduleSingleFolderInCategoryOrDomain');
                        
			$toolsInToolboxSchedulingManager=$this->_authManager->createTask("filesInFolderSchedulingManager");
                        $toolsInToolboxSchedulingManager->addChild('scheduleBulkFilesInFolder');
                        $toolsInToolboxSchedulingManager->addChild('scheduleSingleFileInFolder');
                        
			$toolboxToGroupSchedulingManager=$this->_authManager->createTask("folderToGroupSchedulingManager");
                        $toolboxToGroupSchedulingManager->addChild('scheduleBulkFoldersInGroup');
                        $toolboxToGroupSchedulingManager->addChild('scheduleSingleFolderInGroup');
                        
			$toolboxToSubgroupSchedulingManager=$this->_authManager->createTask("folderToSubgroupSchedulingManager");
                        $toolboxToSubgroupSchedulingManager->addChild('scheduleBulkFoldersInSubgroup');
                        $toolboxToSubgroupSchedulingManager->addChild('scheduleSingleFolderInSubgroup');
                        
			$toolboxToUserSchedulingManager=$this->_authManager->createTask("folderToUserSchedulingManager");
                        $toolboxToUserSchedulingManager->addChild('scheduleBulkFolderForUser');
                        $toolboxToUserSchedulingManager->addChild('scheduleSingleFolderForUser');
                        
			$userManager=$this->_authManager->createTask("userManager");
                        $userManager->addChild('createUser');
                        $userManager->addChild('deleteUser');
                        $userManager->addChild('readUser');
                        $userManager->addChild('updateUser');
                        
			$usertypeManager=$this->_authManager->createTask("usertypeManager");
                        
			$countryManager=$this->_authManager->createTask("countryManager");
                        $countryManager->addChild('createCountry');
                        $countryManager->addChild('deleteCountry');
                        $countryManager->addChild('readCountry');
                        $countryManager->addChild('updateCountry');
                        
			$stateManager=$this->_authManager->createTask("stateManager");
                        $stateManager->addChild('createState');
                        $stateManager->addChild('deleteState');
                        $stateManager->addChild('readState');
                        $stateManager->addChild('updateState');
                        
			$cityManager=$this->_authManager->createTask("cityManager");
                        $cityManager->addChild('createCity');
                        $cityManager->addChild('deleteCity');
                        $cityManager->addChild('readCity');
                        $cityManager->addChild('updateCity');
                        
			$grouptypeManager=$this->_authManager->createTask("grouptypeManager");
                        
			$groupManager=$this->_authManager->createTask("groupManager");
                        $groupManager->addChild('createGroup');
                        $groupManager->addChild('deleteGroup');
                        $groupManager->addChild('readGroup');
                        $groupManager->addChild('updateGroup');
                        
			$subgroupManager=$this->_authManager->createTask("subgroupManager");
                        $subgroupManager->addChild('createSubgroup');
                        $subgroupManager->addChild('deleteSubgroup');
                        $subgroupManager->addChild('readSubgroup');
                        $subgroupManager->addChild('updateSubgroup');
                        
			$containerManager=$this->_authManager->createTask("containerManager");
                        $containerManager->addChild('createContainer');
                        $containerManager->addChild('deleteContainer');
                        $containerManager->addChild('readContainer');
                        $containerManager->addChild('updateContainer');
                        
			$tooltypeManager=$this->_authManager->createTask("documenttypeManager");
                        $tooltypeManager->addChild('createNewDocumenttype');
                        $tooltypeManager->addChild('readDocumenttype');
                        $tooltypeManager->addChild('updateDocumenttype');
                        $tooltypeManager->addChild('deleteDocumenttype');
                        
			$toolboxManager=$this->_authManager->createTask("folderManager");
                        $toolboxManager->addChild('createNewFolder');
                        $toolboxManager->addChild('readFolder');
                        $toolboxManager->addChild('updateFolder');
                        $toolboxManager->addChild('deleteFolder');
                        
			$categoryManager=$this->_authManager->createTask("categoryManager");
                        $categoryManager->addChild('createNewCategoryOrDomain');
                        $categoryManager->addChild('deleteCategoryOrDomain');
                        $categoryManager->addChild('readCategoryOrDomain');
                        $categoryManager->addChild('updateCategoryOrDomain');
                        
			$roleManager=$this->_authManager->createTask("roleManager");
                        $roleManager->addChild('createNewRole');
                        $roleManager->addChild('deleteRole');
                        $roleManager->addChild('updateRole');
                        
			$taskManager=$this->_authManager->createTask("taskManager");
                        $taskManager->addChild('createNewTask');
                        $taskManager->addChild('deleteTask');
                        $taskManager->addChild('updateTask');
                        
			$privilegesManager=$this->_authManager->createTask("privilegesManager");
                        $privilegesManager->addChild('createNewPrivilege');
                        $privilegesManager->addChild('deletePrivilege');
                        $privilegesManager->addChild('updatePrivilege');
                        
			$userAuthorizationManager=$this->_authManager->createTask("userAuthorizationManager");
                        $userAuthorizationManager->addChild('deleteUserAuthorisation');
                        $userAuthorizationManager->addChild('performUserAuthorisation');
                        
			//include the task for some addtional modules
                        $activeToolboxServiceManager=$this->_authManager->createTask("activeFolderServiceManager");
                        $activeToolboxServiceManager->addChild('readInactiveFolderService');
                        $activeToolboxServiceManager->addChild('activateFolderService');
                        $activeToolboxServiceManager->addChild('readActiveFolderService');
                        $activeToolboxServiceManager->addChild('deactivateFolderService');
                        
                        $announcementManager=$this->_authManager->createTask("announcementManager");
                        $announcementManager->addChild('createNewAnnouncement');
                        $announcementManager->addChild('deleteAnnouncement');
                        $announcementManager->addChild('readAnnouncement');
                        $announcementManager->addChild('updateAnnouncement');
                        
                        $currencyExchangeManager=$this->_authManager->createTask("currencyExchangeManager");
                        $currencyExchangeManager->addChild('createNewCurrencyExchange');
                        $currencyExchangeManager->addChild('deleteCurrencyExchange');
                        $currencyExchangeManager->addChild('readCurrencyExchange');
                        $currencyExchangeManager->addChild('updateCurrencyExchange');
                        
                        $currencyManagement=$this->_authManager->createTask("currencyManagement");
                        $currencyManagement->addChild('createNewCurrency');
                        $currencyManagement->addChild('deleteCurrency');
                        $currencyManagement->addChild('readCurrency');
                        $currencyManagement->addChild('updateCurrency');
                        
                        $domainNetworkConnectionManager=$this->_authManager->createTask("domainNetworkConnectionManager");
                        $domainNetworkConnectionManager->addChild('removeAMemberFromNetwork');
                        $domainNetworkConnectionManager->addChild('addingFolderToAnotherDomainNetwork');
                        $domainNetworkConnectionManager->addChild('removeFolderFromNetworkConnection');
                        $domainNetworkConnectionManager->addChild('accessInlineNetworkStore');
                        
                        $domainNetworkManager=$this->_authManager->createTask("domainNetworkManager");
                        $domainNetworkManager->addChild('acceptOrRejectWouldBeNetworkMembership');
                        $domainNetworkManager->addChild('initiateNewNetworkMember');
                        $domainNetworkManager->addChild('keepNetworkMembershipInView');
                        $domainNetworkManager->addChild('modifyNetworkMembership');
                        $domainNetworkManager->addChild('readNetworkMembershipRequest');
                        $domainNetworkManager->addChild('removeMemberFromNetwork');
                        $domainNetworkManager->addChild('removeNetworkMembershipRequest');
                        
                        $domainOrdersManager=$this->_authManager->createTask("domainOrdersManager");
                        $domainOrdersManager->addChild('addToCartFromOrder');
                        $domainOrdersManager->addChild('makePaymentFromOrder');
                        $domainOrdersManager->addChild('readOrders');
                        $domainOrdersManager->addChild('removeFromCartFromOrder');
                        $domainOrdersManager->addChild('updateCartContentFromOrder');
                        
                        $domainPolicyManager=$this->_authManager->createTask("domainPolicyManager");
                        $domainPolicyManager->addChild('createNewDomainPolicy');
                        $domainPolicyManager->addChild('deleteDomainPolicy');
                        $domainPolicyManager->addChild('readDomainPolicy');
                        $domainPolicyManager->addChild('updateDomainPolicy');
                        
                        $domainToPartnerManager=$this->_authManager->createTask("domainToPartnerManager");
                        $domainToPartnerManager->addChild('acceptOrRejectPartnerRequest');
                        $domainToPartnerManager->addChild('deletePendingDomainToPartnershipRequest');
                        $domainToPartnerManager->addChild('deletePendingPartnerToDomainRequest');
                        $domainToPartnerManager->addChild('initiateNewPartnership');
                        $domainToPartnerManager->addChild('readDomainToPartnerRequest');
                        $domainToPartnerManager->addChild('readPartnerToDomainRequest');
                        $domainToPartnerManager->addChild('updatePartnershipInfo');
                        
                        $needManager=$this->_authManager->createTask("needManager");
                        $needManager->addChild('deleteNeed');
                        $needManager->addChild('readNeed');
                        $needManager->addChild('viewNeed');
                        
                        $partnerToDomainManager=$this->_authManager->createTask("partnerToDomainManager");
                        $partnerToDomainManager->addChild('acceptOrRejectPartnerRequest');
                        $partnerToDomainManager->addChild('deletePendingPartnerToDomainRequest');
                        $partnerToDomainManager->addChild('keepRequestInView');
                        $partnerToDomainManager->addChild('readPartnerToDomainRequest');
                        
                        $paymentConfirmationManager=$this->_authManager->createTask("paymentConfirmationManager");
                        $paymentConfirmationManager->addChild('makePaymentConfirmations');
                        $paymentConfirmationManager->addChild('readUnconfirmedPayments');
                        
                        $paymentRemittanceManager=$this->_authManager->createTask("paymentRemittanceManager");
                        $paymentRemittanceManager->addChild('deferPaymentRemittance');
                        $paymentRemittanceManager->addChild('includePaymentForRemittance');
                        $paymentRemittanceManager->addChild('processPaymentForRemittance');
                        $paymentRemittanceManager->addChild('viewPaymentForRemittance');
                        
                        $platformSettingsManager=$this->_authManager->createTask("platformSettingsManager");
                        $platformSettingsManager->addChild('createNewPlatformSettings');
                        $platformSettingsManager->addChild('deletePlatformSettings');
                        $platformSettingsManager->addChild('readPlatformSettings');
                        $platformSettingsManager->addChild('updatePlatformSettings');
                        
                        $receiptManager=$this->_authManager->createTask("receiptManager");
                        $receiptManager->addChild('readDomainReceipt');
                        
                        $serviceRenewalManager=$this->_authManager->createTask("serviceRenewalManager");
                        $serviceRenewalManager->addChild('effectFolderServiceRenewal');
                        $serviceRenewalManager->addChild('readDueFolderServicesForRenewal');
                        
                        $storeManager=$this->_authManager->createTask("storeManager");
                        $storeManager->addChild('createNewStoreParameters');
                        $storeManager->addChild('deleteStoreParameters');
                        $storeManager->addChild('readStoreParameters');
                        $storeManager->addChild('updateStoreParameters');
                        
                        $timezoneManager=$this->_authManager->createTask("timezoneManager");
                        $timezoneManager->addChild('createNewTimezone');
                        $timezoneManager->addChild('deleteTimezone');
                        $timezoneManager->addChild('readTimezone');
                        $timezoneManager->addChild('updateTimezone');
                        
                        $toolboxDuplicationManager=$this->_authManager->createTask("folderDuplicationManager");
                        $toolboxDuplicationManager->addChild('createNewFolderDuplicate');
                        $toolboxDuplicationManager->addChild('updateFolderDuplicate');
                        $toolboxDuplicationManager->addChild('deleteFolderDuplicate');
                        $toolboxDuplicationManager->addChild('readFolderDuplicate');
                        $toolboxDuplicationManager->addChild('removeFileFromDuplicateFolders');
                        
                        $toolDuplicationManager=$this->_authManager->createTask("fileDuplicationManager");
                        $toolDuplicationManager->addChild('createNewFileDuplicate');
                        $toolDuplicationManager->addChild('updateFileDuplicate');
                        $toolDuplicationManager->addChild('deleteFileDuplicate');
                        $toolDuplicationManager->addChild('readFileDuplicate');
                        
                        $wishManager=$this->_authManager->createTask("wishManager");
                        $wishManager->addChild('deleteWish');
                        $wishManager->addChild('readWish');
                        $wishManager->addChild('viewWish');
                        
                        $partnershipManager=$this->_authManager->createTask("partnershipManager");
                        $partnershipManager->addChild('accessPartnerInlineStore');
                        $partnershipManager->addChild('deletePartnership');
                        $partnershipManager->addChild('modifyPartnershipStatus');
                        $partnershipManager->addChild('readDomainPartners');
                        
                        $technologyManager=$this->_authManager->createTask("documentCategoryManager");
                        $technologyManager->addChild('createNewDocumentCategory');
                        $technologyManager->addChild('updateDocumentCategory');
                        $technologyManager->addChild('deleteDocumentCategory');
                        $technologyManager->addChild('readDocumentCategory');
                        
                        $networkManager=$this->_authManager->createTask("networkManager");
                        $networkManager->addChild('addFolderToNetwork');
                        $networkManager->addChild('assignFolderToNetwork');
                        $networkManager->addChild('createNewNetwork');
                        $networkManager->addChild('deleteNetwork');
                        $networkManager->addChild('modifyNetwork');
                        $networkManager->addChild('modifyFolderStatusInNetwork');
                        
                        $technologyManager=$this->_authManager->createTask("reportManager");
                        $technologyManager->addChild('createNewReport');
                        $technologyManager->addChild('createReport');
                        $technologyManager->addChild('updateReport');
                        $technologyManager->addChild('deleteReport');
                        $technologyManager->addChild('generateReport');
			
	//list of user roles on the platform	 
	     $adminrole=$this->_authManager->createRole("platformSuperAdmin", "This is the role that manages the entire platform"); 
             $adminrole->addChild('filesAndDocumentManager');
             $adminrole->addChild('userToSubgroupAssignmentManager');
             $adminrole->addChild('folderToCategoryAssignmentManager');
             $adminrole->addChild('filesToFolderAssignmentManager');
             $adminrole->addChild('folderToGroupAssignmentManager');
             $adminrole->addChild('folderToSubgroupAssignmentManager');
             $adminrole->addChild('folderToUserAssignmentManager');
             $adminrole->addChild('userToSubgroupSchedulingManager');
             $adminrole->addChild('folderToCategorySchedulingManager');
             $adminrole->addChild('filesInFolderSchedulingManager');
             $adminrole->addChild('folderToGroupSchedulingManager');
             $adminrole->addChild('folderToSubgroupSchedulingManager');
             $adminrole->addChild('folderToUserSchedulingManager');
             $adminrole->addChild('userManager');
             $adminrole->addChild('countryManager');
             $adminrole->addChild('stateManager');
             $adminrole->addChild('cityManager');
             $adminrole->addChild('groupManager');
             $adminrole->addChild('subgroupManager');
             $adminrole->addChild('containerManager');
             $adminrole->addChild('documenttypeManager');
             $adminrole->addChild('folderManager');
             $adminrole->addChild('categoryManager');
             $adminrole->addChild('roleManager');
             $adminrole->addChild('taskManager');
             $adminrole->addChild('privilegesManager');
             $adminrole->addChild('userAuthorizationManager');
             $adminrole->addChild('activeFolderServiceManager');
             $adminrole->addChild('announcementManager');
             $adminrole->addChild('currencyExchangeManager');
             $adminrole->addChild('currencyManagement');
             $adminrole->addChild('domainNetworkConnectionManager');
             $adminrole->addChild('domainNetworkManager');
             $adminrole->addChild('domainOrdersManager');
             $adminrole->addChild('domainPolicyManager');
             $adminrole->addChild('domainToPartnerManager');
             $adminrole->addChild('needManager');
             $adminrole->addChild('partnerToDomainManager');
             $adminrole->addChild('paymentConfirmationManager');
             $adminrole->addChild('paymentRemittanceManager');
             $adminrole->addChild('platformSettingsManager');
             $adminrole->addChild('receiptManager');
             $adminrole->addChild('serviceRenewalManager');
             $adminrole->addChild('storeManager');
             $adminrole->addChild('timezoneManager');
             $adminrole->addChild('folderDuplicationManager');
             $adminrole->addChild('fileDuplicationManager');
             $adminrole->addChild('wishManager');
             $adminrole->addChild('partnershipManager');
             $adminrole->addChild('DocumentCategoryManager');
             $adminrole->addChild('networkManager');
             $adminrole->addChild('readFilesAndDocument');
             $adminrole->addChild('readAssignedFoldersToSubgroup');
             $adminrole->addChild('platformPaymentConfirmation');
             $adminrole->addChild('platformAdmin');
             $adminrole->addChild('grantSpecialPrivilegesToDomains');
             $adminrole->addChild('changeUserPassword');
             
             $domainSuperAdmin=$this->_authManager->createRole("domainSuperAdmin","This is the role in charge of domain administration"); 
             $domainSuperAdmin->addChild('filesAndDocumentManager');
             $domainSuperAdmin->addChild('userToSubgroupAssignmentManager');
             $domainSuperAdmin->addChild('folderToCategoryAssignmentManager');
             $domainSuperAdmin->addChild('filesToFolderAssignmentManager');
             $domainSuperAdmin->addChild('folderToGroupAssignmentManager');
             $domainSuperAdmin->addChild('folderToSubgroupAssignmentManager');
             $domainSuperAdmin->addChild('folderToUserAssignmentManager');
             $domainSuperAdmin->addChild('userToSubgroupSchedulingManager');
             $domainSuperAdmin->addChild('folderToCategorySchedulingManager');
             $domainSuperAdmin->addChild('filesInFolderSchedulingManager');
             $domainSuperAdmin->addChild('folderToGroupSchedulingManager');
             $domainSuperAdmin->addChild('folderToSubgroupSchedulingManager');
             $domainSuperAdmin->addChild('folderToUserSchedulingManager');
             $domainSuperAdmin->addChild('userManager');
             $domainSuperAdmin->addChild('groupManager');
             $domainSuperAdmin->addChild('subgroupManager');
             $domainSuperAdmin->addChild('folderManager');
             $domainSuperAdmin->addChild('categoryManager');
             $domainSuperAdmin->addChild('announcementManager');
             $domainSuperAdmin->addChild('domainNetworkConnectionManager');
             $domainSuperAdmin->addChild('domainNetworkManager');
             $domainSuperAdmin->addChild('domainOrdersManager');
             $domainSuperAdmin->addChild('domainPolicyManager');
             $domainSuperAdmin->addChild('domainToPartnerManager');
             $domainSuperAdmin->addChild('needManager');
             $domainSuperAdmin->addChild('partnerToDomainManager');
             $domainSuperAdmin->addChild('receiptManager');
             $domainSuperAdmin->addChild('serviceRenewalManager');
             $domainSuperAdmin->addChild('storeManager');
             $domainSuperAdmin->addChild('folderDuplicationManager');
             $domainSuperAdmin->addChild('fileDuplicationManager');
             $domainSuperAdmin->addChild('wishManager');
             $domainSuperAdmin->addChild('partnershipManager');
             $domainSuperAdmin->addChild('networkManager');
             $domainSuperAdmin->addChild('readFilesAndDocument');
             $domainSuperAdmin->addChild('changeUserPassword');
             
             $domainToolsCentralAdmin=$this->_authManager->createRole("domainFilesCentralAdmin","This role manages all the files and document activity  for a domain"); 
             $domainToolsCentralAdmin->addChild('filesAndDocumentManager');
             
             
             $domainAssignmentAdmin=$this->_authManager->createRole("domainAssignmentAdmin","This role is responsible for all assignment activities for a domain");
             $domainAssignmentAdmin->addChild('userToSubgroupAssignmentManager');
             $domainAssignmentAdmin->addChild('folderToCategoryAssignmentManager');
             $domainAssignmentAdmin->addChild('filesToFolderAssignmentManager');
             $domainAssignmentAdmin->addChild('folderToGroupAssignmentManager');
             $domainAssignmentAdmin->addChild('folderToSubgroupAssignmentManager');
             $domainAssignmentAdmin->addChild('folderToUserAssignmentManager');
             
             $domainSchedulingAdmin=$this->_authManager->createRole("domainSchedulingAdmin","This role is responsible for all scheduling activities for a domain");
             $domainSchedulingAdmin->addChild('userToSubgroupSchedulingManager');
             $domainSchedulingAdmin->addChild('folderToCategorySchedulingManager');
             $domainSchedulingAdmin->addChild('filesInFolderSchedulingManager');
             $domainSchedulingAdmin->addChild('folderToGroupSchedulingManager');
             $domainSchedulingAdmin->addChild('folderToSubgroupSchedulingManager');
             $domainSchedulingAdmin->addChild('folderToUserSchedulingManager');
             
             $domainGroupAdmin=$this->_authManager->createRole("domainGroupAdmin","This role is in charge of group administration for a domain");
             $domainGroupAdmin->addChild('groupManager');
             $domainSubgroupAdmin=$this->_authManager->createRole("domainSubgroupAdmin","This role is in charge of subgroup administration for a domain");
             $domainSubgroupAdmin->addChild('subgroupManager');
             $domainAnnouncementAdmin=$this->_authManager->createRole("domainAnnouncementAdmin","This role is in charge of announcement administration for a domain");
             $domainAnnouncementAdmin->addChild('announcementManager');
             $domainNeedsAdmin=$this->_authManager->createRole("domainNeedsAdmin","This role is in charge of needs administration for a domain");
             $domainNeedsAdmin->addChild('needManager');
             $domainWishesAdmin=$this->_authManager->createRole("domainWishesAdmin","This role is in charge of wishes administration for a domain");
             $domainWishesAdmin->addChild('wishManager');
             $domainUserAdmin=$this->_authManager->createRole("domainUserAdmin","This role is in charge of user administration for a domain");
             $domainUserAdmin->addChild('userManager');
             $domainLocationAdmin=$this->_authManager->createRole("domainLocationAdmin","This role is in charge of country, state and city management on the platform");
             $domainLocationAdmin->addChild('countryManager');
             $domainLocationAdmin->addChild('stateManager');
             $domainLocationAdmin->addChild('cityManager');             
             $domainPolicyAdmin=$this->_authManager->createRole("domainPolicyAdmin","This role is in charge of policy administration for a domain");
             $domainPolicyAdmin->addChild('domainPolicyManager');
             $domainStoreAdmin=$this->_authManager->createRole("domainStoreAdmin","This role is in charge of store administration for a domain");
             $domainStoreAdmin->addChild('storeManager');
             $domainSecurityAdmin=$this->_authManager->createRole("domainSecurityAdmin","This role is in charge of security administration on the platform");
             $domainSecurityAdmin->addChild('roleManager');
             $domainSecurityAdmin->addChild('taskManager');
             $domainSecurityAdmin->addChild('privilegesManager');
             $domainSecurityAdmin->addChild('userAuthorizationManager');
             $domainPartnerAdmin=$this->_authManager->createRole("domainPartnerAdmin","This role is in charge of partnership administration for a domain");
             $domainPartnerAdmin->addChild('domainToPartnerManager');
             $domainPartnerAdmin->addChild('partnershipManager');
             $domainPartnerAdmin->addChild('partnerToDomainManager');
             $domainNetworkAdmin=$this->_authManager->createRole("domainNetworkAdmin","This role is in charge of network management for a domain");
             $domainNetworkAdmin->addChild('networkManager');
             $domainNetworkAdmin->addChild('domainNetworkConnectionManager');
             $domainOrdersAdmin=$this->_authManager->createRole("domainOrdersAdmin","This role is in charge of Service Orders administration for a domain");
             $domainOrdersAdmin->addChild('domainOrdersManager');
             $domainRenewalsAdmin=$this->_authManager->createRole("domainRenewalsAdmin","This role is in charge of service renewals administration for a domain");
             $domainRenewalsAdmin->addChild('serviceRenewalManager');
             $domainReceiptAdmin=$this->_authManager->createRole("domainReceiptAdmin","This role is in charge of receipt administration for a domain");
             $domainReceiptAdmin->addChild('receiptManager');
             $domainDomainAdmin=$this->_authManager->createRole("domainDomainAdmin","This role is in charge of domainn administration for a domain");
             $domainDomainAdmin->addChild('categoryManager');
             $domainToolboxAdmin=$this->_authManager->createRole("domainFolderAdmin","This role is in charge of folder administration for a domain");
             $domainToolboxAdmin->addChild('folderManager');
             $domainToolDuplicationAdmin=$this->_authManager->createRole("domainFileDuplicationAdmin","This role is in charge of file duplication administration for a domain");
             $domainToolDuplicationAdmin->addChild('fileDuplicationManager');
             $domainToolboxDuplicationAdmin=$this->_authManager->createRole("domainFolderDuplicationAdmin","This role is in charge of folder duplication administration for a domain"); 
             $domainToolboxDuplicationAdmin->addChild('folderDuplicationManager');
             $user=$this->_authManager->createRole("user","This is the user only role"); 
			
                         
                         
                         
			 
		
		     //provide a message indicating success
		     echo "Authorization hierarchy successfully generated.\n";
        }
 		else
			echo "Operation cancelled.\n";
    }

	public function actionDelete()
	{
		$this->ensureAuthManagerDefined();
		$message = "This command will clear all RBAC definitions.\n";
		$message .= "Would you like to continue?";
	    //check the input from the user and continue if they indicated 
	    //yes to the above question
	    if($this->confirm($message)) 
	    {
			$this->_authManager->clearAll();
			echo "Authorization hierarchy removed.\n";
		}
		else
			echo "Delete operation cancelled.\n";
			
	}
	
	protected function ensureAuthManagerDefined()
	{
		//ensure that an authManager is defined as this is mandatory for creating an auth heirarchy
		if(($this->_authManager=Yii::app()->authManager)===null)
		{
		    $message = "Error: an authorization manager, named 'authManager' must be configured to use this command.";
			$this->usageError($message);
		}
	}
}
