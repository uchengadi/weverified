<?php
/* @var $this VirtualBatchRequestController */
/* @var $dataProvider CActiveDataProvider */

$this->breadcrumbs=array(
	'Virtual Batch Requests',
);

$this->menu=array(
	array('label'=>'Create VirtualBatchRequest', 'url'=>array('create')),
	array('label'=>'Manage VirtualBatchRequest', 'url'=>array('admin')),
);
?>

<h1>Virtual Batch Requests</h1>

<?php $this->widget('zii.widgets.CListView', array(
	'dataProvider'=>$dataProvider,
	'itemView'=>'_view',
)); ?>
