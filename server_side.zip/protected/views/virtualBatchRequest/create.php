<?php
/* @var $this VirtualBatchRequestController */
/* @var $model VirtualBatchRequest */

$this->breadcrumbs=array(
	'Virtual Batch Requests'=>array('index'),
	'Create',
);

$this->menu=array(
	array('label'=>'List VirtualBatchRequest', 'url'=>array('index')),
	array('label'=>'Manage VirtualBatchRequest', 'url'=>array('admin')),
);
?>

<h1>Create VirtualBatchRequest</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>