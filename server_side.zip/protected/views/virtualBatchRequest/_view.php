<?php
/* @var $this VirtualBatchRequestController */
/* @var $data VirtualBatchRequest */
?>

<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('id')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->id), array('view', 'id'=>$data->id)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('virtual_batch_id')); ?>:</b>
	<?php echo CHtml::encode($data->virtual_batch_id); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('virtual_box_id')); ?>:</b>
	<?php echo CHtml::encode($data->virtual_box_id); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('virtual_requesting_domain_id')); ?>:</b>
	<?php echo CHtml::encode($data->virtual_requesting_domain_id); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('virtual_requesting_user_id')); ?>:</b>
	<?php echo CHtml::encode($data->virtual_requesting_user_id); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('virtual_requesting_group_id')); ?>:</b>
	<?php echo CHtml::encode($data->virtual_requesting_group_id); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('virtual_requesting_subgroup_id')); ?>:</b>
	<?php echo CHtml::encode($data->virtual_requesting_subgroup_id); ?>
	<br />

	<?php /*
	<b><?php echo CHtml::encode($data->getAttributeLabel('status')); ?>:</b>
	<?php echo CHtml::encode($data->status); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('virtual_is_requested')); ?>:</b>
	<?php echo CHtml::encode($data->virtual_is_requested); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('virtual_maximum_requesting_period_in_days')); ?>:</b>
	<?php echo CHtml::encode($data->virtual_maximum_requesting_period_in_days); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('virtual_request_initiation_date')); ?>:</b>
	<?php echo CHtml::encode($data->virtual_request_initiation_date); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('virtual_request_initiated_by')); ?>:</b>
	<?php echo CHtml::encode($data->virtual_request_initiated_by); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('virtual_is_request_initiated')); ?>:</b>
	<?php echo CHtml::encode($data->virtual_is_request_initiated); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('virtual_is_request_accepted')); ?>:</b>
	<?php echo CHtml::encode($data->virtual_is_request_accepted); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('virtual_request_accepted_date')); ?>:</b>
	<?php echo CHtml::encode($data->virtual_request_accepted_date); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('virtual_request_accepted_by')); ?>:</b>
	<?php echo CHtml::encode($data->virtual_request_accepted_by); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('virtual_is_group_request')); ?>:</b>
	<?php echo CHtml::encode($data->virtual_is_group_request); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('virtual_is_subgroup_request')); ?>:</b>
	<?php echo CHtml::encode($data->virtual_is_subgroup_request); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('virtual_is_single_user_request')); ?>:</b>
	<?php echo CHtml::encode($data->virtual_is_single_user_request); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('virtual_is_electronic_instrument_request_included')); ?>:</b>
	<?php echo CHtml::encode($data->virtual_is_electronic_instrument_request_included); ?>
	<br />

	*/ ?>

</div>