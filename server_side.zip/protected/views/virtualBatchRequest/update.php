<?php
/* @var $this VirtualBatchRequestController */
/* @var $model VirtualBatchRequest */

$this->breadcrumbs=array(
	'Virtual Batch Requests'=>array('index'),
	$model->id=>array('view','id'=>$model->id),
	'Update',
);

$this->menu=array(
	array('label'=>'List VirtualBatchRequest', 'url'=>array('index')),
	array('label'=>'Create VirtualBatchRequest', 'url'=>array('create')),
	array('label'=>'View VirtualBatchRequest', 'url'=>array('view', 'id'=>$model->id)),
	array('label'=>'Manage VirtualBatchRequest', 'url'=>array('admin')),
);
?>

<h1>Update VirtualBatchRequest <?php echo $model->id; ?></h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>