<?php

class EnlistmentVerificationCodeController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','listThisEnlistmentVerificationCodes','updateenlistmentverificationcode',
                                    'retrieveenlistmentcodeinfo','retrievecodemessagecontent','retrievethemessageforthiscode','listAllEnlistmentVerificationCodes',
                                    'retrievecodeproductcontent','retrievetheproductforthiscode','submittingenlistmentcodefeedbackengagementdesign',
                                    'submittingenlistmentcodefeedbackdesign','settingengagementlimit','retrieconsumedenlistmentcodeinfo','listThisEnlistmentAllVerificationCodes'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	
	/**
         * This is the function that list a particular enlistment verification code
         */
        public function actionlistThisEnlistmentVerificationCodes(){
            
             $enlistment_id= $_REQUEST['enlistment_id'];
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='enlistment_id=:enlistmentid';
            $criteria->params = array(':enlistmentid'=>$enlistment_id);
            $enlistments = EnlistmentVerificationCode::model()->findAll($criteria);
            
            if($enlistments===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "code" =>$enlistments,
                                    
                    
                            ));
                       
                         }
            
            
        }
        
        
        /**
         * This is the function that updates the information of a verification code
         */
        public function actionupdateenlistmentverificationcode(){
            
            $_id = $_POST['id'];
            $model= EnlistmentVerificationCode::model()->findByPk($_id);
            $model->enlistment_id = $_REQUEST['enlistment_id'];
            if($_REQUEST['code_type'] == "one_time"){
                $model->type = $_REQUEST['code_type'];
                $model->viewership =strtolower('same_viewer');
            }else{
                $model->type = $_REQUEST['code_type'];
                $model->viewership = $_REQUEST['viewership'];
            }
           // $model->date_of_expiry = date("Y-m-d H:i:s",strtotime($_REQUEST['date_of_expiry']));
            if(isset($_REQUEST['is_paid_for_by_code_consumer'])){
                $model->is_paid_for_by_code_consumer = $_REQUEST['is_paid_for_by_code_consumer'];
            }else{
                $model->is_paid_for_by_code_consumer=0;
            }
             if(isset($_REQUEST['is_post_consumption'])){
                $model->is_post_consumption = $_REQUEST['is_post_consumption'];
            }else{
                $model->is_post_consumption=0;
            }
            if(isset($_REQUEST['is_for_public'])){
                $model->is_for_public = $_REQUEST['is_for_public'];
                $model->enlistment_authorized_viewers_email = NULL;
            }else{
                $model->is_for_public=0;
                $model->enlistment_authorized_viewers_email = $_REQUEST['enlistment_authorized_viewers_email'];
            }
            if(isset($_REQUEST['verify_public_with_parameter'])){
                $model->verify_public_with_parameter = $_REQUEST['verify_public_with_parameter'];
            }else{
                $model->verify_public_with_parameter=NULL;
            }
             if(isset($_REQUEST['verify_receiver_with_bvn_in_second_level_auth'])){
                $model->verify_receiver_with_bvn_in_second_level_auth = $_REQUEST['verify_receiver_with_bvn_in_second_level_auth'];
            }else{
                $model->verify_receiver_with_bvn_in_second_level_auth=0;
            }
             if(isset($_REQUEST['verify_receiver_with_nin_second_level_auth'])){
                $model->verify_receiver_with_nin_second_level_auth = $_REQUEST['verify_receiver_with_nin_second_level_auth'];
            }else{
                $model->verify_receiver_with_nin_second_level_auth=0;
            }
             if(isset($_REQUEST['verify_receiver_with_pvc_in_second_level_auth'])){
                $model->verify_receiver_with_pvc_in_second_level_auth = $_REQUEST['verify_receiver_with_pvc_in_second_level_auth'];
            }else{
                $model->verify_receiver_with_pvc_in_second_level_auth=0;
            }
             if(isset($_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'])){
                $model->verify_receiver_registered_mobile_number_in_second_level_auth = $_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'];
            }else{
                $model->verify_receiver_registered_mobile_number_in_second_level_auth=0;
            }
            if(isset($_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'])){
                $model->verify_receiver_with_passport_number_in_second_level_auth = $_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'];
            }else{
                $model->verify_receiver_with_passport_number_in_second_level_auth=0;
            }
            if(isset($_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'])){
                $model->verify_receiver_with_driving_license_in_second_level_auth = $_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'];
            }else{
                $model->verify_receiver_with_driving_license_in_second_level_auth=0;
            }
            if(isset($_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'])){
                $model->verify_receiver_with_pension_pin_in_second_level_auth = $_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'];
            }else{
                $model->verify_receiver_with_pension_pin_in_second_level_auth=0;
            }
             if(isset($_REQUEST['is_verification_required'])){
                $model->is_verification_required = 0;
            }else{
                $model->is_verification_required=1;
            }
            
            if($_REQUEST['day_to_expiry'] == "" || $_REQUEST['day_to_expiry'] == NULL){
                $day_to_expiry = $model->getTheCurrentExpiryDate($_id);
            }else{
               $day_to_expiry =  $model->getTheExpirationDateOfThisVerificationCode($_REQUEST['day_to_expiry']);
            }
          if($this->isThisEnlistmentCodeActive($_REQUEST['date_of_expiry'])){
              $model->date_of_expiry = $day_to_expiry;
              if($model->save()){
                 header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg" =>"This Enlistment Verification code is updated succesfully"
                        ));
                
                
            }else{
                header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"There is possibly a validation error on your input data. Please correct it and try again. If the problem persist, contact customer service for assistance"
                        ));  
            }
              
          }else{
               header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" =>"This code had expired and therefore it cannot be updated. You may however wish to generate a new verification code for this enlistment"
                        ));
              
          }
            
            
        }
        
        
        
         /**
         * This is the function that retrieves information about user enlistments verification code
         */
        public function actionretrieveenlistmentcodeinfo(){
            $enlistment_id = $_REQUEST['enlistment_id'];
            $code_id = $_REQUEST['id'];
            
             //retrieve enlistment information
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$enlistment_id);
            $enlistment = UserEnlistmentRequest::model()->find($criteria); 
            
            //retrieve verification code information
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:listid';
            $criteria->params = array(':listid'=>$code_id);
            $code = EnlistmentVerificationCode::model()->find($criteria); 
            
            if($enlistment_id===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "enlistment" =>$enlistment,
                                    "code"=>$code
                                    
                    
                            ));
                       
                         }
            
        }
        
        
           /**
         * This is the function that determines if an enlistment code is still valid
         */
        public function isThisEnlistmentCodeActive($date_of_expiry){
            $model = new EnlistmentVerificationCode;
            return $model->isThisEnlistmentCodeActive($date_of_expiry);
        }
        
        
           /**
         * This is the function that determines if an enlistment code is still valid
         */
        public function thistimediff($date_of_expiry){
            $model = new EnlistmentVerificationCode;
            return $model->thistimediff($date_of_expiry);
        }
        
        
        /**
         * This is the function that retrieves the content of a code
         */
        public function actionretrievecodemessagecontent(){
           $model = new EnlistmentVerificationCode;
           $user_id = Yii::app()->user->id;
            
            $code = $_REQUEST['code'];
            $message_type = $_REQUEST['message_type'];
           
           if($model->isCodeExist($code)){
               
               if($model->isCodeForThisMessageType($code,$message_type)){
                    //check if code had expired
               if($model->isCodeExpired($code)==false){
                   if($model->isThisCodeStillValidForConsumption($code,$user_id)){
                       //get the authentication attributes for this message
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='verification_code=:code';
                    $criteria->params = array(':code'=>"$code");
                    $verification = EnlistmentVerificationCode::model()->find($criteria);
                    
                     if($verification===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "code"=>$verification
                                    
                    
                            ));
                       
                         }
                       
                   }else{
                       header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" =>"Code Validity: This code is no longer valid for consumption. Please request for a new one from the other party and try again"
                        ));
                       
                   }
                
                   
               }else{
                    header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" =>"Expired Code: This code had expired. Please request for a new one from the other party and try again"
                        ));
               }
                   
                   
                   
               }else{
                   header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" =>"Wrong application of Code: This code is not enlisted against the '$message_type' message type. Please ask the other party for the message type this code was meant for"
                        ));
                   
               }
              
               
           }else{
                header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" =>"Sorry: This code does not exist. Please check the code and try again"
                        ));
               
           }
            
        }
        
        
        /**
         * This is the function that authenticates a code user and retrieves the code message
         */
        public function actionretrievethemessageforthiscode(){
            
            $model = new EnlistmentVerificationCode;
            
            $user_id = Yii::app()->user->id;
            
            $code_id = $_REQUEST['code_id'];
            $code = $_REQUEST['code'];
            $is_bvn = $_REQUEST['is_bvn'];
            $is_nin = $_REQUEST['is_nin'];
            $is_pvc = $_REQUEST['is_pvc'];
            $is_passport = $_REQUEST['is_passport'];
            $is_license = $_REQUEST['is_license'];
            $is_mobile = $_REQUEST['is_mobile'];
            $is_pension = $_REQUEST['is_pension'];
            $is_noauth = $_REQUEST['is_noauth'];
            
            if($is_noauth !=1){
                
                if($is_bvn ==1){
                $userbvn = $_REQUEST['userbvn'];
            }else{
              $userbvn=null;  
            }
            if($is_nin ==1){
                $usernin = $_REQUEST['usernin'];
            }else{
               $usernin = null; 
            }
            if($is_pvc ==1){
                $userpvc = $_REQUEST['userpvc'];
            }else{
               $userpvc = null; 
            }
             if($is_passport ==1){
                $userpassport = $_REQUEST['userpassport'];
            }else{
                $userpassport=null;
            }
             if($is_license ==1){
                $userlicense = $_REQUEST['userlicense'];
            }else{
                $userlicense = null;
            }
            if($is_mobile ==1){
                $usermobile = $_REQUEST['usermobile'];
            }else{
                $usermobile = null;
            }
            if($is_pension ==1){
                $userpension = $_REQUEST['userpension'];
            }else{
                $userpension =null;
            }
            if($model->isThisUserLegibleToConsumeThisCode($user_id,$code_id)){
                if($model->isTheCodeUserAuthenticationValid($user_id,$code_id,$is_bvn,$is_nin,$is_pvc,$is_passport,$is_license,$is_mobile,$is_pension,$userbvn,$usernin,$userpvc,$userpassport,$userlicense,$usermobile,$userpension)){
                //retrieve all the information about the code
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                     $criteria->condition='id=:id';
                    $criteria->params = array(':id'=>$code_id);
                    $code = EnlistmentVerificationCode::model()->find($criteria); 
            
            
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='id=:id';
                    $criteria->params = array(':id'=>$code['enlistment_id']);
                    $enlistment = UserEnlistmentRequest::model()->find($criteria); 
            
                    //record this code consumption activity
                    $this->recordThisCodeConsumptionActivity($user_id,$code_id);
            
            
                    if($code_id===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "enlistment" =>$enlistment,
                                    "code"=>$code
                                    
                    
                            ));
                       
                         }
                }else{
                    header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" =>"One or more of the authentication numbers you provided is not correct"
                        ));
                }
                
            }else{
                 header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" =>"You are not legible to consume this code. Please contact the person that gave you the code if you strongly feel otherwise"
                        ));
                
            }
            
                
                
                
            }else{
                 if($model->isThisUserLegibleToConsumeThisCode($user_id,$code_id)){
                          //retrieve all the information about the code
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='id=:id';
                    $criteria->params = array(':id'=>$code_id);
                    $code = EnlistmentVerificationCode::model()->find($criteria); 
            
            
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='id=:id';
                    $criteria->params = array(':id'=>$code['enlistment_id']);
                    $enlistment = UserEnlistmentRequest::model()->find($criteria); 
            
                    //record this code consumption activity
                    $this->recordThisCodeConsumptionActivity($user_id,$code_id);
            
            
                     if($code_id===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "enlistment" =>$enlistment,
                                    "code"=>$code
                                    
                    
                            ));
                       
                         }
                     
                 }else{
                      header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" =>"You are not legible to consume this code. Please contact the person that gave you the code if you strongly feel otherwise"
                        ));
                     
                 }
             
            }
            
            
            
        }
        
        
        /**
         * This is the function that determines if a user is legible to consume a code
         */
        public function isThisUserLegibleToConsumeThisCode($user_id,$code_id){
            $model = new EnlistmentVerificationCode;
            return $model->isThisUserLegibleToConsumeThisCode($user_id,$code_id);
        }
        
        
        /**
         * This is the function that records a code comsumption activity
         */
        public function recordThisCodeConsumptionActivity($user_id,$code_id){
            $model = new VerificationCodeConsumedByUser;
            return $model->recordThisCodeConsumptionActivity($user_id,$code_id);
        }
        
        
        /**
         * This is the function that list a all enlistment verification code
         */
        public function actionlistAllEnlistmentVerificationCodes(){
                                   
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            //$criteria->condition='enlistment_id=:enlistmentid';
            //$criteria->params = array(':enlistmentid'=>$enlistment_id);
            $enlistments = EnlistmentVerificationCode::model()->findAll($criteria);
            
            if($enlistments===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "code" =>$enlistments,
                                    
                    
                            ));
                       
                         }
            
            
        }
        
        
        /**
         * This is the function that retrieves the content of a product code
         */
        public function actionretrievecodeproductcontent(){
           $model = new EnlistmentVerificationCode;
           $user_id = Yii::app()->user->id;
            
            $code = $_REQUEST['code'];
            $item_type = $_REQUEST['item_type'];
           
           if($model->isCodeExist($code)){
               
               if($model->isCodeForThisMessageType($code,$item_type)){
                    //check if code had expired
               if($model->isCodeExpired($code)==false){
                   if($model->isThisCodeStillValidForConsumption($code,$user_id)){
                       //get the authentication attributes for this message
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='verification_code=:code';
                    $criteria->params = array(':code'=>"$code");
                    $verification = EnlistmentVerificationCode::model()->find($criteria);
                    
                     if($verification===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "code"=>$verification
                                    
                    
                            ));
                       
                         }
                       
                   }else{
                       header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" =>"Code Validity: This code is no longer valid for consumption. Please request for a new one from the other party and try again"
                        ));
                       
                   }
                
                   
               }else{
                    header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" =>"Expired Code: This code had expired. Please request for a new one from the other party and try again"
                        ));
               }
                   
                   
                   
               }else{
                   header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" =>"Wrong application of Code: This code is not enlisted against the '$item_type' message type. Please ask the other party for the message type this code was meant for"
                        ));
                   
               }
              
               
           }else{
                header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" =>"Sorry: This code does not exist. Please check the code and try again"
                        ));
               
           }
            
        }
        
        
        
         /**
         * This is the function that authenticates a code user and retrieves the code message
         */
        public function actionretrievetheproductforthiscode(){
            
            $model = new EnlistmentVerificationCode;
            
            $user_id = Yii::app()->user->id;
            
            $code_id = $_REQUEST['code_id'];
            $code = $_REQUEST['code'];
            $is_bvn = $_REQUEST['is_bvn'];
            $is_nin = $_REQUEST['is_nin'];
            $is_pvc = $_REQUEST['is_pvc'];
            $is_passport = $_REQUEST['is_passport'];
            $is_license = $_REQUEST['is_license'];
            $is_mobile = $_REQUEST['is_mobile'];
            $is_pension = $_REQUEST['is_pension'];
            $is_noauth = $_REQUEST['is_noauth'];
            
            if($is_noauth !=1){
                
                if($is_bvn ==1){
                $userbvn = $_REQUEST['userbvn'];
            }else{
              $userbvn=null;  
            }
            if($is_nin ==1){
                $usernin = $_REQUEST['usernin'];
            }else{
               $usernin = null; 
            }
            if($is_pvc ==1){
                $userpvc = $_REQUEST['userpvc'];
            }else{
               $userpvc = null; 
            }
             if($is_passport ==1){
                $userpassport = $_REQUEST['userpassport'];
            }else{
                $userpassport=null;
            }
             if($is_license ==1){
                $userlicense = $_REQUEST['userlicense'];
            }else{
                $userlicense = null;
            }
            if($is_mobile ==1){
                $usermobile = $_REQUEST['usermobile'];
            }else{
                $usermobile = null;
            }
            if($is_pension ==1){
                $userpension = $_REQUEST['userpension'];
            }else{
                $userpension =null;
            }
            if($model->isThisUserLegibleToConsumeThisCode($user_id,$code_id)){
                if($model->isTheCodeUserAuthenticationValid($user_id,$code_id,$is_bvn,$is_nin,$is_pvc,$is_passport,$is_license,$is_mobile,$is_pension,$userbvn,$usernin,$userpvc,$userpassport,$userlicense,$usermobile,$userpension)){
                //retrieve all the information about the code
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                     $criteria->condition='id=:id';
                    $criteria->params = array(':id'=>$code_id);
                    $code = EnlistmentVerificationCode::model()->find($criteria); 
            
            
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='id=:id';
                    $criteria->params = array(':id'=>$code['enlistment_id']);
                    $enlistment = UserEnlistmentRequest::model()->find($criteria); 
                    
                    //get the feedback if applicable
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='code_id=:codeid';
                    $criteria->params = array(':codeid'=>$code_id);
                    $feedback = FeedbacksForEnlistment::model()->find($criteria); 
            
                    //record this code consumption activity
                    $this->recordThisCodeConsumptionActivity($user_id,$code_id);
            
            
                    if($code_id===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "enlistment" =>$enlistment,
                                    "code"=>$code,
                                    "feedback"=>$feedback
                                    
                    
                            ));
                       
                         }
                }else{
                    header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" =>"One or more of the authentication numbers you provided is not correct"
                        ));
                }
                
            }else{
                 header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" =>"You are not legible to consume this code. Please contact the person that gave you the code if you strongly feel otherwise"
                        ));
                
            }
            
                
                
                
            }else{
                 if($model->isThisUserLegibleToConsumeThisCode($user_id,$code_id)){
                          //retrieve all the information about the code
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='id=:id';
                    $criteria->params = array(':id'=>$code_id);
                    $code = EnlistmentVerificationCode::model()->find($criteria); 
            
            
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='id=:id';
                    $criteria->params = array(':id'=>$code['enlistment_id']);
                    $enlistment = UserEnlistmentRequest::model()->find($criteria); 
                    
                    //get the feedback if applicable
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='code_id=:codeid';
                    $criteria->params = array(':codeid'=>$code_id);
                    $feedback = FeedbacksForEnlistment::model()->find($criteria); 
            
                    //record this code consumption activity
                    $this->recordThisCodeConsumptionActivity($user_id,$code_id);
            
            
                     if($code_id===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "enlistment" =>$enlistment,
                                    "code"=>$code,
                                    "feedback"=>$feedback
                                   
                                    
                    
                            ));
                       
                         }
                     
               }else{
                      header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" =>"You are not legible to consume this code. Please contact the person that gave you the code if you strongly feel otherwise",
                            
                                ));
                     
                 }
              
            }
            
            
            
        }
        
        
        /**
         * This is the function that sets an engagement limit for a code
         */
        public function actionsettingengagementlimit(){
            
            $model = new EnlistmentVerificationCode;
            
            $code_id = $_REQUEST['code_id'];
            
            if(isset($_REQUEST['is_limitless'])){
                $maximum_engagement_required = NULL;
            }else{
                $maximum_engagement_required = $_REQUEST['maximum_engagement_required'];
            }
            
            if($model->isTheSettingOfThisEngagementASuccess($code_id,$maximum_engagement_required)){
                 header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg" =>"This engagement limit is successfully set for the code"
                        ));
                
            }else{
                header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"There was an issue while setting the engagement limit. Please try again or contact customer service for assistance"
                        ));
                
            }
        }
        
        
        /**
         * This is the function that retrieves information about consumed user enlistments verification code
         */
        public function actionretrieconsumedenlistmentcodeinfo(){
            //$enlistment_id = $_REQUEST['enlistment_id'];
            $code_id = $_REQUEST['id'];
            
             //retrieve enlistment information
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$code_id);
            $consumed = VerificationCodeConsumedByUser::model()->find($criteria); 
            
            
             //retrieve verification code information
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:listid';
            $criteria->params = array(':listid'=>$consumed['verification_code_id']);
            $code = EnlistmentVerificationCode::model()->find($criteria); 
            
             //retrieve enlistment information
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$code['enlistment_id']);
            $enlistment = UserEnlistmentRequest::model()->find($criteria); 
            
           
            
            if($consumed===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "enlistment" =>$enlistment,
                                    "code"=>$code
                                    
                    
                            ));
                       
                         }
            
        }
        
        
        /**
         * This is the function that list all product enlistment codes
         */
        public function actionlistThisEnlistmentAllVerificationCodes(){
            
            $enlistment_id = $_REQUEST['enlistment_id'];
            
             //retrieve verification code information
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='enlistment_id=:listid';
            $criteria->params = array(':listid'=>$enlistment_id);
            $codes = EnlistmentVerificationCode::model()->findAll($criteria); 
            
            if($codes===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "codes" =>$codes
                                                                        
                    
                            ));
                       
                         }
        }
}
