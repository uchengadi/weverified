<?php

class TreatyController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update', 'ListAllTreatiesForADomain', 'RetrieveTheDomainName',
                                    'ListAllDomainsForTreatyInitiation', 'RetrieveTheDomainNameAndItsMembers','InitiatingThisNewTreaty',
                                    'ListAllToolboxesForThisDomainForTreatyInitiation','RetrieveTheDomainNameAndItsMembersForEdit',
                                    'UpdateThisTreaty','RenewThisTreaty','TerminateThisTreaty','ActivateThisTreaty','ExtendThisTreaty',
                                    'ListAllTreatiesMadeWithThisDomain','AcceptOrRejectThisTreaty'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
	 * Displays a particular model.
	 * @param integer $id the ID of the model to be displayed
	 */
	public function actionView($id)
	{
		$this->render('view',array(
			'model'=>$this->loadModel($id),
		));
	}

	/**
	 * Creates a new model.
	 * If creation is successful, the browser will be redirected to the 'view' page.
	 */
	public function actionCreate()
	{
		$model=new Treaty;

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);

		if(isset($_POST['Treaty']))
		{
			$model->attributes=$_POST['Treaty'];
			if($model->save())
				$this->redirect(array('view','id'=>$model->id));
		}

		$this->render('create',array(
			'model'=>$model,
		));
	}
        
        /**
         * This is the function to create or initiate a new treaty
         */
        public function actionInitiatingThisNewTreaty(){
            
            $model=new Treaty;
                          
            $domainname = $_POST['domain'];
            $domainid = $this->determineDomainIdGivenItsName($domainname);
            $model->domain_id = $domainid;
            $model->resourcegroup_id = $_POST['resourcegroup_id'];
            $model->related_domain_id = $_POST['related_domain_id'];
            if(isset($_POST['group'])){
                $model->groups = $_POST['group'];
            }
            if(isset($_POST['description'])){
                $model->description = $_POST['description'];
            }
            if(isset($_POST['subgroup'])){
                 $model->subgroups = $_POST['subgroup'];
            }
           if(isset($_POST['user'])){
                $model->employees = $_POST['user'];
            }
           $model->treaty_start_date = date("Y-m-d H:i:s", strtotime($_POST['treaty_start_date']));
            $model->treaty_end_date = date("Y-m-d H:i:s", strtotime($_POST['treaty_end_date']));
            $model->status = 'inactive';
            $model->initiated_by = Yii::app()->user->id;
          
                      
            
            if($model->save()){
                         // $result['success'] = 'true';
                     $this->AssignDomainGroupsMembersToAnotherDomainInATreaty($model);
                     $this->AssignDomainSubgroupsMembersToAnotherDomainInATreaty($model);
                     $this->AssignDomainIndividualsMembersToAnotherDomainInATreaty($model);
                            $msg = 'New Treaty Successfully Initiated';
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                            );
                           
                       
                        
                 }else {
                         //$result['success'] = 'false';
                         $msg = 'New Treaty Not Initiated successful';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                  }  
            
            
            
            
        }
        
        /**
         * This is the function that saves the group items in a treaty
         */
        public function AssignDomainGroupsMembersToAnotherDomainInATreaty($treatymodel){
            
           $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('treaty_has_group')
                    ->where('treaty_id' == $treatymodel->id);
                $result = $cmd->queryScalar();
            
           if(isset($_POST['groupname'])){
               
               //confirm if this group item had already been assigned to this treaty before and delete it if so
               if($result > 0){
                         $cmd->delete('treaty_has_group', 'treaty_id=:id', array(':id'=>$treatymodel->id ));
                    
                     }
               
                     if(is_array($_POST['groupname'])) {
                            foreach($_POST['groupname'] as $group){ 
                                //convert group to the id given the group name
                                //$group_id = $this->determineGroupIdGivenGroupName($group,$treatymodel->domain_id);
                                   $cmd->insert('treaty_has_group',
                                        array(
                                           'treaty_id'=>$treatymodel->id,
                                           'group_id'=>$group 
                                              
                                        ));
                                      
                               
                             }
                             
                       }else{
                           
                           $group = $_POST['groupname'];
                          // $group_id = $this->determineGroupIdGivenGroupName($group, $treatymodel->domain_id);
                           $cmd->insert('treaty_has_group',
                                   array(
                                         'treaty_id'=>$treatymodel->id,
                                           'group_id'=>$group
                                              
                                    ));
                           
                       }
                      
                           
                       
               
           } //end of the isset function
            
        }
        
        /**
         * This is the function that saves the subgroup items in a treaty
         */
        public function AssignDomainSubgroupsMembersToAnotherDomainInATreaty($treatymodel){
            
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('treaty_has_subgroup')
                    ->where('treaty_id' == $treatymodel->id);
                $result = $cmd->queryScalar();
            
           if(isset($_POST['subgroupname'])){
               
               //confirm if this subgroup item had already been assigned to this treaty before and delete it if so
               if($result > 0){
                         $cmd->delete('treaty_has_subgroup', 'treaty_id=:id', array(':id'=>$treatymodel->id ));
                    
                     }
               
                     if(is_array($_POST['subgroupname'])) {
                            foreach($_POST['subgroupname'] as $subgroup){ 
                                 //$subgroup_id = $this->determineSubgroupIdGivenSubgroupName($subgroup, $treatymodel->domain_id);
                                   $cmd->insert('treaty_has_subgroup',
                                        array(
                                           'treaty_id'=>$treatymodel->id,
                                           'subgroup_id'=>$subgroup
                                              
                                        ));
                                      
                               
                             }
                             
                       }else{
                           
                           $subgroup = $_POST['subgroupname'];
                           //$subgroup_id = $this->determineSubgroupIdGivenSubgroupName($subgroup,$treatymodel->domain_id);
                           $cmd->insert('treaty_has_subgroup',
                                   array(
                                         'treaty_id'=>$treatymodel->id,
                                           'subgroup_id'=>$subgroup
                                              
                                    ));
                           
                       }
                      
                           
                       
               
           } //end of the isset function
            
            
        }
        
        
        /**
         * This is the function that saves the individual items in a treaty
         */
        public function AssignDomainIndividualsMembersToAnotherDomainInATreaty($treatymodel){
            
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('treaty_has_individual')
                    ->where('treaty_id' == $treatymodel->id);
                $result = $cmd->queryScalar();
            
           if(isset($_POST['username'])){
               
               //confirm if this user item had already been assigned to this treaty before and delete it if so
               if($result > 0){
                         $cmd->delete('treaty_has_individual', 'treaty_id=:id', array(':id'=>$treatymodel->id ));
                    
                     }
               
                     if(is_array($_POST['username'])) {
                            foreach($_POST['username'] as $user){  
                                 //$user_id = $this->determineUserIdGivenUserName($user);
                                   $cmd->insert('treaty_has_individual',
                                        array(
                                           'treaty_id'=>$treatymodel->id,
                                           'user_id'=>$user
                                              
                                        ));
                                      
                               
                             }
                             
                       }else{
                           
                           $user = $_POST['username'];
                          // $user_id = $this->determineUserIdGivenUserName($user);
                           $cmd->insert('treaty_has_individual',
                                   array(
                                         'treaty_id'=>$treatymodel->id,
                                           'user_id'=>$user
                                              
                                    ));
                           
                       }
                      
                           
                       
               
           } //end of the isset function
            
        }
        
        /**
         * This is the funcrion that is used to edit or update a treaty
         */
        public function actionUpdateThisTreaty(){
            
            $_id = $_POST['id'];
            
             $model=Treaty::model()->findByPk($_id);
             
            $domainname = $_POST['domain'];
            $domainid = $this->determineDomainIdGivenItsName($domainname);
            $related_domain = $_POST['related_domain_id'];
            $related_domain_id = $this->determineDomainIdGivenItsName($related_domain);
            $toolbox =$_POST['resourcegroup_id'];
            $toolboxid = $this->determineToolboxIdGivenItsName($toolbox);
            $model->domain_id = $domainid;       
            //$model->resourcegroup_id = $_POST['resourcegroup_id'];
            //$model->related_domain_id = $_POST['related_domain_id'];
            $model->resourcegroup_id = $toolboxid;
            $model->related_domain_id = $related_domain_id;
             if(isset($_POST['description'])){
                $model->description = $_POST['description'];
            }
            if(isset($_POST['group'])){
                $model->groups = $_POST['group'];
            }
            if(isset($_POST['subgroup'])){
                 $model->subgroups = $_POST['subgroup'];
            }
           if(isset($_POST['user'])){
                $model->employees = $_POST['user'];
            }
           $model->treaty_start_date = date("Y-m-d H:i:s", strtotime($_POST['treaty_start_date']));
            $model->treaty_end_date = date("Y-m-d H:i:s", strtotime($_POST['treaty_end_date']));
            $model->status = 'inactive';
            //$model->initiated_by = Yii::app()->user->id;
          
                      
            
            if($model->save()){
                         // $result['success'] = 'true';
                       $this->AssignDomainGroupsMembersToAnotherDomainInATreaty($model);
                       $this->AssignDomainSubgroupsMembersToAnotherDomainInATreaty($model);
                        $this->AssignDomainIndividualsMembersToAnotherDomainInATreaty($model);
                            $msg = 'Treaty Successfully Updated';
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                            );
                           
                       
                        
                 }else {
                         //$result['success'] = 'false';
                         $msg = 'Treaty Not Updated successful';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                  }  
             
            
            
        }
        
        /**
         * This is the funcrion that is used to edit or update a treaty
         */
        public function actionExtendThisTreaty(){
            
            $_id = $_POST['id'];
            
             $model=Treaty::model()->findByPk($_id);
             
            $domainname = $_POST['domain'];
            $domainid = $this->determineDomainIdGivenItsName($domainname);
            $related_domain = $_POST['related_domain_id'];
            $related_domain_id = $this->determineDomainIdGivenItsName($related_domain);
            $toolbox =$_POST['resourcegroup_id'];
            $toolboxid = $this->determineToolboxIdGivenItsName($toolbox);
            $model->domain_id = $domainid;       
            //$model->resourcegroup_id = $_POST['resourcegroup_id'];
            //$model->related_domain_id = $_POST['related_domain_id'];
            $model->resourcegroup_id = $toolboxid;
            $model->related_domain_id = $related_domain_id;
             if(isset($_POST['description'])){
                $model->description = $_POST['description'];
            }
            if(isset($_POST['group'])){
                $model->groups = $_POST['group'];
            }
            if(isset($_POST['subgroup'])){
                 $model->subgroups = $_POST['subgroup'];
            }
           if(isset($_POST['user'])){
                $model->employees = $_POST['user'];
            }
            $model->treaty_start_date = date("Y-m-d H:i:s", strtotime($_POST['treaty_start_date']));
            $model->treaty_end_date = date("Y-m-d H:i:s", strtotime($_POST['treaty_end_date']));
            $model->status = 'inactive';
            $model->acceptable= 0;
            $model->extended_by = Yii::app()->user->id;
            $model->date_extended = new CDbExpression('NOW()');
          
                      
            
            if($model->save()){
                         // $result['success'] = 'true';
                       $this->AssignDomainGroupsMembersToAnotherDomainInATreaty($model);
                       $this->AssignDomainSubgroupsMembersToAnotherDomainInATreaty($model);
                        $this->AssignDomainIndividualsMembersToAnotherDomainInATreaty($model);
                            $msg = 'Treaty Successfully Extended';
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                            );
                           
                       
                        
                 }else {
                         //$result['success'] = 'false';
                         $msg = 'Treaty Not Extended successful';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                  }  
             
            
            
        }
        
        
        /**
         * This is the funcrion that is used to renew a treaty
         */
        public function actionRenewThisTreaty(){
            
            $_id = $_POST['id'];
            
             $model=Treaty::model()->findByPk($_id);
             
            $domainname = $_POST['domain'];
            $domainid = $this->determineDomainIdGivenItsName($domainname);
            $related_domain = $_POST['related_domain_id'];
            $related_domain_id = $this->determineDomainIdGivenItsName($related_domain);
            $toolbox =$_POST['resourcegroup_id'];
            $toolboxid = $this->determineToolboxIdGivenItsName($toolbox);
            $model->domain_id = $domainid;       
            //$model->resourcegroup_id = $_POST['resourcegroup_id'];
            //$model->related_domain_id = $_POST['related_domain_id'];
            $model->resourcegroup_id = $toolboxid;
            $model->related_domain_id = $related_domain_id;
             if(isset($_POST['description'])){
                $model->description = $_POST['description'];
            }
            if(isset($_POST['group'])){
                $model->groups = $_POST['group'];
            }
            if(isset($_POST['subgroup'])){
                 $model->subgroups = $_POST['subgroup'];
            }
           if(isset($_POST['user'])){
                $model->employees = $_POST['user'];
            }
            
            $model->treaty_start_date = date("Y-m-d H:i:s", strtotime($_POST['treaty_start_date']));
            $model->treaty_end_date = date("Y-m-d H:i:s", strtotime($_POST['treaty_end_date']));
            $model->status = 'inactive';
            $model->renewal_initiated_by = Yii::app()->user->id;
            $model->date_of_current_renewal = new CDbExpression('NOW()');
            $model->acceptable = 0;
                    
            if($model->save()){
                         // $result['success'] = 'true';
                       $this->AssignDomainGroupsMembersToAnotherDomainInATreaty($model);
                       $this->AssignDomainSubgroupsMembersToAnotherDomainInATreaty($model);
                        $this->AssignDomainIndividualsMembersToAnotherDomainInATreaty($model);
                            $msg = 'Renewal of Treaty Successfully Initiated ';
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                            );
                           
                       
                        
                 }else {
                         //$result['success'] = 'false';
                         $msg = 'Renewal of Treaty Not Initiated Successful';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                  }  
             
            
            
        }
        
        
         /**
         * This is the funcrion that is used to activate a treaty
         */
        public function actionActivateThisTreaty(){
            
            $_id = $_POST['id'];
            
             $model=Treaty::model()->findByPk($_id);
             
            $domainname = $_POST['domain'];
            $domainid = $this->determineDomainIdGivenItsName($domainname);
            $related_domain = $_POST['related_domain_id'];
            $related_domain_id = $this->determineDomainIdGivenItsName($related_domain);
            $toolbox =$_POST['resourcegroup_id'];
            $toolboxid = $this->determineToolboxIdGivenItsName($toolbox);
            $model->domain_id = $domainid;       
            //$model->resourcegroup_id = $_POST['resourcegroup_id'];
            //$model->related_domain_id = $_POST['related_domain_id'];
            $model->resourcegroup_id = $toolboxid;
            $model->related_domain_id = $related_domain_id;
             if(isset($_POST['description'])){
                $model->description = $_POST['description'];
            }
            if(isset($_POST['group'])){
                $model->groups = $_POST['group'];
            }
            if(isset($_POST['subgroup'])){
                 $model->subgroups = $_POST['subgroup'];
            }
           if(isset($_POST['user'])){
                $model->employees = $_POST['user'];
            }
            
            $model->treaty_start_date = date("Y-m-d H:i:s", strtotime($_POST['treaty_start_date']));
            $model->treaty_end_date = date("Y-m-d H:i:s", strtotime($_POST['treaty_end_date']));
            $model->status = 'active';
            $model->activated_by = Yii::app()->user->id;
            $model->date_activated = new CDbExpression('NOW()');
            //$model->acceptable = $_POST['acceptable'];;
                    
            if($model->save()){
                         // $result['success'] = 'true';
                       $this->AssignDomainGroupsMembersToAnotherDomainInATreaty($model);
                       $this->AssignDomainSubgroupsMembersToAnotherDomainInATreaty($model);
                        $this->AssignDomainIndividualsMembersToAnotherDomainInATreaty($model);
                            $msg = 'Treaty Successfully Activated ';
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                            );
                           
                       
                        
                 }else {
                         //$result['success'] = 'false';
                         $msg = 'Activation not Successfully done';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                  }  
             
            
            
        }
        
        
        
        /**
         * This is the funcrion that is used to terminate a treaty
         */
        public function actionTerminateThisTreaty(){
            
            $_id = $_POST['id'];
            
             $model=Treaty::model()->findByPk($_id);
             
            $domainname = $_POST['domain'];
            $domainid = $this->determineDomainIdGivenItsName($domainname);
            $related_domain = $_POST['related_domain_id'];
            $related_domain_id = $this->determineDomainIdGivenItsName($related_domain);
            $toolbox =$_POST['resourcegroup_id'];
            $toolboxid = $this->determineToolboxIdGivenItsName($toolbox);
            $model->domain_id = $domainid;       
            //$model->resourcegroup_id = $_POST['resourcegroup_id'];
            //$model->related_domain_id = $_POST['related_domain_id'];
            $model->resourcegroup_id = $toolboxid;
            $model->related_domain_id = $related_domain_id;
             if(isset($_POST['description'])){
                $model->description = $_POST['description'];
            }
            if(isset($_POST['group'])){
                $model->groups = $_POST['group'];
            }
            if(isset($_POST['subgroup'])){
                 $model->subgroups = $_POST['subgroup'];
            }
           if(isset($_POST['user'])){
                $model->employees = $_POST['user'];
            }
            
            $model->treaty_start_date = date("Y-m-d H:i:s", strtotime($_POST['treaty_start_date']));
            $model->treaty_end_date = date("Y-m-d H:i:s", strtotime($_POST['treaty_end_date']));
            $model->status = 'terminated';
            $model->terminated_by = Yii::app()->user->id;
            $model->date_terminated = new CDbExpression('NOW()');
            $model->acceptable = 0;
           if(isset($_POST['termination_reason'])){
               $model->termination_reason = $_POST['termination_reason'];
           }
            
                    
            if($model->save()){
                         // $result['success'] = 'true';
                       $this->AssignDomainGroupsMembersToAnotherDomainInATreaty($model);
                       $this->AssignDomainSubgroupsMembersToAnotherDomainInATreaty($model);
                        $this->AssignDomainIndividualsMembersToAnotherDomainInATreaty($model);
                            $msg = 'Treaty Successfully Terminated ';
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                            );
                           
                       
                        
                 }else {
                         //$result['success'] = 'false';
                         $msg = 'Treaty Termination was notSuccessful';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                  }  
             
            
            
        }
        
        /**
         * This is the function to accept or reject a treaty
         */
        public function actionAcceptOrRejectThisTreaty(){
            
          $_id = $_POST['id'];
            
            $model=Treaty::model()->findByPk($_id);
            
            $model->acceptable =$_POST['acceptable'];
            $model->accepted_by = Yii::app()->user->id;
            
             if($model->acceptable == 1){
                   
                 if($model->save()){
               
                           $msg = 'Treaty Successfully Accepted ';
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                            );
                           
                       
                        
                 }else {
                         //$result['success'] = 'false';
                         $msg = 'Treaty Acceptance not Successful';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                  } 
                    
                    
                }else if($model->acceptable == 0){
                    
                    if($model->save()){
               
                           $msg = 'Treaty Successfully Rejected ';
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                            );
                           
                       
                        
                 }else {
                         //$result['success'] = 'false';
                         $msg = 'Treaty Rehection not Successful';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                  } 
                    
                    
                    
                    
                }
            
             
           
           
            
        }
        

	/**
	 * Updates a particular model.
	 * If update is successful, the browser will be redirected to the 'view' page.
	 * @param integer $id the ID of the model to be updated
	 */
	public function actionUpdate($id)
	{
		$model=$this->loadModel($id);

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);

		if(isset($_POST['Treaty']))
		{
			$model->attributes=$_POST['Treaty'];
			if($model->save())
				$this->redirect(array('view','id'=>$model->id));
		}

		$this->render('update',array(
			'model'=>$model,
		));
	}

	/**
	 * Deletes a particular model.
	 * If deletion is successful, the browser will be redirected to the 'admin' page.
	 * @param integer $id the ID of the model to be deleted
	 */
	public function actionDelete($id)
	{
		$this->loadModel($id)->delete();

		// if AJAX request (triggered by deletion via admin grid view), we should not redirect the browser
		if(!isset($_GET['ajax']))
			$this->redirect(isset($_POST['returnUrl']) ? $_POST['returnUrl'] : array('admin'));
	}

	/**
         * This is the function that list all treaties belonging to a domain
         */
        public function actionListAllTreatiesForADomain(){
            
            //obtain the id of the logged in user
            $userid = Yii::app()->user->id;
            
            //determine the domain of the logged in user
            $domainid = $this->determineAUserDomainIdGiven($userid);
            
            //spool the treaty for this domain
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='domain_id=:id';
            $criteria->params = array(':id'=>$domainid);
            $treaty= Treaty::model()->findAll($criteria);
            
            if($treaty===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "treaty" =>$treaty                    
                       ));
                       
                } 
        }
        
        
        
        /**
         * This is the function that list all treaties belonging to a domain
         */
        public function actionListAllTreatiesMadeWithThisDomain(){
            
            //obtain the id of the logged in user
            $userid = Yii::app()->user->id;
            
            //determine the domain of the logged in user
            $domainid = $this->determineAUserDomainIdGiven($userid);
            $domainid = 3;
            //spool the treaty for this domain
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='related_domain_id=:id and (status=:status and acceptable=:acceptable)';
            $criteria->params = array(':id'=>$domainid, ':status'=>"inactive", ':acceptable'=>0);
            $treaty= Treaty::model()->findAll($criteria);
            
            if($treaty===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "treaty" =>$treaty                    
                       ));
                       
                } 
        }
        
        
        /**
         * This is the function that returns the logged user domain 
         */
        public function actionRetrieveTheDomainNameAndItsMembers(){
            //obtain the id of the logged in user
            $userid = Yii::app()->user->id;
            
            //determine the domain of the logged in user
            $domainid = $this->determineAUserDomainIdGiven($userid);
            
            $domainname = $this->determineDomainNameGivenItId($domainid);
            
            //determine the grouptypeid of the logged in user given the domain name
            $grouptypeid = $this->determineGrouptypeIdGivenDomainName($domainname);
            
            //retrieve all groups in that grouptype
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='grouptype_id=:id';
            $criteria->params = array(':id'=>$grouptypeid);
            $groups= Group::model()->findAll($criteria);
            
            //foreach of the groups determine the subgroups
            $allsubgroups = [];
            
            foreach($groups as $group){
                
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='group_id=:id';
            $criteria1->params = array(':id'=>$group['id']);
            $subgroups= SubGroup::model()->findAll($criteria1); 
              
            $allsubgroups = array_merge($allsubgroups,$subgroups);
            }
            
            //determine the usertype of logged in user given the domain name
            $usertypeid = $this->determineAUserUsertypeId($userid);
            
            //retrieve all the users for that domain
            $criteria2 = new CDbCriteria();
            $criteria2->select = '*';
            $criteria2->condition='usertype_id=:id';
            $criteria2->params = array(':id'=>$usertypeid);
            $users= User::model()->findAll($criteria2); 
            
            
             if($domainname===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "domain" =>$domainname,  
                            "groups" =>$groups,
                           "subgroups" =>$allsubgroups,
                           "users" =>$users
                          
                       ));
                       
                } 
            
             
        }
        
        
        /**
         * This is the function that retrieves all the components of a treaty for the domain when editing
         */
        public function actionRetrieveTheDomainNameAndItsMembersForEdit(){
            
            //obtain the treaty id
            $id = $_POST['id'];
            $domainid = $_POST['domain_id'];
            $related_domainid = $_POST['related_domain_id']; 
            $toolboxid = $_POST['resourcegroup_id'];
            
            //the userid of the logged in user
            $userid = Yii::app()->user->id;
         
            $domainname = $this->determineDomainNameGivenItId($domainid);
            
            //obtain the name of the related domain
            $related_domainname = $this->determineDomainNameGivenItId($related_domainid);
            
            //obtain the name of the toolbox
            
            $toolboxname = $this->determineToolboxNameGivenItsId($toolboxid);
            
            //determine the grouptypeid of the logged in user given the domain name
            $grouptypeid = $this->determineGrouptypeIdGivenDomainName($domainname);
            
            //retrieve all groups in that grouptype
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='grouptype_id=:id';
            $criteria->params = array(':id'=>$grouptypeid);
            $groups= Group::model()->findAll($criteria);
            
            //foreach of the groups determine the subgroups
            $allsubgroups = [];
            
            foreach($groups as $group){
                
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='group_id=:id';
            $criteria1->params = array(':id'=>$group['id']);
            $subgroups= SubGroup::model()->findAll($criteria1); 
              
            $allsubgroups = array_merge($allsubgroups,$subgroups);
            }
            
            //determine the usertype of logged in user given the domain name
            $usertypeid = $this->determineAUserUsertypeId($userid);
            
            //retrieve all the users for that domain
            $criteria2 = new CDbCriteria();
            $criteria2->select = '*';
            $criteria2->condition='usertype_id=:id';
            $criteria2->params = array(':id'=>$usertypeid);
            $users= User::model()->findAll($criteria2); 
            
            
            //obtain the selected groups in this treaty
            
            $criteria3 = new CDbCriteria();
            $criteria3->select = 'treaty_id,group_id';
            $criteria3->condition='treaty_id=:id';
            $criteria3->params = array(':id'=>$id);
            $selectedgroups= TreatyHasGroup::model()->findAll($criteria3); 
            
            //obtain the selected subgroups
            $criteria4 = new CDbCriteria();
            $criteria4->select = 'treaty_id,subgroup_id';
            $criteria4->condition='treaty_id=:id';
            $criteria4->params = array(':id'=>$id);
            $selectedsubgroups= TreatyHasSubgroup::model()->findAll($criteria4); 
            
            
            //obtain the selected users
            $criteria5 = new CDbCriteria();
            $criteria5->select = 'treaty_id,user_id';
            $criteria5->condition='treaty_id=:id';
            $criteria5->params = array(':id'=>$id);
            $selectedusers= TreatyHasIndividual::model()->findAll($criteria5); 
     
             if($domainname===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "domain" =>$domainname,  
                            "groups" =>$groups,
                           "subgroups" =>$allsubgroups,
                           "users" =>$users,
                           "selectedgroups"=>$selectedgroups,
                           "selectedsubgroups"=>$selectedsubgroups,
                           "selectedusers"=>$selectedusers,
                           "relatedname"=>$related_domainname,
                           "toolboxname"=>$toolboxname
                          
                       ));
                       
                } 
            
             
        }
            
        

        
         /**
         * List all domains/categories in the platform for treaty initiation
         */
        public function actionListAllDomainsForTreatyInitiation(){
            
            //obtain the id of the logged in user
            $userid = Yii::app()->user->id;
            
            //determine the domain of the logged in user
            $domainid = $this->determineAUserDomainIdGiven($userid);
            
            //obtain the platform domain id
            $platformid = $this->determineDomainIdGivenItsName("Platform");
            
            //spool the treaty for this domain
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            //$criteria->condition='id!=:id and id!=:platform';
            $criteria->condition='id!=:id';
            $criteria->params = array(':id'=>$domainid);
            //$criteria->params = array(':id'=>$domainid, ':platform'=>$platformid);
            $category= ResourcegroupCategory::model()->findAll($criteria);
            
                if($category===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "domains" => $category,
                           // "category" =>$platformid,
                           
                           
                          
                       ));
                       
                }
            
            
        }
        
        
        /**
         * List all toolboxes/resourcegroup for this domain for treaty initiation
         */
        public function actionListAllToolboxesForThisDomainForTreatyInitiation(){
            
            //obtain the id of the logged in user
            $userid = Yii::app()->user->id;
            
            //determine the domain of the logged in user
            $domainid = $this->determineAUserDomainIdGiven($userid);
            
            //obtain the platform domain id
            //$platformid = $this->determineDomainIdGivenItsName("Platform");
            
            //spool the treaty for this domain
            $criteria = new CDbCriteria();
            $criteria->select = 'resourcegroup_id, category_id';
            $criteria->condition='category_id=:id';
            $criteria->params = array(':id'=>$domainid);
            $groups= ResourcegroupHasResourcegroupcategory::model()->findAll($criteria);
            
            $toolboxes = [];
            foreach($groups as $group){
                $criteria1 = new CDbCriteria();
                $criteria1->select = '*';
                $criteria1->condition='id=:id';
                $criteria1->params = array(':id'=>$group['resourcegroup_id']);
                $toolbox= Resourcegroup::model()->findAll($criteria1);
                 $toolboxes = array_merge($toolboxes, $toolbox);
                
            }
            
                if($toolboxes===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "toolboxes" => $toolboxes,
                           // "category" =>$platformid,
                           
                           
                          
                       ));
                       
                }
            
            
        }
        
        /**
         * Determine a domain id of a user given his user id 
         */
        public function determineAUserDomainIdGiven_old($userid){
            
            //determine the usertype id of the user
            $typeid = $this->determineAUserUsertypeId($userid);
            //determine the usertype name of this usertypeid
            $typename = $this->determineUserTypeName($typeid);
            
            //determine the domain id given usertype name
            $domainid = $this->determineDomainIdGiveUsertypeName($typename);
            
            //determine the domain name given its id
            $name = $this->determineDomainNameGivenItId($domainid);
            //determine the domain id given its name
            $domainname = $this->determineDomainIdGivenItsName($name);
            
            return $domainname;
            
            
        }
        
        
         /**
         * Determine a domain id of a user given his user id 
         */
        public function determineAUserDomainIdGiven($userid){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$userid);
            $user= User::model()->find($criteria1);
            
            return $user['domain_id'];
        }
        
        
              
        /**
         * this is the function that retrieves the grouptype id given domain name
         */
        public function determineGrouptypeIdGivenDomainName($domainname){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='name=:name';
            $criteria->params = array(':name'=>$domainname);
            $grouptypeid= GroupType::model()->find($criteria);
            
            return $grouptypeid['id'];
            
            
        }
           
        /**
         * Determine a users usertype_id
         */
        public function determineAUserUsertypeId($userid){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, usertype_id';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$userid);
            $usertype= User::model()->find($criteria);
            
            return $usertype['usertype_id'];
            
            
        }
        
        /*
         * Determine a usertype name given its id
         */
        public function determineUserTypeName($usertypeid){
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$usertypeid);
            $name= UserType::model()->find($criteria1);
            
            return $name['name'];
            
        }
        
        /*
         *  determine a usertype id given its name
         */
        public function determineUsertypeNameGiveId($usertypename){
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$usertypename);
            $id= UserType::model()->find($criteria1);
            
            return $id['id'];
        }
        
        /*
         * Determine a domain name given a usetypername
         */
        public function determineDomainNameGiveUsertypeName($usertypename){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$usertypename);
            $name= ResourcegroupCategory::model()->find($criteria1);
            
            return $name['name'];
            
        }
        
        /*
         * Determine a domain id given a usetypername
         */
        public function determineDomainIdGiveUsertypeName($usertypename){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$usertypename);
            $id= ResourcegroupCategory::model()->find($criteria1);
            
            return $id['id'];
            
        }
        
        
        /**
         * Determine a domain id given its name
         */
        public function determineDomainIdGivenItsName($name){
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$name);
            $id= ResourcegroupCategory::model()->find($criteria1);
            
            return $id['id'];
            
        }
        
        /**
         * Determine a domain name given its id
         */
        public function determineDomainNameGivenItId($domainid){
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$domainid);
            $name= ResourcegroupCategory::model()->find($criteria1);
            
            return $name['name'];
            
            
        }
        
        /**
         * This is the function that retrieves a resource/tool id given its name
         */
        public function determineResourceOrToolId($toolname){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$toolname);
            $id= Resources::model()->find($criteria1);
            
            return $id['id'];
            
        }
        
        
        /**
         * This is the function that retrieves a resource/tool name given its id
         */
        public function determineResourceOrToolName($toolid){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$toolid);
            $name= Resources::model()->find($criteria1);
            
            return $name['name'];
            
        }
        
        /**
         * This is the function that retrieves a resource/tool name given its id
         */
        public function determineGrouptypeGivenDomainId($domainid){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$domainid);
            $name= GroupType::model()->find($criteria1);
            
            return $name['name'];
            
        }
        
        /**
         * This is the function the retrieves a group id given the group name
         */
        public function determineGroupIdGivenGroupName($groupname,$domainid){
            
            //obtain the grouptype id given a domain id
            $grouptype_id = $this->determineGrouptypeIdGivenDomainId($domainid);
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='name=:name and grouptype_id=:id';
            $criteria->params = array(':name'=>$groupname, ':id'=>$grouptype_id);
            $id= Group::model()->find($criteria);
            
            return $id['id'];
            
            
        }
        
        /**
         * This is the function to retrieve subgroup id given subgroup name
         */
        public function determineSubgroupIdGivenSubgroupName($subgroupname, $domainid){
            //determine the group for this subgroup            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name, group_id';
            $criteria->condition='name=:name';
            $criteria->params = array(':name'=>$subgroupname);
            $groups= SubGroup::model()->findAll($criteria);
            
            foreach($groups as $group){
                $groupdomainid = $this->determineDomainIdGivenGroupId($group['group_id']);
                if($groupdomainid == $domainid){
                    $criteria1 = new CDbCriteria();
                    $criteria1->select = 'id, name';
                    $criteria1->condition='name=:name';
                    $criteria1->params = array(':name'=>$subgroupname);
                    $id= SubGroup::model()->find($criteria1);
                    
                     return $id['id'];
                    
                }
                
                
            }
            
           
            
        }
        
        /**
         * This is the function that determines grouptype is given domain id
         */
        public function determineGrouptypeIdGivenDomainId($domainid){
            
            //determine domain name
            $domainname = $this->determineDomainNameGivenItId($domainid);
            //Determine grouptype id given domain name
            $grouptypeid = $this->determineGrouptypeIdGivenDomainName($domainname);
            
            return $grouptypeid;
            
        }
        
        
        /**
         * This is the function that determines domain id given group id
         */
        public function determineDomainIdGivenGroupId($groupid){
            //determine grouptype id given group id
            $grouptypeid = $this->determineGrouptypeIdGivenGroupId($groupid);
            //determine domain id given grouptype id
            $domainid = $this->determineDomainIdGivenGrouptypeId($grouptypeid);
            
            return $domainid;
            
            
        }
        
        /**
         * This is the function that determines the grouptypeid given group id
         */
        public function determineGrouptypeIdGivenGroupId($groupid){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name, grouptype_id';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$groupid);
            $type= Group::model()->find($criteria);
            
            return $type['grouptype_id'];
            
        }
        
        /**
         * This is the function that returns domain id given grouptype id
         */
        public function determineDomainIdGivenGrouptypeId($grouptypeid){
            
            //determine the grouptype name
            $typename = $this->determineGrouptypeNameGivenGrouptypeId($grouptypeid);
            
            $domainname = $this->determineDomainNameGivenGrouptypeName($typename);
           
            //determine domain id given its id
            $domainid = $this->determineDomainIdGivenItsName($domainname);
            
            return $domainid;
            
            
        }
        
        /**
         * This is the function that determines grouptype name given its id
         **/
        public function determineGrouptypeNameGivenGrouptypeId($typeid){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$typeid);
            $type= GroupType::model()->find($criteria);
            
            return $type['name'];
            
        }
        
        /**
         * This is the function that determines domain name given grouptype name
         */
        public function determineDomainNameGivenGrouptypeName($typename){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='name=:name';
            $criteria->params = array(':name'=>$typename);
            $domain= ResourcegroupCategory::model()->find($criteria);
            
            return $domain['name'];
            
        }
        
        /**
         * This is the function that obtains a toolbox name given its id 
         */
        public function determineToolboxNameGivenItsId($toolboxid){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$toolboxid);
            $toolbox= Resourcegroup::model()->find($criteria);
            
            return $toolbox['name'];
            
        }
        
        
        /**
         * This is the function that obtains a toolbox id given its name
         */
        public function determineToolboxIdGivenItsName($toolboxname){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='name=:name';
            $criteria->params = array(':name'=>$toolboxname);
            $toolbox= Resourcegroup::model()->find($criteria);
            
            return $toolbox['id'];
            
        }
        
	/**
	 * Returns the data model based on the primary key given in the GET variable.
	 * If the data model is not found, an HTTP exception will be raised.
	 * @param integer $id the ID of the model to be loaded
	 * @return Treaty the loaded model
	 * @throws CHttpException
	 */
	public function loadModel($id)
	{
		$model=Treaty::model()->findByPk($id);
		if($model===null)
			throw new CHttpException(404,'The requested page does not exist.');
		return $model;
	}

	/**
	 * Performs the AJAX validation.
	 * @param Treaty $model the model to be validated
	 */
	protected function performAjaxValidation($model)
	{
		if(isset($_POST['ajax']) && $_POST['ajax']==='treaty-form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}
	}
}
