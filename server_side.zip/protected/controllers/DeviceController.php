<?php

class DeviceController extends Controller
{
	
        private $_id;
        /**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'. 'listalldevices'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update', 'ListDeviceForUserAssignmentUpdate','ListUserForDeviceBulkScheduling',
                                                'AssignDeviceToUser','ScheduleSingleDeviceToUser', 'ScheduleBulkDeviceToUser', 'ListAllDevicesInDevicetype',
                                    'ListAllDevicesForThisUser', 'ListDevicetypeForDeviceScheduling', 'ListDeviceForUserForSingleAssignment'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('listalldevices','deleteonedevice'),
				'users'=>array('@'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
	 * Displays a particular model.
	 * @param integer $id the ID of the model to be displayed
	 */
	public function actionView($id)
	{
		$this->render('view',array(
			'model'=>$this->loadModel($id),
		));
	}

	/**
	 * Creates a new model.
	 * If creation is successful, the browser will be redirected to the 'view' page.
	 */
	public function actionCreate()
	{
		
           $model=new Device;

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);

                $model->name = $_POST['name'];
                $model->devicetype_id = $_POST['devicetype'];
                $model->description = $_POST['description'];
                $model->status = $_POST['status'];
                $model->uuid = $_POST['uuid'];
                $model->create_time = new CDbExpression('NOW()');
                //$model->create_user_id = Yii::app()->user->id;
                
                if($_FILES['image']['name'] == null) {
                            
                        if($model->save()) {
                        // $result['success'] = 'true';
                         $msg = 'Creation of Device type was successful';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                           "success" => mysql_errno() == 0,
                             "msg" => $msg)
                       );
                         
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'Creation of Device type was  not successful';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                         
                         
                     }
                    
                    
                }else if($_FILES['image']['name'] != null) {
                    
                        if(isset($_FILES)){
                                 $tmpName = $_FILES['image']['tmp_name'];
                                 $fileName = $_FILES['image']['name'];
                                 $type = $_FILES['image']['type'];
                                 $size = $_FILES['image']['size'];
                  
                         }
                        if($fileName !== null) {
                                $iconFileName = time().'_'.$fileName;
                             $model->image = $iconFileName;
                         }
                        //Testing for the file extension and size
                             if($type === 'image/png'|| $type === 'image/jpg' || $type === 'image/jpeg'){
                                      if($size <= 256 * 256){
                                          if($model->save())
                                           {
                                                // upload the file
                                                if($fileName !== null) // validate to save file
                                                 $filepath = Yii::app()->params['icons'].$iconFileName;
                                                 move_uploaded_file($tmpName,  $filepath);
                           
                                              //  $result['success'] = 'true';
                                                 $msg = 'Creation of Device type was successful';
                                                 header('Content-Type: application/json');
                                                echo CJSON::encode(array(
                                                     "success" => mysql_errno() == 0,
                                                     "msg" => $msg)
                                                 );
                                            }else {
                                                 //$result['success'] = 'false';
                                                 $msg = 'Device type creation was not successfull.Check your input data';
                                                 header('Content-Type: application/json');
                                                 echo CJSON::encode(array(
                                                     "success" => mysql_errno() != 0,
                                                     "msg" => $msg)
                                                 );
                                            }
                                     }else {
                                         //$result['success'] = 'false';
                                        $msg = 'Failed. image/Image File is too large. Maximum size allowed is 65.5kb';
                                        header('Content-Type: application/json');
                                       echo CJSON::encode(array(
                                                     "success" => mysql_errno() != 0,
                                                     "msg" => $msg)
                                                 );                   
                                    }
                   
                         }else {
                                 //$result['success'] = 'false';
                                 $msg = 'Failed: Wrong File Type. Only jpeg, jpg or png file is allowed';
                                 header('Content-Type: application/json');
                                 echo CJSON::encode(array(
                                              "success" => mysql_errno() != 0,
                                              "msg" => $msg)
                                    );
                    
                    
                        }
                    
                    
                }//end of the if-else statement
	}

	/**
	 * Updates a particular model.
	 * If update is successful, the browser will be redirected to the 'view' page.
	 * @param integer $id the ID of the model to be updated
	 */
	public function actionUpdate()
	{
            // Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);
               
                $_name = $_POST['devicetype'];
                $criteria = new CDbCriteria();
                $criteria->select = 'id';
                $criteria->condition='name=:id';
                $criteria->params = array(':id'=>$_name);
                $devicetype_name = DeviceType::model()->find($criteria); 
				
				
		//update a device info
            	$_id = $_POST['id'];
		$model=Device::model()->findByPk($_id);
		$model->name = $_POST['name'];
		$model->devicetype_id = $devicetype_name->id;
		$model->description = $_POST['description'];
		$model->status = $_POST['status'];
		$model->uuid = $_POST['uuid'];
		$model->update_time = new CDbExpression('NOW()');
		//$model->update_user_id = Yii::app()->user->id;
		//$model->update_user_id = Yii::app()->user->id;
				
				
		if($_FILES['image']['name'] == null) {
                            
                   if($model->save()) {
                        // $result['success'] = 'true';
                         $msg = 'Update of Device Information was successful';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                           "success" => mysql_errno() == 0,
                             "msg" => $msg)
                       );
                         
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'Device Information update was unsuccessful';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                         
                         
                     }
                    
                    
                }else if($_FILES['image']['name'] != null) {
                    
                        if(isset($_FILES)){
                                 $tmpName = $_FILES['image']['tmp_name'];
                                 $fileName = $_FILES['image']['name'];
                                 $type = $_FILES['image']['type'];
                                 $size = $_FILES['image']['size'];
                  
                         }
                        if($fileName !== null) {
                                $iconFileName = time().'_'.$fileName;
                             $model->image = $iconFileName;
                         }
                        //Testing for the file extension and size
                             if($type === 'image/png'|| $type === 'image/jpg' || $type === 'image/jpeg'){
                                      if($size <= 256 * 256){
                                          if($model->save())
                                           {
                                                // upload the file
                                                if($fileName !== null) // validate to save file
                                                 $filepath = Yii::app()->params['icons'].$iconFileName;
                                                 move_uploaded_file($tmpName,  $filepath);
                           
                                              //  $result['success'] = 'true';
                                                 $msg = 'Update of Device Information was successful';
                                                 header('Content-Type: application/json');
                                                echo CJSON::encode(array(
                                                     "success" => mysql_errno() == 0,
                                                     "msg" => $msg)
                                                 );
                                            }else {
                                                 //$result['success'] = 'false';
                                                 $msg = 'Device Information update was not successfull.Check your input data';
                                                 header('Content-Type: application/json');
                                                 echo CJSON::encode(array(
                                                     "success" => mysql_errno() != 0,
                                                     "msg" => $msg)
                                                 );
                                            }
                                     }else {
                                         //$result['success'] = 'false';
                                        $msg = 'Update failed. image/Image File is too large. Maximum size allowed is 65.5kb';
                                        header('Content-Type: application/json');
                                       echo CJSON::encode(array(
                                                     "success" => mysql_errno() != 0,
                                                     "msg" => $msg)
                                                 );                   
                                    }
                   
                         }else {
                                 //$result['success'] = 'false';
                                 $msg = 'Failed: Wrong File Type. Only jpeg, jpg or png file is allowed';
                                 header('Content-Type: application/json');
                                 echo CJSON::encode(array(
                                              "success" => mysql_errno() != 0,
                                              "msg" => $msg)
                                    );
                    
                    
                        }
                    
                    
                }//end of the if-else statement
	}

	/**
	 * Deletes a particular model.
	 * If deletion is successful, the browser will be redirected to the 'admin' page.
	 * @param integer $id the ID of the model to be deleted
	 */
	public function actionDeleteOneDevice()
	{
            //Delete one device
            
            $_id = $_POST['id'];
            $model=Device::model()->findByPk($_id);
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->delete()){
                    $data['success'] = 'true';
                    $data['msg'] = 'The data was successfully deleted';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'deletion unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
           }
	}

	/**
	 * Lists all models.
	 */
	public function actionIndex()
	{
		$dataProvider=new CActiveDataProvider('Device');
		$this->render('index',array(
			'dataProvider'=>$dataProvider,
		));
	}

	/**
	 * list all Devices.
	 */
	public function actionListAllDevices()
	{
		$device = Device::model()->findAll();
                if($device===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode($device);
                       
                }
	}
        
        
        /**
          * listing all the resourcegroup items needed for the resourcegroup to 
          * subgroup assignment 
          */
         public function actionListDeviceForUserAssignmentUpdate()
	{
		
            $_id = $_REQUEST['user_id'];
            //$_id = 1;
            
            $criteria = new CDbCriteria();
             $criteria->select = 'id, name,uuid,select_value';
             $result = Device::model()->findAll($criteria);   
             
             $criteria2 = new CDbCriteria();
             $criteria2->select = 'user_id, device_id,assign_name, assign_description, isfirst_assignment, date_last_assigned, date_first_assigned';
             $criteria2->condition='user_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = UserHasDevice::model()->findAll($criteria2);
             
             $criteria3 = new CDbCriteria();
             $criteria3->select = 'id, email, username';
             $user = User::model()->findAll($criteria3);   
               
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                            "user" => $user  
                       ));
                       
                }
	}
        
        /**
         * listing all the usergroup items needed for the subgroup to 
         * user scheduling
         */
        public function actionListUserForDeviceBulkScheduling()
	{
		
             $_id = $_REQUEST['user_id'];
             //$_id = 1;
            
             $criteria = new CDbCriteria();
             $criteria->select = 'id, name,uuid, select_value';
             $result = Device::model()->findAll($criteria);   
             
             $criteria2 = new CDbCriteria();
             $criteria2->select = 'user_id, device_id';
             $criteria2->condition='user_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $assigned = UserHasDevice::model()->findAll($criteria2);
               
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "assigned" => $assigned,
                            "data" => $result)
                       );
                       
                } 
         } 
         
               /**
	 * Assign Users To Subgroup.
	 * If assignment is successful, close the window else insist for an assignment to be done.
	 */
	public function actionAssignDeviceToUser()
	{
		//$model=new GroupHasResourcegroup;

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);
                $_id = $_POST['id'];
                                             
                $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('user_has_device')
                    ->where('user_id' == $_id);
                $result = $cmd->queryScalar();
                
                if(isset($_POST['device'])){
                    if($result > 0){
                         $cmd->delete('user_has_device', 'user_id=:id', array(':id'=>$_id ));
                    
                     }
                    if (is_array($_POST['device'])) {
                            foreach($_POST['device'] as $value){                                                   
                                   $cmd->insert('user_has_device',
                                        array(
                                           'user_id'=>$_POST['id'],
                                           'assign_name'=>$_POST['assign_name'],
                                           'assign_description'=>$_POST['assign_description'],
                                           'device_id'=>$value 
                                              
                                        ));
                                      
                               
                             }
                             
                       }else {
                           $value = $_POST['device'];
                           $cmd->insert('user_has_device',
                                   array(
                                        'user_id'=>$_POST['id'],
                                        'assign_name'=>$_POST['assign_name'],
                                        'assign_description'=>$_POST['assign_description'],
                                        'device_id'=>$value 
                                              
                                    ));
                           
                       }
                      
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                       ));
                        
                    } else {
                        header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => 'Assignment not done as  no device was selected'
                          )); 
                        
                    }
                    
        }
                  
                          
         /**
	 * Schedule Device To User.
	 * If schedule is successful, close the window else insist on doing the single item 
           * scheduling.
	 */
	public function actionScheduleSingleDeviceToUser()
	{
		//$model=new UserHasDevice;

		 		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);
                $excluded_days = [];
                $_id = $_POST['user_id'];
                $min_date = date("Y-m-d H:i:s", strtotime($_POST['min_date'])); 
                $max_date = date("Y-m-d H:i:s", strtotime($_POST['max_date']));
                $start_date = date("Y-m-d H:i:s", strtotime($_POST['start_date']));
                $end_date = date("Y-m-d H:i:s", strtotime($_POST['end_date']));
                $device_id = $_POST['device_id'];
               
                
                if(isset($_POST['sunday'])){
                    $excluded_days[] = $_POST['sunday'];
                }
                if(isset($_POST['monday'])){
                    $excluded_days[] = $_POST['monday'];
                }
                if(isset($_POST['tuesday'])){
                    $excluded_days[] = $_POST['tuesday'];
                }
                if(isset($_POST['wednesday'])){
                    $excluded_days[] = $_POST['wednesday'];
                }
                if(isset($_POST['thursday'])){
                    $excluded_days[] = $_POST['thursday'];
                }
                if(isset($_POST['friday'])){
                    $excluded_days[] = $_POST['friday'];
                }
                if(isset($_POST['saturday'])){
                    $excluded_days[] = $_POST['saturday'];
                }
                 
                 
             
                //check if the start_date is less than the min_date
                $cmd =Yii::app()->db->createCommand();           
                if(($start_date >= $min_date) AND ($start_date <= $end_date)){
                   if(($end_date <= $max_date) AND ($end_date >= $start_date)){                
                       //perform the assignment table update here
                       $cmd->update('user_has_device',
                                    array('min_date'=>$min_date, 'max_date' =>$max_date, 'start_date'=>$start_date,
                                    'end_date'=>$end_date),
					 "user_id = $_id and device_id = $device_id"
                                     );
                      // if(isset($excluded_days)){
                         if(is_array($excluded_days) AND $excluded_days != NULL) {
                               $num = 0;
                               foreach($excluded_days as $value){
                                   if($value == 'Sunday' ) {
                                       $num = $num + 1;
                                        $cmd->update('user_has_device',
                                            array('excluded_days'=>'excluded_days'|$num),
                                             "user_id = $_id and  device_id = $device_id"
                                     );
                                   }elseif($value == 'Monday'){
                                       $num = $num + 2;
                                       $cmd->update('user_has_device',
                                            array('excluded_days'=>'excluded_days'|$num),
                                             "user_id = $_id and  device_id = $device_id"
                                        );       
                                       
                                   }elseif($value == 'Tuesday'){
                                       $num = $num + 4;
                                       $cmd->update('user_has_device',
                                            array('excluded_days'=>'excluded_days'|$num),
                                             "user_id = $_id and  device_id = $device_id"
                                        ); 
                                       
                                   } elseif($value == 'Wednesday'){
                                       $num = $num + 8;
                                       $cmd->update('user_has_device',
                                            array('excluded_days'=>'excluded_days'|$num),
                                             "user_id = $_id and  device_id = $device_id"
                                        ); 
                                       
                                   }elseif($value == 'Thursday'){
                                       $num = $num + 16;
                                       $cmd->update('user_has_device',
                                            array('excluded_days'=>'excluded_days'|$num),
                                             "user_id = $_id and  device_id = $device_id"
                                        ); 
                                       
                                   } elseif($value == 'Friday'){
                                       $num = $num + 32;
                                       $cmd->update('user_has_device',
                                            array('excluded_days'=>'excluded_days'|$num),
                                             "user_id = $_id and  device_id = $device_id"
                                        ); 
                                                                              
                                   }elseif($value == 'Saturday'){
                                       $num = $num + 64;
                                       $cmd->update('user_has_device',
                                            array('excluded_days'=>'excluded_days'|$num),
                                             "user_id = $_id and  device_id = $device_id"
                                        ); 
                                   
                                       
                                   }
                                       
                                       
                                                
                                  
                                   
                               }
                                                                                          
                           }elseif($excluded_days == NULL){
                                      // $num = $num + 64;
                                       $cmd->update('user_has_device',
                                             array('excluded_days'=>NULL),
                                             "user_id = $_id and  device_id = $device_id"
                                        ); 
                                   
                                       
                       }
                           
                     header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                       ));
                       
                   }else {
                        header('Content-Type: application/json');
                         echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => 'End Date is out of range with the Time to Live period or it is less than the Start Date'
                          )); 
                       
                   }             
                    
                }else {
                    header('Content-Type: application/json');
                         echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => 'Start Date is out of range with the Time To Live period or it is greater than the End Date'
                          )); 
                    
                    
                }
                
  
                
        }//end of single device to user scheduling function                       
           
        
        /**
	 * Schedule Bulk Device To User.
	 * If schedule is successful, close the window else insist on doing the a single item 
           * scheduling.
	 */
	public function actionScheduleBulkDeviceToUser()
	{
		//$model=new GroupHasResourcegroup;

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);
                $_id = $_POST['id'];
                $min_date = date("Y-m-d H:i:s", strtotime($_POST['min_date'])); 
                $max_date = date("Y-m-d H:i:s", strtotime($_POST['max_date']));
                $start_date = date("Y-m-d H:i:s", strtotime($_POST['start_date']));
                $end_date = date("Y-m-d H:i:s", strtotime($_POST['end_date']));
                //$resourcegroup_id = $_POST['resourcegroup_id'];
                //check if the start_date is less than the min_date
                $cmd =Yii::app()->db->createCommand();   
                if(($start_date >= $min_date) AND ($start_date <= $end_date)){
                    if(($end_date <= $max_date) AND ($end_date >= $start_date)){  
                        if(isset($_POST['device'])){
                            if(is_array($_POST['device'])) {
                                 foreach($_POST['device'] as $device){
                                     //save all the data into the database except the set the data type 
                                     $cmd->update('user_has_device',
                                             array('min_date'=>$min_date, 'max_date' =>$max_date, 'start_date'=>$start_date,
                                             'end_date'=>$end_date),
                                             "user_id = $_id and device_id = $device"
                                     );
                                     //update table to save the excluded_days data into the database
                                     if(isset($_POST['excluded_days'])){
                                         if(is_array($_POST['excluded_days'])) {
                                              $num = 0;
                                              foreach($_POST['excluded_days'] as $value){ 
                                                   if($value == 'sunday' ) {
                                                       $num = $num + 1;
                                                       $cmd->update('user_has_device',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                             "user_id = $_id and  device_id = $device"
                                                        );
                                                       
                                                       
                                                   }elseif ($value == 'monday') {
                                                       $num = $num + 2;
                                                       $cmd->update('user_has_device',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                            "user_id = $_id and  device_id = $device"
                                                        );  
                                                       
                                                       
                                                   }elseif ($value == 'tuesday'){
                                                        $num = $num + 4;
                                                        $cmd->update('user_has_device',
                                                        array('excluded_days'=>'excluded_days'|$num),
                                                            "user_id = $_id and  device_id = $device"
                                                        ); 
                                                       
                                                       
                                                   }elseif($value == 'wednesday'){
                                                       $num = $num + 8;
                                                       $cmd->update('user_has_device',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                         "user_id = $_id and  device_id = $device"
                                                       ); 
                                                       
                                                       
                                                   }elseif($value == 'thursday'){
                                                       $num = $num + 16;
                                                       $cmd->update('user_has_device',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                            "user_id = $_id and  device_id = $device"
                                                        ); 
                                                       
                                                   }elseif($value == 'friday'){
                                                       $num = $num + 32;
                                                       $cmd->update('user_has_device',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                            "user_id = $_id and  device_id = $device"
                                                         ); 
                                                       
                                                       
                                                   }elseif($value == 'saturday'){
                                                       $num = $num + 64;
                                                       $cmd->update('user_has_device',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                            "user_id = $_id and  device_id = $device"
                                                        ); 
                                                       
                                                       
                                                   }//end of the $value = saturday else if statement
                                                  
                                                  
                                              }//end of the foreach excluded_days statement
                                             
                                             
                                         }else {
                                             
                                             //update the bridge/assignment table when checkbox is not an array
                                             $value = $_POST['excluded_days'];
                                             $num = 0;
                                             if($value == 'sunday'){
                                                $num = $num + 1;
                                                update('user_has_device',
                                                    array('excluded_days'=>'excluded_days'|$num),
                                                        "user_id = $_id and  device_id = $device"
                                                );  
                                   
                                                }elseif($value == 'monday'){
                                                    $num = $num + 2;
                                                    update('user_has_device',
                                                        array('excluded_days'=>'excluded_days'|$num),
                                                            "user_id = $_id and  device_id = $device"
                                                        ); 
                                   
                                                }elseif($value == 'tuesday'){
                                                    $num = $num + 4;
                                                    update('user_has_device',
                                                         array('excluded_days'=>'excluded_days'|$num),
                                                             "user_id = $_id and  device_id = $device"
                                                    ); 
                                   
                                                }elseif($value == 'wednesday'){
                                                    $num = $num + 8;
                                                    update('user_has_device',
                                                    array('excluded_days'=>'excluded_days'|$num),
                                                        "user_id = $_id and  device_id = $device"
                                                    ); 
                                   
                                                }elseif($value == 'thursday'){
                                                     $num = $num + 16;
                                                     update('user_has_device',
                                                     array('excluded_days'=>'excluded_days'|$num),
                                                        "user_id = $_id and  device_id = $device"
                                                    ); 
                                   
                                                }elseif($value == 'friday'){
                                                    $num = $num + 32;
                                                    update('user_has_device',
                                                    array('excluded_days'=>'excluded_days'|$num),
                                                        "user_id = $_id and  device_id = $device"
                                                ); 
                                   
                                                }elseif($value == 'saturday'){
                                                    $num = $num + 64;
                                                    update('user_has_device',
                                                        array('excluded_days'=>'excluded_days'|$num),
                                                             "user_id = $_id and  device_id = $device"
                                                ); 
                                   
                                                }
                                             
                                             
                                         }//end of the excluded_days is_assay if-else statement
                                         
                                         
                                     }//end of the excluded_days isset if statement
                             
                                }//end of the resourcegroup array  foreach statement
                                
                         
                            } else { //end of resourcegroup is_array if  statement
                                $device = $_POST['device'];
                                $cmd->update('user_has_device',
                                             array('min_date'=>$min_date, 'max_date' =>$max_date, 'start_date'=>$start_date,
                                             'end_date'=>$end_date),
                                             "user_id = $_id and device_id = $device"
                                  );
                                  if(isset($_POST['excluded_days'])){
                                         if(is_array($_POST['excluded_days'])) {
                                              $num = 0;
                                              foreach($_POST['excluded_days'] as $value){ 
                                                   if($value == 'sunday' ) {
                                                       $num = $num + 1;
                                                       $cmd->update('user_has_device',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                             "user_id = $_id and  device_id = $device"
                                                        );
                                                       
                                                       
                                                   }elseif ($value == 'monday') {
                                                       $num = $num + 2;
                                                       $cmd->update('user_has_device',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                            "user_id = $_id and  device_id = $device"
                                                        );  
                                                       
                                                       
                                                   }elseif ($value == 'tuesday'){
                                                        $num = $num + 4;
                                                        $cmd->update('user_has_device',
                                                        array('excluded_days'=>'excluded_days'|$num),
                                                            "user_id = $_id and  device_id = $device"
                                                        ); 
                                                       
                                                       
                                                   }elseif($value == 'wednesday'){
                                                       $num = $num + 8;
                                                       $cmd->update('user_has_device',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                         "user_id = $_id and  device_id = $device"
                                                       ); 
                                                       
                                                       
                                                   }elseif($value == 'thursday'){
                                                       $num = $num + 16;
                                                       $cmd->update('user_has_device',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                            "user_id = $_id and  device_id = $device"
                                                        ); 
                                                       
                                                   }elseif($value == 'friday'){
                                                       $num = $num + 32;
                                                       $cmd->update('user_has_device',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                            "user_id = $_id and  device_id = $device"
                                                         ); 
                                                       
                                                       
                                                   }elseif($value == 'saturday'){
                                                       $num = $num + 64;
                                                       $cmd->update('user_has_device',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                            "user_id = $_id and  device_id = $device"
                                                        ); 
                                                       
                                                       
                                                   }//end of the $value = saturday else if statement
                                                  
                                                  
                                              }//end of the foreach excluded_days statement
                                             
                                             
                                         }else {
                                             
                                             //update the bridge/assignment table when checkbox is not an array
                                             $value = $_POST['excluded_days'];
                                             $num = 0;
                                             if($value == 'sunday'){
                                                $num = $num + 1;
                                                update('user_has_device',
                                                    array('excluded_days'=>'excluded_days'|$num),
                                                        "user_id = $_id and  device_id = $device"
                                                );  
                                   
                                                }elseif($value == 'monday'){
                                                    $num = $num + 2;
                                                    update('user_has_device',
                                                        array('excluded_days'=>'excluded_days'|$num),
                                                            "user_id = $_id and  device_id = $device"
                                                        ); 
                                   
                                                }elseif($value == 'tuesday'){
                                                    $num = $num + 4;
                                                    update('user_has_device',
                                                         array('excluded_days'=>'excluded_days'|$num),
                                                             "user_id = $_id and  device_id = $device"
                                                    ); 
                                   
                                                }elseif($value == 'wednesday'){
                                                    $num = $num + 8;
                                                    update('user_has_device',
                                                    array('excluded_days'=>'excluded_days'|$num),
                                                        "user_id = $_id and  device_id = $device"
                                                    ); 
                                   
                                                }elseif($value == 'thursday'){
                                                     $num = $num + 16;
                                                     update('user_has_device',
                                                     array('excluded_days'=>'excluded_days'|$num),
                                                        "user_id = $_id and  device_id = $device"
                                                    ); 
                                   
                                                }elseif($value == 'friday'){
                                                    $num = $num + 32;
                                                    update('user_has_device',
                                                    array('excluded_days'=>'excluded_days'|$num),
                                                        "user_id = $_id and  device_id = $device"
                                                ); 
                                   
                                                }elseif($value == 'saturday'){
                                                    $num = $num + 64;
                                                    update('user_has_device',
                                                        array('excluded_days'=>'excluded_days'|$num),
                                                             "user_id = $_id and  device_id = $device"
                                                ); 
                                   
                                                }
                                             
                                             
                                         }//end of the excluded_days is_assay if-else statement
                                         
                                         
                                     }// end of the excluded_day isset statement for non-array resourcegroup
                                
                                
                            }//end of resourcegroup is_array if else  statement
                             header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                     "success" => mysql_errno() == 0,
                             ));
                            
                    
                }else{
                    header('Content-Type: application/json');
                          echo CJSON::encode(array(
                          "success" => mysql_errno() != 0,
                           "msg" => "Select at least one item in the resourcegroup to schedule"   
                      ));
                    
                    
                }//end of resourcegroup isset if-else statement 
                        
                        
                        
         }else {
               header('Content-Type: application/json');
                     echo CJSON::encode(array(
                         "success" => mysql_errno() != 0,
                         "msg" => 'End Date is out of range with the Time to Live period or it is less than the Start Date'
                      )); 
                        
                        
          }//end of end_date check if-else statement
                    
                    
          }else{
              header('Content-Type: application/json');
                  echo CJSON::encode(array(
                     "success" => mysql_errno() != 0,
                     "msg" => 'Start Date is out of range with the Time To Live period or it is greater than the End Date'
               ));  
                    
                    
                    
          }//end of start_date check if-else  statement
          
        }//end of bulk device to user scheduling function 
            
        
        
        /**
	 * List all the devices that belong to a particular devicetype
	 */
	public function actionListAllDevicesInDevicetype()
	{
		
                $_id = $_REQUEST['id'];
                //$_id = 3;
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='devicetype_id=:id';
                $criteria->params = array(':id'=>$_id);
                $device= Device::model()->findAll($criteria);
                if($device===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode($device);
                       
                }
	}
        
        
           /**
	 * List all the users in the subgroup
	 */
	public function actionListAllDevicesForThisUser()
	{
		
                $_id = $_REQUEST['id'];
                //$_id = 1;
                $criteria = new CDbCriteria();
                $criteria->select = 'device_id, user_id,  max_date,min_date, start_date, end_date, excluded_days';
                $criteria->condition='user_id=:id';
                $criteria->params = array(':id'=>$_id);
                $devices= UserHasDevice::model()->findAll($criteria);
                
               if($devices===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode($devices);
                       
                }
        }  
        
        
        /**
	 * get a group name  given a group id
	 */
	public function actionListDevicetypeForDeviceScheduling()
	{
		
             $devicetype_id = $_REQUEST['devicetype_id'];
             //$_id = 1;
            
             $criteria = new CDbCriteria();
             $criteria->select = 'id, name';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$devicetype_id);
             $devicetype = DeviceType::model()->findAll($criteria);   
             
             
               
                if($devicetype===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "devicetype" => $devicetype)
                       );
                       
                } 
               
               
	}
        
        
        /**
	 * List  the device for this user for single assignment
	 */
	public function actionListDeviceForUserForSingleAssignment()
	{
		
             $user_id = $_REQUEST['user_id'];
             $device_id = $_REQUEST['device_id'];
             //$_id = 1;
            
             $criteria = new CDbCriteria();
             $criteria->select = 'id, name';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$user_id);
             $user = User::model()->findAll($criteria);   
             
             $criteria2 = new CDbCriteria();
             $criteria2->select = 'id, name';
             $criteria2->condition='id=:id';
             $criteria2->params = array(':id'=>$resourcegroup_id);
             $device = Device::model()->findAll($criteria2);
             
             $criteria3 = new CDbCriteria();
             $criteria3->select = 'assign_name, assign_description';
             $criteria3->condition='device_id=:id AND user_id=:user';
             $criteria3->params = array(':id'=>$device_id, ':user'=>$user_id);
             $assignment = UserHasDevice::model()->findAll($criteria3);
               
                if($user===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "device" => $device,
                            "user" => $user,
                           "assignment"=> $assignment)
                       );
                       
                } 
               
               
	}
               

	/**
	 * Returns the data model based on the primary key given in the GET variable.
	 * If the data model is not found, an HTTP exception will be raised.
	 * @param integer $id the ID of the model to be loaded
	 * @return Device the loaded model
	 * @throws CHttpException
	 */
	public function loadModel($id)
	{
		$model=Device::model()->findByPk($id);
		if($model===null)
			throw new CHttpException(404,'The requested page does not exist.');
		return $model;
	}

	/**
	 * Performs the AJAX validation.
	 * @param Device $model the model to be validated
	 */
	protected function performAjaxValidation($model)
	{
		if(isset($_POST['ajax']) && $_POST['ajax']==='device-form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}
	}
}
