<?php

class DomainLocationsController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','addnewlocation','addnewlocation','updatelocation','deletealocation',
                                    'listalldomainlocations','ListAllDomainPendingPayments','listalllocations'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	
        /**
         * This is the function that creates new domain location
         */
        public function actionaddnewlocation(){
           
            $model = new DomainLocations;
            $user_id = Yii::app()->user->id;
            
            //get the domain id of this user
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            
            $model->name = $_POST['name'];
            
            $model->address = $_POST['address'];
            
            $model->domain_id = $domain_id;
            
             if($model->save()) {
                        
                   $msg = "'$model->name' branch/location was created successful";
                   header('Content-Type: application/json');
                         echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                         "msg" => $msg)
                   );
                         
            }else{
                $msg = 'Validaion Error: Check your file fields for correctness';
                    header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                "success" => mysql_errno() != 0,
                                "msg" => $msg)
                               );
            }
            
            
            
            
        }
        
        
        /**
         * This is the function that updates location/branch information
         */
        public function actionupdatelocation(){
             $_id = $_POST['id'];
            
            $model = DomainLocations::model()->findByPk($_id); 
            
             $model->name = $_POST['name'];
            
            $model->address = $_POST['address'];
            
            $model->domain_id = $_POST['domain_id'];
            
             if($model->save()) {
                        
                   $msg = "'$model->name' branch/location was updated successful";
                   header('Content-Type: application/json');
                         echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                         "msg" => $msg)
                   );
                         
            }else{
                $msg = 'Validaion Error: Check your file fields for correctness';
                    header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                "success" => mysql_errno() != 0,
                                "msg" => $msg)
                               );
            }
            
        }
        
        
        
        /**
         * This is the function that deletes a location 
         */
        public function actiondeletealocation(){
            
          $_id = $_POST['id'];
            $model=  DomainLocations::model()->findByPk($_id);
            
            //get the country name
            $location_name = $model->getThisLocationName($_id);
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->delete()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$location_name' was successfully deleted";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'deletion was unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                }
            
        }
        
        
        
        /**
         * This is the function that list all locations for a domain
         */
        public function actionlistalldomainlocations(){
             $user_id = Yii::app()->user->id;
             //get the domain id of this user
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='domain_id=:domainid';   
             $criteria->params = array(':domainid'=>$domain_id);
             $locations = DomainLocations::model()->findAll($criteria);
             
             
              if($locations===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "location" => $locations
                          
                           
                           
                          
                       ));
                       
                }
            
            
        }
        
        
        
        
        
         /**
         * Determine a domain id of a user given his user id 
         */
        public function determineAUserDomainIdGiven($userid){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$userid);
            $user= User::model()->find($criteria1);
            
            return $user['domain_id'];
        }
        
        
        
        /**
         * This is the function that list all locations
         */
        public function actionlistalllocations(){
             $user_id = Yii::app()->user->id;
             //get the domain id of this user
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $locations = DomainLocations::model()->findAll($criteria);
             
             
              if($locations===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "location" => $locations
                          
                           
                           
                          
                       ));
                       
                }
            
            
        }
        
        
     
}
