<?php

class DomainVerificationRequestController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','listThisDomainPendingVerificationRequest','listThisDomainVerifiedVerificationRequest',
                                    'listThisDomainUnverifiedVerificationRequest','listAllDomainPendingVerificationRequest','listAllDomainVerifiedVerificationRequest',
                                    'listAllDomainUnVerifiedVerificationRequest','retrieveextradomainverificationinfo','freezethisdomainverificationrequest'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that list all pending request for a domain
         */
        public function actionlistThisDomainPendingVerificationRequest(){
            $model = new User;
            
            $user_id = Yii::app()->user->id;
            
            $domain_id = $model->determineAUserDomainIdGiven($user_id);
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='requestor_domain_id=:domainid and status=:status';
            $criteria->params = array(':domainid'=>$domain_id,':status'=>'requested');
            $verifications = DomainVerificationRequest::model()->findAll($criteria); 
            
            if($verifications===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "request" => $verifications,
                                    
                    
                            ));
                       
                         }
            
        }
        
        
        /**
         * This is the function that list verified request for a domain
         */
        public function actionlistThisDomainVerifiedVerificationRequest(){
            
            $model = new User;
            
            $user_id = Yii::app()->user->id;
            
            $domain_id = $model->determineAUserDomainIdGiven($user_id);
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='requestor_domain_id=:domainid and status=:status';
            $criteria->params = array(':domainid'=>$domain_id,':status'=>'verified');
            $verifications = DomainVerificationRequest::model()->findAll($criteria); 
            
            if($verifications===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "request" => $verifications,
                                    
                    
                            ));
                       
                         }
            
        }
        
        /**
         * This is the function that list  unverified request for a domain
         */
        public function actionlistThisDomainUnverifiedVerificationRequest(){
           
            $model = new User;
            
            $user_id = Yii::app()->user->id;
            
            $domain_id = $model->determineAUserDomainIdGiven($user_id);
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='requestor_domain_id=:domainid and status=:status';
            $criteria->params = array(':domainid'=>$domain_id,':status'=>'not_verified');
            $verifications = DomainVerificationRequest::model()->findAll($criteria); 
            
            if($verifications===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "request" => $verifications,
                                    
                    
                            ));
                       
                         }
            
        }
        
        
        /**
         * This is the functioon that list all domains pending request
         */
        public function actionlistAllDomainPendingVerificationRequest(){
                  
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='status=:status';
            $criteria->params = array(':status'=>'requested');
            $verifications = DomainVerificationRequest::model()->findAll($criteria); 
            
            if($verifications===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "request" => $verifications,
                                    
                    
                            ));
                       
                         }
            
        }
        
        
        
        
        /**
         * This is the functioon that list all domains verified request
         */
        public function actionlistAllDomainVerifiedVerificationRequest(){
                  
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='status=:status';
            $criteria->params = array(':status'=>'verified');
            $verifications = DomainVerificationRequest::model()->findAll($criteria); 
            
            if($verifications===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "request" => $verifications,
                                    
                    
                            ));
                       
                         }
            
        }
        
        
        
         /**
         * This is the functioon that list all domains unverified request
         */
        public function actionlistAllDomainUnVerifiedVerificationRequest(){
                  
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='status=:status';
            $criteria->params = array(':status'=>'not_verified');
            $verifications = DomainVerificationRequest::model()->findAll($criteria); 
            
            if($verifications===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "request" => $verifications,
                                    
                    
                            ));
                       
                         }
            
        }
        
        
        /**
         * This is the function that retrieves extra domain verification parametser
         */
        public function actionretrieveextradomainverificationinfo(){
            $domain_id = $_REQUEST['domain_id'];
            
            //retrieve domain information
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$domain_id);
            $domain = Resourcegroupcategory::model()->find($criteria); 
            
            //retrieve domain verification request parameters
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='domain_id=:domainid';
            $criteria->params = array(':domainid'=>$domain_id);
            $verifications = DomainVerificationOutcome::model()->find($criteria); 
            
            if($domain_id===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "domain" => $domain,
                                    "request"=>$verifications
                                    
                    
                            ));
                       
                         }
        }
        
        
        /**
         * This is the function that freezes a domain verification request before the commencement of verification exercise
         */
        public function actionfreezethisdomainverificationrequest(){
            $model = new DomainVerificationRequest;
            $domain_id = $_REQUEST['domain_id'];
            
            if($model->isTheFreezingOfThisDomainVerificationRequestASuccess($domain_id)){
                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "msg" => "This domain verification request is frozen successfully"
                                   
                            ));
                
            }else{
                 header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                    "msg" => "Attempt to freeze this domain verification request was not successfully. You may however still go ahead with the verification exercise"
                                    
                                   
                            ));
                
            }
            
        }
        
        
        
        

}
