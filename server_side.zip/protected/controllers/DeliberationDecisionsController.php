<?php

class DeliberationDecisionsController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','retrievethisMessageDeliberationDecision'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that retrieves all the adopters of a message
         */
        public function actionretrievethisMessageDeliberationDecision(){
            
            $model = new DeliberationDecisions;
            
            $user_id = Yii::app()->user->id;
            
             $domain_id = $model->determineAUserDomainIdGiven($user_id);
            
            $message_id = $_REQUEST['message_id'];
            
            $group_id = $_REQUEST['group_id'];
            
            $asset_id = $_REQUEST['asset_id'];
            
           
            
            //get all the deliberations of this message
            $deliberations = $this->getAllOfThisMessageOrAssetDeliberations($message_id,$asset_id);
            $adopted = [];
            foreach($deliberations as $deli){
                if($model->isDeliberationAdopted($deli,$group_id,$user_id)){
                    if($model->isDeliberationAlreadyInDecision($deli) == false){
                         //add deliberation to the decision table
                        if($model->isAddingThisDeliberationToTheDecisionBoardASuccess($deli,$group_id)){
                            $adopted[] = $deli;
                        } 
                    }
                   
                }
                
            }
            $decisions = [];
            
            //retrieve all the message decision
              foreach($adopted as $adopt){
                 $criteria = new CDbCriteria();
                 $criteria->select = '*';
                 $criteria->condition='deliberation_id=:delid';
                 $criteria->params = array(':delid'=>$adopt);
                 $decision= DeliberationDecisions::model()->find($criteria);
                 $decisions[] = $decision;
             }
            
           if($deliberations===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                }else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "decision" => $decisions,
                     
                       ));
                       
                }  
            
        }
        
        
        /**
         * This is the function tgat gets all deliberations of a message
         */
        public function  getAllOfThisMessageOrAssetDeliberations($message_id, $asset_id){
            $model= new MessageDeliberation;
            return $model->getAllOfThisMessageOrAssetDeliberations($message_id, $asset_id);
        }
}
