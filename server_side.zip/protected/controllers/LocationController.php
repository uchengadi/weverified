<?php

class LocationController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','AddNewLocation','UpdateLocation','DeleteOneLocation',
                                    'listDomainLocations','listPlatformLocations'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}
        
        
        
        /**
         * This is the function that adds new location to a domain
         */
        public function actionAddNewLocation(){
            
            $model = new Location;
            
            $user_id = Yii::app()->user->id;
            
            $domain_id = $this->getTheDomainIdOfThisUser($user_id);
            
            $domain_name = $this->getTheNameOfThisDomain($domain_id);
            
            $model->name = $_POST['name'];
            $model->category = strtolower($_POST['this_category']);
            $model->description = $_POST['description'];
            $model->type = strtolower($_POST['this_type']);
            if(isset($_POST['person_in_charge'])){
                $model->user_in_charge_id = $_POST['person_in_charge'];
            }
            $model->address1 = $_POST['address1'];
            $model->address2 = $_POST['address2'];
            $model->domain_id = $domain_id;
            $model->create_time = new CDbExpression('NOW()');
            $model->create_user_id = Yii::app()->user->id;
            
            if($model->save()){
               $msg = "Successfully added '$model->name' location to this '$domain_name' domain";
               header('Content-Type: application/json');
               echo CJSON::encode(array(
                      "success" => mysql_errno() == 0,
                       "msg" => $msg
                       ));
           }else{
                $msg = "'$model->name' location could not be added to the '$domain_name' domain";
               header('Content-Type: application/json');
               echo CJSON::encode(array(
                      "success" => mysql_errno() != 0,
                       "msg" => $msg
                       ));
           } 
            
            
        }
        
        
        
        /**
         * This is the function that gets the domain id of a user
         */
        public function getTheDomainIdOfThisUser($user_id){
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$user_id);
             $domain = User::model()->find($criteria);   
             
             return $domain['domain_id'];
        }
        
        
        /**
         * This  is the function that gets the name of a domain
         */
        public function getTheNameOfThisDomain($domain_id){
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$domain_id);
             $domain = Resourcegroupcategory::model()->find($criteria);   
             
             return $domain['name'];
        }
        
        /**
         * This is the function that updates a  location information
         * 
         */
        public function actionUpdateLocation(){
            
            $_id = $_POST['id'];
            $model=Location::model()->findByPk($_id);
            
            $user_id = Yii::app()->user->id;
            
            $domain_id = $this->getTheDomainIdOfThisUser($user_id);
            
            $domain_name = $this->getTheNameOfThisDomain($domain_id);
            
            $model->name = $_POST['name'];
            $model->category = strtolower($_POST['this_category']);
            $model->description = $_POST['description'];
            $model->type = strtolower($_POST['this_type']);
            if(is_numeric($_POST['person_in_charge'])){
                 $model->user_in_charge_id = $_POST['person_in_charge'];
            }else{
                 $model->user_in_charge_id = $_POST['user_in_charge_id'];
            }
            $model->address1 = $_POST['address1'];
            $model->address2 = $_POST['address2'];
            $model->domain_id = $domain_id;
            $model->update_time = new CDbExpression('NOW()');
            $model->update_user_id = Yii::app()->user->id;
            
            if($model->save()){
               $msg = "Successfully updated '$model->name' location in this '$domain_name' domain";
               header('Content-Type: application/json');
               echo CJSON::encode(array(
                      "success" => mysql_errno() == 0,
                       "msg" => $msg
                       ));
           }else{
                $msg = "'$model->name' location in the '$domain_name' domain could not be updated";
               header('Content-Type: application/json');
               echo CJSON::encode(array(
                      "success" => mysql_errno() != 0,
                       "msg" => $msg
                       ));
           } 
            
            
            
            
        }
        
        
        /**
         * This is the function that deletes a location 
         */
        public function actionDeleteOneLocation(){
            
            $_id = $_POST['id'];
            //get the name of this location
            $location_name = $this->getLocationName($_id);
            $model=Location::model()->findByPk($_id);
            if($model === null){
                 $msg = 'No Such Record Exist'; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                                      
            }else if($model->delete()){
                    $msg = "'$location_name' location was successfully deleted"; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                       
            } else {
                    $msg = "'$location_name' location could not be deleted"; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                            
                }
            
        }
        
        
        
        /**
         * This is the function that determines the name of a location
         */
        public function getLocationName($id){
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$id);
             $location = Location::model()->find($criteria);   
             
             return $location['name'];
            
        }
        
        /**
         * This is the function that lists all locations in a domain
         */
        public function actionlistDomainLocations(){
            
           $user_id = Yii::app()->user->id;
            
           $domain_id =  $this->getTheDomainIdOfThisUser($user_id);
           
                     
           $criteria = new CDbCriteria();
           $criteria->select = '*';
           $criteria->condition='domain_id=:domainid';
           $criteria->params = array(':domainid'=>$domain_id);
           $locations =Location::model()->findAll($criteria);
                 
           if($locations===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "location" => $locations
            
                       ));
                       
                }
            
            
        }

        
        
        /**
         * This is the function that list all locations in the platform
         */
        public function actionlistPlatformLocations(){
            
               $criteria = new CDbCriteria();
               $criteria->select = '*';
              // $criteria->condition='type!=:type';
              // $criteria->params = array(':type'=>'special_report');
               $locations =Location::model()->findAll($criteria);
                 
            if($locations===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "location" => $locations
            
                       ));
                       
                }
            
            
        }
        
    }
